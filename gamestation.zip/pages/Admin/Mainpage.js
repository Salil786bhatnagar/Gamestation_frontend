import React from 'react'

export default function Mainpage() {
    return (
        <>
         main pagethtytytytytryr
        {/* <!---Container Fluid-->   */}
        </>
    )
}
