import React from 'react';
import styles from  './style.module.css'

const style = {
    button: {
        margin :'0 auto',
        maxWidth:'40%',
        // width:'300px',
        borderRadius:50,
        padding:10,
        background : '#8444bc',
        border :'none'
    },

    blackPaper:{
      width:'100%',
      background:'#000',
      height:'300px',
      padding:'0 50px'

    },


}

export default function Register() {

    const [email, setEmail] = React.useState('');

    return (
        <>
        <div className="text-center my-4">
            <h3>Register to Start</h3>
            <p> and get ₹99 in your account </p>
        </div>
<div className="col-md-6">
{/* <label for="validationServer03" className="form-label">City</label> */}
<input type="text" style={{borderRadius:30}} className="form-control mt-4 p-4 ml-2" id="validationServer03" aria-describedby="validationServer03Feedback" required placeholder='*Username' />
{/* <div id="validationServer03Feedback" className="invalid-feedback">
  Please provide a valid city.
</div> */}
</div>
        
<div className="col-md-6">
{/* <label for="validationServer03" className="form-label">City</label> */}
<input type="text"  style={{borderRadius:30}} className="form-control mt-4 p-4 ml-2" id="validationServer03" aria-describedby="validationServer03Feedback" required placeholder='*Email' />
{/* <div id="validationServer03Feedback" className="invalid-feedback">
  Please provide a valid city.
</div> */}
</div>

<div className="col-md-6">
{/* <label for="validationServer03" className="form-label">City</label> */}
<input type="text"  style={{borderRadius:30}} className="form-control mt-4 p-4 ml-2" id="validationServer03" aria-describedby="validationServer03Feedback" required placeholder='*Password' />
{/* <div id="validationServer03Feedback" className="invalid-feedback">
  Please provide a valid city.
</div> */}
</div>

<div className="col-md-6">
{/* <label for="validationServer03" className="form-label">City</label> */}
<input type="text"  style={{borderRadius:30}} className="form-control mt-4 p-4 ml-2" id="validationServer03" aria-describedby="validationServer03Feedback" required placeholder='*Confirm Password' />
{/* <div id="validationServer03Feedback" className="invalid-feedback">
  Please provide a valid city.
</div> */}
</div>

<div className="col-md-6">
 {/* <label for="validationServer03" className="form-label">Phone</label> */}
<input type="text"  style={{borderRadius:30}} className="form-control mt-4 p-4 ml-2" id="validationServer03" aria-describedby="validationServer03Feedback" required placeholder='*Phone' />
{/* <div id="validationServer03Feedback" className="invalid-feedback">
  Please provide a valid city.
</div> */}
</div>

<div style={{width:'100%'}} class="col-md-6 mt-4 mx-3" >
  <button className="btn btn-primary btn-block" style={style.button} type="button">Resgister</button>
  
</div>


<p className='text-center mt-4'>Already have an account? Sign in Now</p>

<div  className="mt-5" style={style.blackPaper}>
<div style={{color:'#ccc',padding:80}}>
<h6 style={{letterSpacing:1.5}}><b>GET EXCLUSIVE UPDATES </b></h6>
<p style={{color:'grey'}} className="mt-4"  >Subscribe to our newsletter and get essential updates about discounts and price drops</p>
<div className={styles.inputContainer} >
  <input placeholder='Email Address'  value={email} onClick={e => setEmail(e.target.value)}/>
  <div className={styles.subscribe}>
  <button>Subscribe</button>
  <span>&#9654;</span>
  </div>
</div>
</div>

</div>

</>
    )
}
 