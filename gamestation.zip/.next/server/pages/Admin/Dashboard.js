module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./pages/Admin/Dashboard.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./FetchServices.js":
/*!**************************!*\
  !*** ./FetchServices.js ***!
  \**************************/
/*! exports provided: getData, postData, postDataAndImage, deleteDataAxios, ServerURL */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getData", function() { return getData; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "postData", function() { return postData; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "postDataAndImage", function() { return postDataAndImage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "deleteDataAxios", function() { return deleteDataAxios; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServerURL", function() { return ServerURL; });
var axios = __webpack_require__(/*! axios */ "axios");

const ServerURL = 'http://localhost:4000'; //to read all data from node

/* get data*/

const getData = async url => {
  try {
    const response = await fetch(`${ServerURL}/${url}`);
    const result = await response.json();

    if (result == 'Session Expired Pls Login Again') {
      alert(result);
      return [];
    } else {
      return result;
    }
  } catch (e) {
    console.log(e);
    return null;
  }
};
/* post data */


const postData = async (url, body) => {
  try {
    const response = await fetch(`${ServerURL}/${url}`, {
      method: "POST",
      mode: "cors",
      headers: {
        "Content-Type": "application/json;charset=utf-8"
      },
      body: JSON.stringify(body)
    });
    const result = await response.json();

    if (result == 'Session Expired Pls Login Again') {
      alert(result);
      return [];
    } else {
      //const result=await response.json()
      return result;
    }
  } catch (e) {
    console.log(e);
    return null;
  }
};
/* post and image data*/


const postDataAndImage = async (url, formData, config) => {
  try {
    var response = await axios.post(`${ServerURL}/${url}`, formData, config); //  const result=await response.data.RESULT 

    if (response.data == 'Session Expired Pls Login Again') {
      alert(response.data);
      return false;
    } else {
      const result = await response.data;
      return result;
    }
  } catch (e) {
    return null;
  }
};

const deleteDataAxios = async Url => {
  try {
    var url = `${ServerURL}/${Url}`;
    const config = {
      "content-type": "application/json"
    };
    const response = await axios.delete(url, config);
    var result = response.data;
    console.log(result);
    return result;
  } catch (error) {
    console.log(error);
  }
};



/***/ }),

/***/ "./pages/Admin/Console_type.js":
/*!*************************************!*\
  !*** ./pages/Admin/Console_type.js ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ConsoleType; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _FetchServices__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../FetchServices */ "./FetchServices.js");
/* harmony import */ var _material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/IconButton */ "@material-ui/core/IconButton");
/* harmony import */ var _material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core_Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/Button */ "@material-ui/core/Button");
/* harmony import */ var _material_ui_core_Button__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _material_ui_core_Avatar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/Avatar */ "@material-ui/core/Avatar");
/* harmony import */ var _material_ui_core_Avatar__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Avatar__WEBPACK_IMPORTED_MODULE_5__);


var _jsxFileName = "E:\\gamestation\\pages\\Admin\\Console_type.js";





function ConsoleType() {
  const {
    0: getType,
    1: setType
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])("");
  const {
    0: getDescription,
    1: setDescription
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])("");
  const {
    0: getImage,
    1: setImage
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])({
    icon: '',
    file: ''
  });
  const {
    0: getMessage,
    1: setMessage
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])("");
  /* handle in image*/

  const handleImage = event => {
    setImage({
      icon: URL.createObjectURL(event.target.files[0]),
      file: event.target.files[0]
    });
  };

  const handlesubmit = async () => {
    var formData = new FormData();
    formData.append('type', getType), formData.append('description', getDescription), formData.append('image', getImage.file);
    var config = {
      header: {
        'content-type': 'multipart/form-data'
      }
    };
    var result = await Object(_FetchServices__WEBPACK_IMPORTED_MODULE_2__["postDataAndImage"])('consoletype/addtype', formData, config);
    console.log('result', result);

    if (result) {
      //alert("Record Submitted")
      setMessage('Record Submitted');
    } else {
      // alert('Fail to Submit Record')
      setMessage('Fail to Submit Record');
    }
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      id: "consoletype_form",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        id: "consoltypeheading",
        children: "Console Type"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 40,
        columnNumber: 12
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        class: "form-row",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          class: "col-md-6 mb-3",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
            for: "validationServer01",
            children: "Type"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 44,
            columnNumber: 21
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
            type: "text",
            class: "form-control",
            id: "validationServer01",
            value: getType,
            onChange: event => setType(event.target.value),
            required: true
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 45,
            columnNumber: 21
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            class: "valid-feedback",
            children: "Looks good!"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 47,
            columnNumber: 21
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 43,
          columnNumber: 21
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          class: "col-md-6 mb-3",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
            for: "validationServer02",
            children: "Description"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 52,
            columnNumber: 21
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
            type: "text",
            class: "form-control",
            id: "validationServer02",
            value: getDescription,
            onChange: event => setDescription(event.target.value),
            required: true
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 53,
            columnNumber: 21
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            class: "valid-feedback",
            children: "Looks good!"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 55,
            columnNumber: 21
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 51,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 42,
        columnNumber: 17
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        class: "form-row",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          class: "col-md-6 mb-3",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
            accept: "image/*" //  className={classes.input}
            ,
            id: "contained-button-file",
            multiple: true,
            type: "file",
            style: {
              display: 'none'
            },
            onChange: event => handleImage(event)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 64,
            columnNumber: 21
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
            htmlFor: "contained-button-file",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_4___default.a, {
              variant: "contained",
              color: "primary",
              component: "span",
              children: "Upload Image"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 74,
              columnNumber: 25
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 73,
            columnNumber: 21
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Avatar__WEBPACK_IMPORTED_MODULE_5___default.a, {
            id: "Aveter",
            style: {
              width: 60,
              height: 60
            },
            src: getImage.icon
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 78,
            columnNumber: 21
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 61,
          columnNumber: 21
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 60,
        columnNumber: 20
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_4___default.a, {
        variant: "contained",
        color: "primary",
        onClick: () => handlesubmit(),
        children: "Submit form"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 82,
        columnNumber: 21
      }, this), getMessage]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 39,
      columnNumber: 9
    }, this)
  }, void 0, false);
}

/***/ }),

/***/ "./pages/Admin/Dashboard.js":
/*!**********************************!*\
  !*** ./pages/Admin/Dashboard.js ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Dashboard; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! clsx */ "clsx");
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/Typography */ "@material-ui/core/Typography");
/* harmony import */ var _material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _Console_type__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Console_type */ "./pages/Admin/Console_type.js");
/* harmony import */ var _Displayall_consoletype__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Displayall_consoletype */ "./pages/Admin/Displayall_consoletype.js");
/* harmony import */ var _Mainpage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./Mainpage */ "./pages/Admin/Mainpage.js");
/* harmony import */ var _material_ui_core_CssBaseline__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @material-ui/core/CssBaseline */ "@material-ui/core/CssBaseline");
/* harmony import */ var _material_ui_core_CssBaseline__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_CssBaseline__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _material_ui_core_AppBar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @material-ui/core/AppBar */ "@material-ui/core/AppBar");
/* harmony import */ var _material_ui_core_AppBar__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_AppBar__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _material_ui_core_Toolbar__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @material-ui/core/Toolbar */ "@material-ui/core/Toolbar");
/* harmony import */ var _material_ui_core_Toolbar__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Toolbar__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _material_ui_core_List__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @material-ui/core/List */ "@material-ui/core/List");
/* harmony import */ var _material_ui_core_List__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_List__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _material_ui_core_Divider__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @material-ui/core/Divider */ "@material-ui/core/Divider");
/* harmony import */ var _material_ui_core_Divider__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Divider__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @material-ui/core/IconButton */ "@material-ui/core/IconButton");
/* harmony import */ var _material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _material_ui_core_Badge__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @material-ui/core/Badge */ "@material-ui/core/Badge");
/* harmony import */ var _material_ui_core_Badge__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Badge__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _material_ui_core_Container__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @material-ui/core/Container */ "@material-ui/core/Container");
/* harmony import */ var _material_ui_core_Container__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Container__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @material-ui/core/Grid */ "@material-ui/core/Grid");
/* harmony import */ var _material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _material_ui_core_Paper__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @material-ui/core/Paper */ "@material-ui/core/Paper");
/* harmony import */ var _material_ui_core_Paper__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Paper__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _material_ui_core_Link__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @material-ui/core/Link */ "@material-ui/core/Link");
/* harmony import */ var _material_ui_core_Link__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Link__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _material_ui_icons_Menu__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @material-ui/icons/Menu */ "@material-ui/icons/Menu");
/* harmony import */ var _material_ui_icons_Menu__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Menu__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _material_ui_core_Avatar__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @material-ui/core/Avatar */ "@material-ui/core/Avatar");
/* harmony import */ var _material_ui_core_Avatar__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Avatar__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _material_ui_core_Drawer__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @material-ui/core/Drawer */ "@material-ui/core/Drawer");
/* harmony import */ var _material_ui_core_Drawer__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Drawer__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _material_ui_icons_ChevronLeft__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @material-ui/icons/ChevronLeft */ "@material-ui/icons/ChevronLeft");
/* harmony import */ var _material_ui_icons_ChevronLeft__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_ChevronLeft__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _ListItems__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./ListItems */ "./pages/Admin/ListItems.js");
/* harmony import */ var _material_ui_core_Box__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @material-ui/core/Box */ "@material-ui/core/Box");
/* harmony import */ var _material_ui_core_Box__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Box__WEBPACK_IMPORTED_MODULE_24__);


var _jsxFileName = "E:\\gamestation\\pages\\Admin\\Dashboard.js";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


























function Copyright() {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_4___default.a, {
    variant: "body2",
    color: "textSecondary",
    align: "center",
    children: ['Copyright © ', /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Link__WEBPACK_IMPORTED_MODULE_18___default.a, {
      color: "inherit",
      href: "https://material-ui.com/",
      children: "Your Website"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 29,
      columnNumber: 7
    }, this), ' ', new Date().getFullYear(), '.']
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 27,
    columnNumber: 5
  }, this);
}

const drawerWidth = 240;
const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_3__["makeStyles"])(theme => ({
  root: {
    display: 'flex'
  },
  toolbar: {
    paddingRight: 24 // keep right padding when drawer closed

  },
  toolbarIcon: _objectSpread({
    display: 'flex',
    // alignItems: 'center',
    justifyContent: 'flex-end',
    padding: '0 8px'
  }, theme.mixins.toolbar),
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen
    })
  },
  appBarShift: {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen
    })
  },
  menuButton: {
    marginRight: 36
  },
  menuButtonHidden: {
    display: 'none'
  },
  title: {
    flexGrow: 1
  },
  drawerPaper: {
    position: 'relative',
    whiteSpace: 'nowrap',
    width: drawerWidth,
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen
    })
  },
  drawerPaperClose: {
    overflowX: 'hidden',
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen
    }),
    width: theme.spacing(7),
    [theme.breakpoints.up('sm')]: {
      width: theme.spacing(9)
    }
  },
  appBarSpacer: theme.mixins.toolbar,
  content: {
    flexGrow: 1,
    height: '100vh',
    overflow: 'auto'
  },
  container: {
    paddingTop: theme.spacing(4),
    paddingBottom: theme.spacing(4) // backgroundColor:'#ececd9',

  },
  paper: {
    padding: theme.spacing(2),
    display: 'flex',
    overflow: 'auto',
    flexDirection: 'column'
  },
  fixedHeight: {
    height: 240
  }
}));
function Dashboard(props) {
  const classes = useStyles();
  const [open, setOpen] = react__WEBPACK_IMPORTED_MODULE_1___default.a.useState(true);
  const [ShowComponents, setComponet] = react__WEBPACK_IMPORTED_MODULE_1___default.a.useState( /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_Mainpage__WEBPACK_IMPORTED_MODULE_7__["default"], {}, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 123,
    columnNumber: 55
  }, this)); //   const [admin,setAdmin]=React.useState([])
  //   const CheckSession=async()=>{
  //   var result=await getData('admin/chktoken')
  //   if(!result)
  //   {
  //    props.history.replace({pathname:'/Signin'})
  //   }
  //   else{
  //     var admin=JSON.parse(localStorage.getItem('admin'))
  //    console.log("ADMIN",admin)
  //    setAdmin(admin)
  //   }
  // useEffect(function(){
  //   CheckSession();
  // },[])

  const handleComponents = async ShowData => {
    switch (ShowData) {
      case 0:
        console.log('0', 0);
        setComponet( /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_Mainpage__WEBPACK_IMPORTED_MODULE_7__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 146,
          columnNumber: 19
        }, this));
        break;

      case 1:
        setComponet( /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_Console_type__WEBPACK_IMPORTED_MODULE_5__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 149,
          columnNumber: 19
        }, this));
        break;

      case 2:
        setComponet( /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_Displayall_consoletype__WEBPACK_IMPORTED_MODULE_6__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 152,
          columnNumber: 19
        }, this));
        break;
    }
  };

  const handleDrawerOpen = () => {
    setOpen(true);
  };

  const handleDrawerClose = () => {
    setOpen(false);
  };

  const fixedHeightPaper = clsx__WEBPACK_IMPORTED_MODULE_2___default()(classes.paper, classes.fixedHeight);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_CssBaseline__WEBPACK_IMPORTED_MODULE_8___default.a, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 169,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_AppBar__WEBPACK_IMPORTED_MODULE_9___default.a, {
      position: "absolute",
      className: clsx__WEBPACK_IMPORTED_MODULE_2___default()(classes.appBar, open && classes.appBarShift),
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Toolbar__WEBPACK_IMPORTED_MODULE_10___default.a, {
        className: classes.toolbar,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_13___default.a, {
          edge: "start",
          color: "inherit",
          "aria-label": "open drawer",
          onClick: handleDrawerOpen,
          className: clsx__WEBPACK_IMPORTED_MODULE_2___default()(classes.menuButton, open && classes.menuButtonHidden),
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_Menu__WEBPACK_IMPORTED_MODULE_19___default.a, {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 179,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 172,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_4___default.a, {
          component: "h1",
          variant: "h6",
          color: "inherit",
          noWrap: true,
          className: classes.title,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: classes.heading,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {}, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 186,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 182,
            columnNumber: 11
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 181,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Avatar__WEBPACK_IMPORTED_MODULE_20___default.a, {
          alt: "Remy Sharp",
          className: classes.large
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 191,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 171,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 170,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Drawer__WEBPACK_IMPORTED_MODULE_21___default.a, {
      variant: "permanent",
      classes: {
        paper: clsx__WEBPACK_IMPORTED_MODULE_2___default()(classes.drawerPaper, !open && classes.drawerPaperClose)
      },
      open: open,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: classes.toolbarIcon,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_13___default.a, {
          onClick: handleDrawerClose,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_ChevronLeft__WEBPACK_IMPORTED_MODULE_22___default.a, {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 210,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 209,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 208,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Divider__WEBPACK_IMPORTED_MODULE_12___default.a, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 214,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_List__WEBPACK_IMPORTED_MODULE_11___default.a, {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ListItems__WEBPACK_IMPORTED_MODULE_23__["default"], {
          handle_Components: handleComponents
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 215,
          columnNumber: 15
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 215,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 201,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("main", {
      className: classes.content,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: classes.appBarSpacer
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 218,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Container__WEBPACK_IMPORTED_MODULE_15___default.a, {
        maxWidth: "lg",
        className: classes.container,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_16___default.a, {
          container: true,
          spacing: 2,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_16___default.a, {
            item: true,
            xs: 12,
            sm: 12,
            children: ShowComponents
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 221,
            columnNumber: 15
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 220,
          columnNumber: 13
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Box__WEBPACK_IMPORTED_MODULE_24___default.a, {
            pt: 12,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Copyright, {}, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 227,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 226,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 225,
          columnNumber: 12
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 219,
        columnNumber: 11
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 217,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

/***/ }),

/***/ "./pages/Admin/Displayall_consoletype.js":
/*!***********************************************!*\
  !*** ./pages/Admin/Displayall_consoletype.js ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Displayall_consoletype; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var material_table__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! material-table */ "material-table");
/* harmony import */ var material_table__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(material_table__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core_Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/Button */ "@material-ui/core/Button");
/* harmony import */ var _material_ui_core_Button__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _material_ui_core_Avatar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/Avatar */ "@material-ui/core/Avatar");
/* harmony import */ var _material_ui_core_Avatar__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Avatar__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _FetchServices__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../FetchServices */ "./FetchServices.js");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! sweetalert2 */ "sweetalert2");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_7__);


var _jsxFileName = "E:\\gamestation\\pages\\Admin\\Displayall_consoletype.js";







/**
 * @author
 * @function CategoryDisplay
 **/

function Displayall_consoletype() {
  const {
    0: data,
    1: setData
  } = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])([]);
  const {
    0: open,
    1: setOpen
  } = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(false);
  const {
    0: getConsole_Id,
    1: setConsole_Id
  } = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])("");
  const {
    0: getType,
    1: setType
  } = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])("");
  const {
    0: getDescription,
    1: setDescription
  } = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])("");
  const {
    0: getImage,
    1: setImage
  } = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])({
    icon: '',
    file: ''
  });
  const {
    0: getMessage,
    1: setMessage
  } = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])("");
  const {
    0: getColumns,
    1: setColumns
  } = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])({
    columns: [{
      title: "Type",
      field: "type"
    }, {
      title: "Description",
      field: "description"
    }, {
      title: "Image",
      field: "image",
      render: rowData => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Avatar__WEBPACK_IMPORTED_MODULE_5___default.a, {
          variant: "rounded",
          src: `${_FetchServices__WEBPACK_IMPORTED_MODULE_6__["ServerURL"]}/images/${rowData.image}`
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 28,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 9
      }, this)
    }]
  });

  const fetchData = async () => {
    const result = await Object(_FetchServices__WEBPACK_IMPORTED_MODULE_6__["getData"])("consoletype/display");
    console.log("data", result);
    result.status && setData(result.result);
  };

  Object(react__WEBPACK_IMPORTED_MODULE_3__["useEffect"])(() => {
    fetchData();
  }, []);

  const handleClose = () => {
    setOpen(false); // fetchData()
  };
  /* handle in icon*/


  const handleImage = event => {
    setImage({
      icon: URL.createObjectURL(event.target.files[0]),
      file: event.target.files[0]
    });
  };

  const handleUpdate = rowData => {
    setConsole_Id(rowData.console_type_id);
    setType(rowData.type);
    setDescription(rowData.description);
    setImage({
      icon: `${_FetchServices__WEBPACK_IMPORTED_MODULE_6__["ServerURL"]}/images/${rowData.image}`,
      file: ""
    });
    setOpen(true);
  }; // const handleDelete = async (oldData) => {
  //   // let body = { getConsole_Id: oldData.console_type_id };
  //   await deleteDataAxios(`consoletype/delete/${oldData.getConsole_Id}`);
  // };


  const handleDelete = async oldData => {
    // console.log("oldDataaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",JSON.stringify(oldData))
    await Object(_FetchServices__WEBPACK_IMPORTED_MODULE_6__["deleteDataAxios"])(`consoletype/delete/${oldData.console_type_id}`);
  };

  const handleSubmit = async e => {
    var formData = new FormData();
    formData.append('console_type_id', getConsole_Id);
    formData.append('type', getType), formData.append('description', getDescription), formData.append('image', getImage.file);
    var config = {
      header: {
        'content-type': 'multipart/form-data'
      }
    }; // var result = await postDataAndImage(`consoletype/update/${console_type_id}`, config)
    // console.log('result',result);

    var result = await Object(_FetchServices__WEBPACK_IMPORTED_MODULE_6__["postDataAndImage"])(`consoletype/update/${getConsole_Id}`, formData, config);
    fetchData();
    handleClose();

    if (result) {
      //alert("Record Submitted")
      setMessage('Record Updated');
    } else {
      // alert('Fail to Submit Record')
      setMessage('Fail to Update Record');
    }
  };

  const renderEditForm = e => {
    const style = {
      width: 600,
      padding: 16,
      borderRadius: 5,
      boxShadow: "0 0 10px -1px #ccc"
    };
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      id: "consoletype_formdilogbox",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        id: "consoltypeheading",
        children: "Console Type"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 113,
        columnNumber: 12
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        class: "form-row",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          class: "col-md-6 mb-3",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
            for: "validationServer01",
            children: "Type"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 116,
            columnNumber: 21
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
            type: "text",
            class: "form-control",
            id: "validationServer01",
            value: getType,
            onChange: event => setType(event.target.value),
            required: true
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 117,
            columnNumber: 21
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            class: "valid-feedback",
            children: "Looks good!"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 119,
            columnNumber: 21
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 115,
          columnNumber: 21
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          class: "col-md-6 mb-3",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
            for: "validationServer02",
            children: "Description"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 124,
            columnNumber: 21
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
            type: "text",
            class: "form-control",
            id: "validationServer02",
            value: getDescription,
            onChange: event => setDescription(event.target.value),
            required: true
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 125,
            columnNumber: 21
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            class: "valid-feedback",
            children: "Looks good!"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 127,
            columnNumber: 21
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 123,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 114,
        columnNumber: 17
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        class: "form-row",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          class: "col-md-6 mb-3",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
            accept: "image/*" //  className={classes.input}
            ,
            id: "contained-button-file",
            multiple: true,
            type: "file",
            style: {
              display: 'none'
            },
            onChange: event => handleImage(event)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 136,
            columnNumber: 21
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
            htmlFor: "contained-button-file",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_4___default.a, {
              variant: "contained",
              color: "primary",
              component: "span",
              children: "Upload Image"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 146,
              columnNumber: 25
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 145,
            columnNumber: 21
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Avatar__WEBPACK_IMPORTED_MODULE_5___default.a, {
            id: "Aveterdilogbox",
            style: {
              width: 60,
              height: 60
            },
            src: getImage.icon
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 150,
            columnNumber: 21
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 133,
          columnNumber: 21
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 132,
        columnNumber: 20
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_4___default.a, {
        variant: "contained",
        color: "primary",
        disableElevation: true,
        id: "buttonSumit",
        onClick: () => handleSubmit(),
        children: "Submit form"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 154,
        columnNumber: 21
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 159,
          columnNumber: 19
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("center", {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
            children: getMessage
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 160,
            columnNumber: 27
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 160,
          columnNumber: 19
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 158,
        columnNumber: 17
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 112,
      columnNumber: 1
    }, this);
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(material_table__WEBPACK_IMPORTED_MODULE_2___default.a, {
      title: "Consol Type Data",
      columns: getColumns.columns,
      data: data,
      options: {
        headerStyle: {
          backgroundColor: "#003399",
          color: "#FFF"
        },
        actionsCellStyle: {
          padding: "0 20px"
        }
      },
      actions: [{
        icon: "edit",
        tooltip: "Edit",
        onClick: (event, rowData) => {
          handleUpdate(rowData);
        }
      }],
      editable: {
        onRowDelete: oldData => new Promise((resolve, reject) => {
          setTimeout(() => {
            const dataDelete = [...data];
            const index = oldData.tableData.id;
            dataDelete.splice(index, 1);
            setData([...dataDelete]);
            handleDelete(oldData);
            resolve();
          }, 1000);
        })
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 169,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Dialog"] // fullScreen={fullScreen}
    , {
      maxWidth: "lg",
      open: open,
      onClose: handleClose,
      "aria-labelledby": "responsive-dialog-title",
      children: renderEditForm()
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 205,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}
const style = {
  maxWidth: "95%",
  margin: "20px auto",
  borderRadius: 5,
  boxShadow: "0 0 10px -1px #ccc"
}; // const CategoryDisplay = (props) => {
//   return <div style={style}>{Editable()}</div>;
// };

/***/ }),

/***/ "./pages/Admin/ListItems.js":
/*!**********************************!*\
  !*** ./pages/Admin/ListItems.js ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ListItems; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_ListItem__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/ListItem */ "@material-ui/core/ListItem");
/* harmony import */ var _material_ui_core_ListItem__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_ListItem__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_ListItemIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/ListItemIcon */ "@material-ui/core/ListItemIcon");
/* harmony import */ var _material_ui_core_ListItemIcon__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_ListItemIcon__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core_ListItemText__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/ListItemText */ "@material-ui/core/ListItemText");
/* harmony import */ var _material_ui_core_ListItemText__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_ListItemText__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _material_ui_core_ListSubheader__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/ListSubheader */ "@material-ui/core/ListSubheader");
/* harmony import */ var _material_ui_core_ListSubheader__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_ListSubheader__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _material_ui_icons_Dashboard__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/icons/Dashboard */ "@material-ui/icons/Dashboard");
/* harmony import */ var _material_ui_icons_Dashboard__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Dashboard__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _material_ui_icons_ShoppingCart__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @material-ui/icons/ShoppingCart */ "@material-ui/icons/ShoppingCart");
/* harmony import */ var _material_ui_icons_ShoppingCart__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_ShoppingCart__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _material_ui_icons_People__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @material-ui/icons/People */ "@material-ui/icons/People");
/* harmony import */ var _material_ui_icons_People__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_People__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _material_ui_icons_BarChart__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @material-ui/icons/BarChart */ "@material-ui/icons/BarChart");
/* harmony import */ var _material_ui_icons_BarChart__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_BarChart__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _material_ui_icons_Layers__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @material-ui/icons/Layers */ "@material-ui/icons/Layers");
/* harmony import */ var _material_ui_icons_Layers__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Layers__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _material_ui_icons_Assignment__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @material-ui/icons/Assignment */ "@material-ui/icons/Assignment");
/* harmony import */ var _material_ui_icons_Assignment__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Assignment__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _material_ui_core_List__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @material-ui/core/List */ "@material-ui/core/List");
/* harmony import */ var _material_ui_core_List__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_List__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _material_ui_core_Collapse__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @material-ui/core/Collapse */ "@material-ui/core/Collapse");
/* harmony import */ var _material_ui_core_Collapse__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Collapse__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _material_ui_icons_MoveToInbox__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @material-ui/icons/MoveToInbox */ "@material-ui/icons/MoveToInbox");
/* harmony import */ var _material_ui_icons_MoveToInbox__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_MoveToInbox__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _material_ui_icons_Drafts__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @material-ui/icons/Drafts */ "@material-ui/icons/Drafts");
/* harmony import */ var _material_ui_icons_Drafts__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Drafts__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _material_ui_icons_Send__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @material-ui/icons/Send */ "@material-ui/icons/Send");
/* harmony import */ var _material_ui_icons_Send__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Send__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _material_ui_icons_ExpandLess__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @material-ui/icons/ExpandLess */ "@material-ui/icons/ExpandLess");
/* harmony import */ var _material_ui_icons_ExpandLess__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_ExpandLess__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _material_ui_icons_ExpandMore__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @material-ui/icons/ExpandMore */ "@material-ui/icons/ExpandMore");
/* harmony import */ var _material_ui_icons_ExpandMore__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_ExpandMore__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _material_ui_icons_StarBorder__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @material-ui/icons/StarBorder */ "@material-ui/icons/StarBorder");
/* harmony import */ var _material_ui_icons_StarBorder__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_StarBorder__WEBPACK_IMPORTED_MODULE_20__);

var _jsxFileName = "E:\\gamestation\\pages\\Admin\\ListItems.js";




















const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_12__["makeStyles"])(theme => ({}));
function ListItems(props) {
  const classes = useStyles();
  const [open, setOpen] = react__WEBPACK_IMPORTED_MODULE_1___default.a.useState(false);
  const [brand, setBrand] = react__WEBPACK_IMPORTED_MODULE_1___default.a.useState(false);
  const [outlate, setOutlate] = react__WEBPACK_IMPORTED_MODULE_1___default.a.useState(false);
  const [modle, setModle] = react__WEBPACK_IMPORTED_MODULE_1___default.a.useState(false); //  const [category, setCategory]=React.useState(false)

  const handleClickOpen = listData => {
    if (listData == 'Console_type') {
      setOpen(!open);
    } else if (listData == 'brand_data') {
      setBrand(!brand);
    } else if (listData == 'outlate_data') {
      setOutlate(!outlate);
    } else if (listData == 'modle_data') {
      setModle(!modle);
    }
  };

  const handleClick = showData => {
    props.handle_Components(showData);
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_ListItem__WEBPACK_IMPORTED_MODULE_2___default.a, {
      button: true,
      onClick: () => handleClick(0),
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_ListItemIcon__WEBPACK_IMPORTED_MODULE_3___default.a, {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_Dashboard__WEBPACK_IMPORTED_MODULE_6___default.a, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 56,
          columnNumber: 9
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 55,
        columnNumber: 7
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_ListItemText__WEBPACK_IMPORTED_MODULE_4___default.a, {
        primary: "Dashboard"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 58,
        columnNumber: 7
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 54,
      columnNumber: 5
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_ListItem__WEBPACK_IMPORTED_MODULE_2___default.a, {
      button: true,
      onClick: () => handleClickOpen('Console_type'),
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_ListItemIcon__WEBPACK_IMPORTED_MODULE_3___default.a, {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_ShoppingCart__WEBPACK_IMPORTED_MODULE_7___default.a, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 63,
          columnNumber: 9
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 62,
        columnNumber: 7
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_ListItemText__WEBPACK_IMPORTED_MODULE_4___default.a, {
        primary: "Console Type"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 65,
        columnNumber: 7
      }, this), open ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_ExpandLess__WEBPACK_IMPORTED_MODULE_18___default.a, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 66,
        columnNumber: 17
      }, this) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_ExpandMore__WEBPACK_IMPORTED_MODULE_19___default.a, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 66,
        columnNumber: 34
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 61,
      columnNumber: 5
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Collapse__WEBPACK_IMPORTED_MODULE_14___default.a, {
      in: open,
      timeout: "auto",
      unmountOnExit: true,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_List__WEBPACK_IMPORTED_MODULE_13___default.a, {
        component: "div",
        disablePadding: true,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_ListItem__WEBPACK_IMPORTED_MODULE_2___default.a, {
          button: true,
          className: classes.nested,
          onClick: () => handleClick(1),
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_ListItemIcon__WEBPACK_IMPORTED_MODULE_3___default.a, {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_StarBorder__WEBPACK_IMPORTED_MODULE_20___default.a, {}, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 72,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 71,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_ListItemText__WEBPACK_IMPORTED_MODULE_4___default.a, {
            primary: "Display all console type "
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 74,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 70,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_ListItem__WEBPACK_IMPORTED_MODULE_2___default.a, {
          button: true,
          className: classes.nested,
          onClick: () => handleClick(2),
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_ListItemIcon__WEBPACK_IMPORTED_MODULE_3___default.a, {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_StarBorder__WEBPACK_IMPORTED_MODULE_20___default.a, {}, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 79,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 78,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_ListItemText__WEBPACK_IMPORTED_MODULE_4___default.a, {
            primary: "Displayall_consoletype"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 81,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 77,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 69,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 68,
      columnNumber: 5
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 53,
    columnNumber: 3
  }, this);
}

/***/ }),

/***/ "./pages/Admin/Mainpage.js":
/*!*********************************!*\
  !*** ./pages/Admin/Mainpage.js ***!
  \*********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Mainpage; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



function Mainpage() {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: "main pagethtytytytytryr"
  }, void 0, false);
}

/***/ }),

/***/ "@material-ui/core":
/*!************************************!*\
  !*** external "@material-ui/core" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core");

/***/ }),

/***/ "@material-ui/core/AppBar":
/*!*******************************************!*\
  !*** external "@material-ui/core/AppBar" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/AppBar");

/***/ }),

/***/ "@material-ui/core/Avatar":
/*!*******************************************!*\
  !*** external "@material-ui/core/Avatar" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Avatar");

/***/ }),

/***/ "@material-ui/core/Badge":
/*!******************************************!*\
  !*** external "@material-ui/core/Badge" ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Badge");

/***/ }),

/***/ "@material-ui/core/Box":
/*!****************************************!*\
  !*** external "@material-ui/core/Box" ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Box");

/***/ }),

/***/ "@material-ui/core/Button":
/*!*******************************************!*\
  !*** external "@material-ui/core/Button" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Button");

/***/ }),

/***/ "@material-ui/core/Collapse":
/*!*********************************************!*\
  !*** external "@material-ui/core/Collapse" ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Collapse");

/***/ }),

/***/ "@material-ui/core/Container":
/*!**********************************************!*\
  !*** external "@material-ui/core/Container" ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Container");

/***/ }),

/***/ "@material-ui/core/CssBaseline":
/*!************************************************!*\
  !*** external "@material-ui/core/CssBaseline" ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/CssBaseline");

/***/ }),

/***/ "@material-ui/core/Divider":
/*!********************************************!*\
  !*** external "@material-ui/core/Divider" ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Divider");

/***/ }),

/***/ "@material-ui/core/Drawer":
/*!*******************************************!*\
  !*** external "@material-ui/core/Drawer" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Drawer");

/***/ }),

/***/ "@material-ui/core/Grid":
/*!*****************************************!*\
  !*** external "@material-ui/core/Grid" ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Grid");

/***/ }),

/***/ "@material-ui/core/IconButton":
/*!***********************************************!*\
  !*** external "@material-ui/core/IconButton" ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/IconButton");

/***/ }),

/***/ "@material-ui/core/Link":
/*!*****************************************!*\
  !*** external "@material-ui/core/Link" ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Link");

/***/ }),

/***/ "@material-ui/core/List":
/*!*****************************************!*\
  !*** external "@material-ui/core/List" ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/List");

/***/ }),

/***/ "@material-ui/core/ListItem":
/*!*********************************************!*\
  !*** external "@material-ui/core/ListItem" ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/ListItem");

/***/ }),

/***/ "@material-ui/core/ListItemIcon":
/*!*************************************************!*\
  !*** external "@material-ui/core/ListItemIcon" ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/ListItemIcon");

/***/ }),

/***/ "@material-ui/core/ListItemText":
/*!*************************************************!*\
  !*** external "@material-ui/core/ListItemText" ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/ListItemText");

/***/ }),

/***/ "@material-ui/core/ListSubheader":
/*!**************************************************!*\
  !*** external "@material-ui/core/ListSubheader" ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/ListSubheader");

/***/ }),

/***/ "@material-ui/core/Paper":
/*!******************************************!*\
  !*** external "@material-ui/core/Paper" ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Paper");

/***/ }),

/***/ "@material-ui/core/Toolbar":
/*!********************************************!*\
  !*** external "@material-ui/core/Toolbar" ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Toolbar");

/***/ }),

/***/ "@material-ui/core/Typography":
/*!***********************************************!*\
  !*** external "@material-ui/core/Typography" ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Typography");

/***/ }),

/***/ "@material-ui/core/styles":
/*!*******************************************!*\
  !*** external "@material-ui/core/styles" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ "@material-ui/icons/Assignment":
/*!************************************************!*\
  !*** external "@material-ui/icons/Assignment" ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/Assignment");

/***/ }),

/***/ "@material-ui/icons/BarChart":
/*!**********************************************!*\
  !*** external "@material-ui/icons/BarChart" ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/BarChart");

/***/ }),

/***/ "@material-ui/icons/ChevronLeft":
/*!*************************************************!*\
  !*** external "@material-ui/icons/ChevronLeft" ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/ChevronLeft");

/***/ }),

/***/ "@material-ui/icons/Dashboard":
/*!***********************************************!*\
  !*** external "@material-ui/icons/Dashboard" ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/Dashboard");

/***/ }),

/***/ "@material-ui/icons/Drafts":
/*!********************************************!*\
  !*** external "@material-ui/icons/Drafts" ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/Drafts");

/***/ }),

/***/ "@material-ui/icons/ExpandLess":
/*!************************************************!*\
  !*** external "@material-ui/icons/ExpandLess" ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/ExpandLess");

/***/ }),

/***/ "@material-ui/icons/ExpandMore":
/*!************************************************!*\
  !*** external "@material-ui/icons/ExpandMore" ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/ExpandMore");

/***/ }),

/***/ "@material-ui/icons/Layers":
/*!********************************************!*\
  !*** external "@material-ui/icons/Layers" ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/Layers");

/***/ }),

/***/ "@material-ui/icons/Menu":
/*!******************************************!*\
  !*** external "@material-ui/icons/Menu" ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/Menu");

/***/ }),

/***/ "@material-ui/icons/MoveToInbox":
/*!*************************************************!*\
  !*** external "@material-ui/icons/MoveToInbox" ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/MoveToInbox");

/***/ }),

/***/ "@material-ui/icons/People":
/*!********************************************!*\
  !*** external "@material-ui/icons/People" ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/People");

/***/ }),

/***/ "@material-ui/icons/Send":
/*!******************************************!*\
  !*** external "@material-ui/icons/Send" ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/Send");

/***/ }),

/***/ "@material-ui/icons/ShoppingCart":
/*!**************************************************!*\
  !*** external "@material-ui/icons/ShoppingCart" ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/ShoppingCart");

/***/ }),

/***/ "@material-ui/icons/StarBorder":
/*!************************************************!*\
  !*** external "@material-ui/icons/StarBorder" ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/StarBorder");

/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("axios");

/***/ }),

/***/ "clsx":
/*!***********************!*\
  !*** external "clsx" ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("clsx");

/***/ }),

/***/ "material-table":
/*!*********************************!*\
  !*** external "material-table" ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("material-table");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "sweetalert2":
/*!******************************!*\
  !*** external "sweetalert2" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sweetalert2");

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vRmV0Y2hTZXJ2aWNlcy5qcyIsIndlYnBhY2s6Ly8vLi9wYWdlcy9BZG1pbi9Db25zb2xlX3R5cGUuanMiLCJ3ZWJwYWNrOi8vLy4vcGFnZXMvQWRtaW4vRGFzaGJvYXJkLmpzIiwid2VicGFjazovLy8uL3BhZ2VzL0FkbWluL0Rpc3BsYXlhbGxfY29uc29sZXR5cGUuanMiLCJ3ZWJwYWNrOi8vLy4vcGFnZXMvQWRtaW4vTGlzdEl0ZW1zLmpzIiwid2VicGFjazovLy8uL3BhZ2VzL0FkbWluL01haW5wYWdlLmpzIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvQXBwQmFyXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvQXZhdGFyXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvQmFkZ2VcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZS9Cb3hcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZS9CdXR0b25cIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZS9Db2xsYXBzZVwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL0NvbnRhaW5lclwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL0Nzc0Jhc2VsaW5lXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvRGl2aWRlclwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL0RyYXdlclwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL0dyaWRcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZS9JY29uQnV0dG9uXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvTGlua1wiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL0xpc3RcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZS9MaXN0SXRlbVwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL0xpc3RJdGVtSWNvblwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL0xpc3RJdGVtVGV4dFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL0xpc3RTdWJoZWFkZXJcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZS9QYXBlclwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL1Rvb2xiYXJcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZS9UeXBvZ3JhcGh5XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvc3R5bGVzXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2ljb25zL0Fzc2lnbm1lbnRcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvaWNvbnMvQmFyQ2hhcnRcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvaWNvbnMvQ2hldnJvbkxlZnRcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvaWNvbnMvRGFzaGJvYXJkXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2ljb25zL0RyYWZ0c1wiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9pY29ucy9FeHBhbmRMZXNzXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2ljb25zL0V4cGFuZE1vcmVcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvaWNvbnMvTGF5ZXJzXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2ljb25zL01lbnVcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvaWNvbnMvTW92ZVRvSW5ib3hcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvaWNvbnMvUGVvcGxlXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2ljb25zL1NlbmRcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvaWNvbnMvU2hvcHBpbmdDYXJ0XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2ljb25zL1N0YXJCb3JkZXJcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJheGlvc1wiIiwid2VicGFjazovLy9leHRlcm5hbCBcImNsc3hcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJtYXRlcmlhbC10YWJsZVwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicmVhY3QvanN4LWRldi1ydW50aW1lXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwic3dlZXRhbGVydDJcIiJdLCJuYW1lcyI6WyJheGlvcyIsInJlcXVpcmUiLCJTZXJ2ZXJVUkwiLCJnZXREYXRhIiwidXJsIiwicmVzcG9uc2UiLCJmZXRjaCIsInJlc3VsdCIsImpzb24iLCJhbGVydCIsImUiLCJjb25zb2xlIiwibG9nIiwicG9zdERhdGEiLCJib2R5IiwibWV0aG9kIiwibW9kZSIsImhlYWRlcnMiLCJKU09OIiwic3RyaW5naWZ5IiwicG9zdERhdGFBbmRJbWFnZSIsImZvcm1EYXRhIiwiY29uZmlnIiwicG9zdCIsImRhdGEiLCJkZWxldGVEYXRhQXhpb3MiLCJVcmwiLCJkZWxldGUiLCJlcnJvciIsIkNvbnNvbGVUeXBlIiwiZ2V0VHlwZSIsInNldFR5cGUiLCJ1c2VTdGF0ZSIsImdldERlc2NyaXB0aW9uIiwic2V0RGVzY3JpcHRpb24iLCJnZXRJbWFnZSIsInNldEltYWdlIiwiaWNvbiIsImZpbGUiLCJnZXRNZXNzYWdlIiwic2V0TWVzc2FnZSIsImhhbmRsZUltYWdlIiwiZXZlbnQiLCJVUkwiLCJjcmVhdGVPYmplY3RVUkwiLCJ0YXJnZXQiLCJmaWxlcyIsImhhbmRsZXN1Ym1pdCIsIkZvcm1EYXRhIiwiYXBwZW5kIiwiaGVhZGVyIiwidmFsdWUiLCJkaXNwbGF5Iiwid2lkdGgiLCJoZWlnaHQiLCJDb3B5cmlnaHQiLCJEYXRlIiwiZ2V0RnVsbFllYXIiLCJkcmF3ZXJXaWR0aCIsInVzZVN0eWxlcyIsIm1ha2VTdHlsZXMiLCJ0aGVtZSIsInJvb3QiLCJ0b29sYmFyIiwicGFkZGluZ1JpZ2h0IiwidG9vbGJhckljb24iLCJqdXN0aWZ5Q29udGVudCIsInBhZGRpbmciLCJtaXhpbnMiLCJhcHBCYXIiLCJ6SW5kZXgiLCJkcmF3ZXIiLCJ0cmFuc2l0aW9uIiwidHJhbnNpdGlvbnMiLCJjcmVhdGUiLCJlYXNpbmciLCJzaGFycCIsImR1cmF0aW9uIiwibGVhdmluZ1NjcmVlbiIsImFwcEJhclNoaWZ0IiwibWFyZ2luTGVmdCIsImVudGVyaW5nU2NyZWVuIiwibWVudUJ1dHRvbiIsIm1hcmdpblJpZ2h0IiwibWVudUJ1dHRvbkhpZGRlbiIsInRpdGxlIiwiZmxleEdyb3ciLCJkcmF3ZXJQYXBlciIsInBvc2l0aW9uIiwid2hpdGVTcGFjZSIsImRyYXdlclBhcGVyQ2xvc2UiLCJvdmVyZmxvd1giLCJzcGFjaW5nIiwiYnJlYWtwb2ludHMiLCJ1cCIsImFwcEJhclNwYWNlciIsImNvbnRlbnQiLCJvdmVyZmxvdyIsImNvbnRhaW5lciIsInBhZGRpbmdUb3AiLCJwYWRkaW5nQm90dG9tIiwicGFwZXIiLCJmbGV4RGlyZWN0aW9uIiwiZml4ZWRIZWlnaHQiLCJEYXNoYm9hcmQiLCJwcm9wcyIsImNsYXNzZXMiLCJvcGVuIiwic2V0T3BlbiIsIlJlYWN0IiwiU2hvd0NvbXBvbmVudHMiLCJzZXRDb21wb25ldCIsImhhbmRsZUNvbXBvbmVudHMiLCJTaG93RGF0YSIsImhhbmRsZURyYXdlck9wZW4iLCJoYW5kbGVEcmF3ZXJDbG9zZSIsImZpeGVkSGVpZ2h0UGFwZXIiLCJjbHN4IiwiaGVhZGluZyIsImxhcmdlIiwiRGlzcGxheWFsbF9jb25zb2xldHlwZSIsInNldERhdGEiLCJnZXRDb25zb2xlX0lkIiwic2V0Q29uc29sZV9JZCIsImdldENvbHVtbnMiLCJzZXRDb2x1bW5zIiwiY29sdW1ucyIsImZpZWxkIiwicmVuZGVyIiwicm93RGF0YSIsImltYWdlIiwiZmV0Y2hEYXRhIiwic3RhdHVzIiwidXNlRWZmZWN0IiwiaGFuZGxlQ2xvc2UiLCJoYW5kbGVVcGRhdGUiLCJjb25zb2xlX3R5cGVfaWQiLCJ0eXBlIiwiZGVzY3JpcHRpb24iLCJoYW5kbGVEZWxldGUiLCJvbGREYXRhIiwiaGFuZGxlU3VibWl0IiwicmVuZGVyRWRpdEZvcm0iLCJzdHlsZSIsImJvcmRlclJhZGl1cyIsImJveFNoYWRvdyIsImhlYWRlclN0eWxlIiwiYmFja2dyb3VuZENvbG9yIiwiY29sb3IiLCJhY3Rpb25zQ2VsbFN0eWxlIiwidG9vbHRpcCIsIm9uQ2xpY2siLCJvblJvd0RlbGV0ZSIsIlByb21pc2UiLCJyZXNvbHZlIiwicmVqZWN0Iiwic2V0VGltZW91dCIsImRhdGFEZWxldGUiLCJpbmRleCIsInRhYmxlRGF0YSIsImlkIiwic3BsaWNlIiwibWF4V2lkdGgiLCJtYXJnaW4iLCJMaXN0SXRlbXMiLCJicmFuZCIsInNldEJyYW5kIiwib3V0bGF0ZSIsInNldE91dGxhdGUiLCJtb2RsZSIsInNldE1vZGxlIiwiaGFuZGxlQ2xpY2tPcGVuIiwibGlzdERhdGEiLCJoYW5kbGVDbGljayIsInNob3dEYXRhIiwiaGFuZGxlX0NvbXBvbmVudHMiLCJuZXN0ZWQiLCJNYWlucGFnZSJdLCJtYXBwaW5ncyI6Ijs7UUFBQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLElBQUk7UUFDSjtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBOzs7UUFHQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMENBQTBDLGdDQUFnQztRQUMxRTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLHdEQUF3RCxrQkFBa0I7UUFDMUU7UUFDQSxpREFBaUQsY0FBYztRQUMvRDs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EseUNBQXlDLGlDQUFpQztRQUMxRSxnSEFBZ0gsbUJBQW1CLEVBQUU7UUFDckk7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwyQkFBMkIsMEJBQTBCLEVBQUU7UUFDdkQsaUNBQWlDLGVBQWU7UUFDaEQ7UUFDQTtRQUNBOztRQUVBO1FBQ0Esc0RBQXNELCtEQUErRDs7UUFFckg7UUFDQTs7O1FBR0E7UUFDQTs7Ozs7Ozs7Ozs7OztBQ3hGQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUFJQSxLQUFLLEdBQUNDLG1CQUFPLENBQUMsb0JBQUQsQ0FBakI7O0FBQ0EsTUFBTUMsU0FBUyxHQUFDLHVCQUFoQixDLENBQ0E7O0FBRUE7O0FBQ0EsTUFBTUMsT0FBTyxHQUFDLE1BQU1DLEdBQU4sSUFBWTtBQUN0QixNQUFHO0FBQ0QsVUFBTUMsUUFBUSxHQUFDLE1BQU1DLEtBQUssQ0FBRSxHQUFFSixTQUFVLElBQUdFLEdBQUksRUFBckIsQ0FBMUI7QUFDQSxVQUFNRyxNQUFNLEdBQUMsTUFBTUYsUUFBUSxDQUFDRyxJQUFULEVBQW5COztBQUNBLFFBQUdELE1BQU0sSUFBRSxpQ0FBWCxFQUNBO0FBQ0VFLFdBQUssQ0FBQ0YsTUFBRCxDQUFMO0FBQ0EsYUFBTyxFQUFQO0FBQ0QsS0FKRCxNQUtLO0FBQ0gsYUFBT0EsTUFBUDtBQUNBO0FBQ0gsR0FYRCxDQVdDLE9BQU1HLENBQU4sRUFBUTtBQUNKQyxXQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNKLFdBQU8sSUFBUDtBQUVBO0FBQ0osQ0FqQkQ7QUFtQkE7OztBQUNBLE1BQU1HLFFBQVEsR0FBQyxPQUFNVCxHQUFOLEVBQVVVLElBQVYsS0FBaUI7QUFDNUIsTUFBRztBQUNELFVBQU1ULFFBQVEsR0FBQyxNQUFNQyxLQUFLLENBQUUsR0FBRUosU0FBVSxJQUFHRSxHQUFJLEVBQXJCLEVBQzFCO0FBQUNXLFlBQU0sRUFBQyxNQUFSO0FBQWVDLFVBQUksRUFBQyxNQUFwQjtBQUNDQyxhQUFPLEVBQUM7QUFBQyx3QkFBZTtBQUFoQixPQURUO0FBRUNILFVBQUksRUFBQ0ksSUFBSSxDQUFDQyxTQUFMLENBQWVMLElBQWY7QUFGTixLQUQwQixDQUExQjtBQUtBLFVBQU1QLE1BQU0sR0FBQyxNQUFNRixRQUFRLENBQUNHLElBQVQsRUFBbkI7O0FBQ0EsUUFBR0QsTUFBTSxJQUFFLGlDQUFYLEVBQ0E7QUFBRUUsV0FBSyxDQUFDRixNQUFELENBQUw7QUFDRCxhQUFPLEVBQVA7QUFDQSxLQUhELE1BSUk7QUFFSjtBQUNBLGFBQU9BLE1BQVA7QUFDQztBQUVGLEdBakJELENBaUJDLE9BQU1HLENBQU4sRUFBUTtBQUNKQyxXQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNKLFdBQU8sSUFBUDtBQUVBO0FBQ0osQ0F2QkQ7QUF5QkE7OztBQUNBLE1BQU1VLGdCQUFnQixHQUFDLE9BQU1oQixHQUFOLEVBQVVpQixRQUFWLEVBQW1CQyxNQUFuQixLQUE0QjtBQUMvQyxNQUFHO0FBQ0EsUUFBSWpCLFFBQVEsR0FBQyxNQUFNTCxLQUFLLENBQUN1QixJQUFOLENBQVksR0FBRXJCLFNBQVUsSUFBR0UsR0FBSSxFQUEvQixFQUFpQ2lCLFFBQWpDLEVBQTBDQyxNQUExQyxDQUFuQixDQURBLENBRUQ7O0FBQ0MsUUFBR2pCLFFBQVEsQ0FBQ21CLElBQVQsSUFBZSxpQ0FBbEIsRUFDRDtBQUFFZixXQUFLLENBQUNKLFFBQVEsQ0FBQ21CLElBQVYsQ0FBTDtBQUNELGFBQU8sS0FBUDtBQUNBLEtBSEEsTUFJRztBQUVILFlBQU1qQixNQUFNLEdBQUMsTUFBTUYsUUFBUSxDQUFDbUIsSUFBNUI7QUFDQSxhQUFRakIsTUFBUjtBQUNBO0FBRUYsR0FiRCxDQWNBLE9BQU1HLENBQU4sRUFBUTtBQUVOLFdBQU8sSUFBUDtBQUNEO0FBQ0YsQ0FuQkg7O0FBb0JFLE1BQU1lLGVBQWUsR0FBRyxNQUFPQyxHQUFQLElBQWU7QUFDckMsTUFBSTtBQUNGLFFBQUl0QixHQUFHLEdBQUksR0FBRUYsU0FBVSxJQUFHd0IsR0FBSSxFQUE5QjtBQUNBLFVBQU1KLE1BQU0sR0FBRztBQUFFLHNCQUFnQjtBQUFsQixLQUFmO0FBQ0EsVUFBTWpCLFFBQVEsR0FBRyxNQUFNTCxLQUFLLENBQUMyQixNQUFOLENBQWF2QixHQUFiLEVBQWtCa0IsTUFBbEIsQ0FBdkI7QUFDQSxRQUFJZixNQUFNLEdBQUdGLFFBQVEsQ0FBQ21CLElBQXRCO0FBQ0FiLFdBQU8sQ0FBQ0MsR0FBUixDQUFZTCxNQUFaO0FBQ0EsV0FBT0EsTUFBUDtBQUNELEdBUEQsQ0FPRSxPQUFPcUIsS0FBUCxFQUFjO0FBQ2RqQixXQUFPLENBQUNDLEdBQVIsQ0FBWWdCLEtBQVo7QUFDRDtBQUNGLENBWEQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZFRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ2UsU0FBU0MsV0FBVCxHQUF1QjtBQUVsQyxRQUFNO0FBQUEsT0FBQ0MsT0FBRDtBQUFBLE9BQVVDO0FBQVYsTUFBcUJDLHNEQUFRLENBQUMsRUFBRCxDQUFuQztBQUNBLFFBQU07QUFBQSxPQUFDQyxjQUFEO0FBQUEsT0FBaUJDO0FBQWpCLE1BQW1DRixzREFBUSxDQUFDLEVBQUQsQ0FBakQ7QUFDQSxRQUFNO0FBQUEsT0FBQ0csUUFBRDtBQUFBLE9BQVdDO0FBQVgsTUFBcUJKLHNEQUFRLENBQUM7QUFBQ0ssUUFBSSxFQUFDLEVBQU47QUFBVUMsUUFBSSxFQUFDO0FBQWYsR0FBRCxDQUFuQztBQUNBLFFBQU07QUFBQSxPQUFDQyxVQUFEO0FBQUEsT0FBYUM7QUFBYixNQUEyQlIsc0RBQVEsQ0FBQyxFQUFELENBQXpDO0FBRUU7O0FBQ0gsUUFBTVMsV0FBVyxHQUFFQyxLQUFELElBQVM7QUFDMUJOLFlBQVEsQ0FBQztBQUFDQyxVQUFJLEVBQUNNLEdBQUcsQ0FBQ0MsZUFBSixDQUFvQkYsS0FBSyxDQUFDRyxNQUFOLENBQWFDLEtBQWIsQ0FBbUIsQ0FBbkIsQ0FBcEIsQ0FBTjtBQUFpRFIsVUFBSSxFQUFDSSxLQUFLLENBQUNHLE1BQU4sQ0FBYUMsS0FBYixDQUFtQixDQUFuQjtBQUF0RCxLQUFELENBQVI7QUFDRixHQUZDOztBQUlDLFFBQU1DLFlBQVksR0FBQyxZQUFTO0FBRXhCLFFBQUkxQixRQUFRLEdBQUcsSUFBSTJCLFFBQUosRUFBZjtBQUNJM0IsWUFBUSxDQUFDNEIsTUFBVCxDQUFnQixNQUFoQixFQUF1Qm5CLE9BQXZCLEdBQ0FULFFBQVEsQ0FBQzRCLE1BQVQsQ0FBZ0IsYUFBaEIsRUFBOEJoQixjQUE5QixDQURBLEVBRUFaLFFBQVEsQ0FBQzRCLE1BQVQsQ0FBZ0IsT0FBaEIsRUFBd0JkLFFBQVEsQ0FBQ0csSUFBakMsQ0FGQTtBQUdBLFFBQUloQixNQUFNLEdBQUM7QUFBQzRCLFlBQU0sRUFBQztBQUFDLHdCQUFlO0FBQWhCO0FBQVIsS0FBWDtBQUNBLFFBQUkzQyxNQUFNLEdBQUcsTUFBTWEsdUVBQWdCLENBQUMscUJBQUQsRUFBdUJDLFFBQXZCLEVBQWdDQyxNQUFoQyxDQUFuQztBQUNSWCxXQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaLEVBQXFCTCxNQUFyQjs7QUFDSSxRQUFHQSxNQUFILEVBQ0k7QUFBRTtBQUNGaUMsZ0JBQVUsQ0FBQyxrQkFBRCxDQUFWO0FBQ0MsS0FITCxNQUlRO0FBQ1I7QUFDSUEsZ0JBQVUsQ0FBQyx1QkFBRCxDQUFWO0FBQ0M7QUFFUixHQWxCRDs7QUFtQkEsc0JBQ0k7QUFBQSwyQkFDQTtBQUFLLFFBQUUsRUFBQyxrQkFBUjtBQUFBLDhCQUNHO0FBQUssVUFBRSxFQUFDLG1CQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREgsZUFHUTtBQUFLLGFBQUssRUFBQyxVQUFYO0FBQUEsZ0NBQ0k7QUFBSyxlQUFLLEVBQUMsZUFBWDtBQUFBLGtDQUNBO0FBQU8sZUFBRyxFQUFDLG9CQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURBLGVBRUE7QUFBTyxnQkFBSSxFQUFDLE1BQVo7QUFBbUIsaUJBQUssRUFBQyxjQUF6QjtBQUF3QyxjQUFFLEVBQUMsb0JBQTNDO0FBQ0EsaUJBQUssRUFBRVYsT0FEUDtBQUNnQixvQkFBUSxFQUFHWSxLQUFELElBQVNYLE9BQU8sQ0FBQ1csS0FBSyxDQUFDRyxNQUFOLENBQWFNLEtBQWQsQ0FEMUM7QUFDZ0Usb0JBQVE7QUFEeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFGQSxlQUlBO0FBQUssaUJBQUssRUFBQyxnQkFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFKQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREosZUFTSTtBQUFLLGVBQUssRUFBQyxlQUFYO0FBQUEsa0NBQ0E7QUFBTyxlQUFHLEVBQUMsb0JBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREEsZUFFQTtBQUFPLGdCQUFJLEVBQUMsTUFBWjtBQUFtQixpQkFBSyxFQUFDLGNBQXpCO0FBQXdDLGNBQUUsRUFBQyxvQkFBM0M7QUFDQSxpQkFBSyxFQUFFbEIsY0FEUDtBQUN1QixvQkFBUSxFQUFHUyxLQUFELElBQVNSLGNBQWMsQ0FBQ1EsS0FBSyxDQUFDRyxNQUFOLENBQWFNLEtBQWQsQ0FEeEQ7QUFDOEUsb0JBQVE7QUFEdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFGQSxlQUlBO0FBQUssaUJBQUssRUFBQyxnQkFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFKQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSFIsZUFxQlc7QUFBSyxhQUFLLEVBQUMsVUFBWDtBQUFBLCtCQUNDO0FBQUssZUFBSyxFQUFDLGVBQVg7QUFBQSxrQ0FHQTtBQUNLLGtCQUFNLEVBQUMsU0FEWixDQUVJO0FBRko7QUFHSyxjQUFFLEVBQUMsdUJBSFI7QUFJSyxvQkFBUSxNQUpiO0FBS0ssZ0JBQUksRUFBQyxNQUxWO0FBTUksaUJBQUssRUFBRTtBQUFDQyxxQkFBTyxFQUFDO0FBQVQsYUFOWDtBQU9JLG9CQUFRLEVBQUdWLEtBQUQsSUFBU0QsV0FBVyxDQUFDQyxLQUFEO0FBUGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSEEsZUFZQTtBQUFPLG1CQUFPLEVBQUMsdUJBQWY7QUFBQSxtQ0FDSSxxRUFBQywrREFBRDtBQUFRLHFCQUFPLEVBQUMsV0FBaEI7QUFBNEIsbUJBQUssRUFBQyxTQUFsQztBQUE0Qyx1QkFBUyxFQUFDLE1BQXREO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFaQSxlQWlCQSxxRUFBQywrREFBRDtBQUFRLGNBQUUsRUFBQyxRQUFYO0FBQW9CLGlCQUFLLEVBQUU7QUFBQ1csbUJBQUssRUFBQyxFQUFQO0FBQVVDLG9CQUFNLEVBQUM7QUFBakIsYUFBM0I7QUFBaUQsZUFBRyxFQUFFbkIsUUFBUSxDQUFDRTtBQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQWpCQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERDtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBckJYLGVBMkNZLHFFQUFDLCtEQUFEO0FBQVEsZUFBTyxFQUFDLFdBQWhCO0FBQTRCLGFBQUssRUFBQyxTQUFsQztBQUE0QyxlQUFPLEVBQUUsTUFBSVUsWUFBWSxFQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQTNDWixFQStDU1IsVUEvQ1Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREEsbUJBREo7QUFxREgsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pGRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EsU0FBU2dCLFNBQVQsR0FBcUI7QUFDbkIsc0JBQ0UscUVBQUMsbUVBQUQ7QUFBWSxXQUFPLEVBQUMsT0FBcEI7QUFBNEIsU0FBSyxFQUFDLGVBQWxDO0FBQWtELFNBQUssRUFBQyxRQUF4RDtBQUFBLGVBQ0csY0FESCxlQUVFLHFFQUFDLDhEQUFEO0FBQU0sV0FBSyxFQUFDLFNBQVo7QUFBc0IsVUFBSSxFQUFDLDBCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUZGLEVBSVUsR0FKVixFQUtHLElBQUlDLElBQUosR0FBV0MsV0FBWCxFQUxILEVBTUcsR0FOSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQVVEOztBQUVELE1BQU1DLFdBQVcsR0FBRyxHQUFwQjtBQUVBLE1BQU1DLFNBQVMsR0FBR0MsMkVBQVUsQ0FBRUMsS0FBRCxLQUFZO0FBQ3ZDQyxNQUFJLEVBQUU7QUFDSlYsV0FBTyxFQUFFO0FBREwsR0FEaUM7QUFJdkNXLFNBQU8sRUFBRTtBQUNQQyxnQkFBWSxFQUFFLEVBRFAsQ0FDVzs7QUFEWCxHQUo4QjtBQU92Q0MsYUFBVztBQUNUYixXQUFPLEVBQUUsTUFEQTtBQUVUO0FBQ0FjLGtCQUFjLEVBQUUsVUFIUDtBQUlUQyxXQUFPLEVBQUU7QUFKQSxLQUtOTixLQUFLLENBQUNPLE1BQU4sQ0FBYUwsT0FMUCxDQVA0QjtBQWN2Q00sUUFBTSxFQUFFO0FBQ05DLFVBQU0sRUFBRVQsS0FBSyxDQUFDUyxNQUFOLENBQWFDLE1BQWIsR0FBc0IsQ0FEeEI7QUFFTkMsY0FBVSxFQUFFWCxLQUFLLENBQUNZLFdBQU4sQ0FBa0JDLE1BQWxCLENBQXlCLENBQUMsT0FBRCxFQUFVLFFBQVYsQ0FBekIsRUFBOEM7QUFDeERDLFlBQU0sRUFBRWQsS0FBSyxDQUFDWSxXQUFOLENBQWtCRSxNQUFsQixDQUF5QkMsS0FEdUI7QUFFeERDLGNBQVEsRUFBRWhCLEtBQUssQ0FBQ1ksV0FBTixDQUFrQkksUUFBbEIsQ0FBMkJDO0FBRm1CLEtBQTlDO0FBRk4sR0FkK0I7QUFxQnZDQyxhQUFXLEVBQUU7QUFDWEMsY0FBVSxFQUFFdEIsV0FERDtBQUVYTCxTQUFLLEVBQUcsZUFBY0ssV0FBWSxLQUZ2QjtBQUdYYyxjQUFVLEVBQUVYLEtBQUssQ0FBQ1ksV0FBTixDQUFrQkMsTUFBbEIsQ0FBeUIsQ0FBQyxPQUFELEVBQVUsUUFBVixDQUF6QixFQUE4QztBQUN4REMsWUFBTSxFQUFFZCxLQUFLLENBQUNZLFdBQU4sQ0FBa0JFLE1BQWxCLENBQXlCQyxLQUR1QjtBQUV4REMsY0FBUSxFQUFFaEIsS0FBSyxDQUFDWSxXQUFOLENBQWtCSSxRQUFsQixDQUEyQkk7QUFGbUIsS0FBOUM7QUFIRCxHQXJCMEI7QUE2QnZDQyxZQUFVLEVBQUU7QUFDVkMsZUFBVyxFQUFFO0FBREgsR0E3QjJCO0FBZ0N2Q0Msa0JBQWdCLEVBQUU7QUFDaEJoQyxXQUFPLEVBQUU7QUFETyxHQWhDcUI7QUFtQ3ZDaUMsT0FBSyxFQUFFO0FBQ0xDLFlBQVEsRUFBRTtBQURMLEdBbkNnQztBQXNDdkNDLGFBQVcsRUFBRTtBQUNYQyxZQUFRLEVBQUUsVUFEQztBQUVYQyxjQUFVLEVBQUUsUUFGRDtBQUdYcEMsU0FBSyxFQUFFSyxXQUhJO0FBSVhjLGNBQVUsRUFBRVgsS0FBSyxDQUFDWSxXQUFOLENBQWtCQyxNQUFsQixDQUF5QixPQUF6QixFQUFrQztBQUM1Q0MsWUFBTSxFQUFFZCxLQUFLLENBQUNZLFdBQU4sQ0FBa0JFLE1BQWxCLENBQXlCQyxLQURXO0FBRTVDQyxjQUFRLEVBQUVoQixLQUFLLENBQUNZLFdBQU4sQ0FBa0JJLFFBQWxCLENBQTJCSTtBQUZPLEtBQWxDO0FBSkQsR0F0QzBCO0FBK0N2Q1Msa0JBQWdCLEVBQUU7QUFDaEJDLGFBQVMsRUFBRSxRQURLO0FBRWhCbkIsY0FBVSxFQUFFWCxLQUFLLENBQUNZLFdBQU4sQ0FBa0JDLE1BQWxCLENBQXlCLE9BQXpCLEVBQWtDO0FBQzVDQyxZQUFNLEVBQUVkLEtBQUssQ0FBQ1ksV0FBTixDQUFrQkUsTUFBbEIsQ0FBeUJDLEtBRFc7QUFFNUNDLGNBQVEsRUFBRWhCLEtBQUssQ0FBQ1ksV0FBTixDQUFrQkksUUFBbEIsQ0FBMkJDO0FBRk8sS0FBbEMsQ0FGSTtBQU1oQnpCLFNBQUssRUFBRVEsS0FBSyxDQUFDK0IsT0FBTixDQUFjLENBQWQsQ0FOUztBQU9oQixLQUFDL0IsS0FBSyxDQUFDZ0MsV0FBTixDQUFrQkMsRUFBbEIsQ0FBcUIsSUFBckIsQ0FBRCxHQUE4QjtBQUM1QnpDLFdBQUssRUFBRVEsS0FBSyxDQUFDK0IsT0FBTixDQUFjLENBQWQ7QUFEcUI7QUFQZCxHQS9DcUI7QUEwRHZDRyxjQUFZLEVBQUVsQyxLQUFLLENBQUNPLE1BQU4sQ0FBYUwsT0ExRFk7QUEyRHZDaUMsU0FBTyxFQUFFO0FBQ1BWLFlBQVEsRUFBRSxDQURIO0FBRVBoQyxVQUFNLEVBQUUsT0FGRDtBQUdQMkMsWUFBUSxFQUFFO0FBSEgsR0EzRDhCO0FBZ0V2Q0MsV0FBUyxFQUFFO0FBQ1RDLGNBQVUsRUFBRXRDLEtBQUssQ0FBQytCLE9BQU4sQ0FBYyxDQUFkLENBREg7QUFFVFEsaUJBQWEsRUFBRXZDLEtBQUssQ0FBQytCLE9BQU4sQ0FBYyxDQUFkLENBRk4sQ0FHVDs7QUFIUyxHQWhFNEI7QUFxRXZDUyxPQUFLLEVBQUU7QUFDTGxDLFdBQU8sRUFBRU4sS0FBSyxDQUFDK0IsT0FBTixDQUFjLENBQWQsQ0FESjtBQUVMeEMsV0FBTyxFQUFFLE1BRko7QUFHTDZDLFlBQVEsRUFBRSxNQUhMO0FBSUxLLGlCQUFhLEVBQUU7QUFKVixHQXJFZ0M7QUEyRXZDQyxhQUFXLEVBQUU7QUFDWGpELFVBQU0sRUFBRTtBQURHO0FBM0UwQixDQUFaLENBQUQsQ0FBNUI7QUFnRmUsU0FBU2tELFNBQVQsQ0FBbUJDLEtBQW5CLEVBQTBCO0FBQ3ZDLFFBQU1DLE9BQU8sR0FBRy9DLFNBQVMsRUFBekI7QUFDQSxRQUFNLENBQUNnRCxJQUFELEVBQU9DLE9BQVAsSUFBa0JDLDRDQUFLLENBQUM3RSxRQUFOLENBQWUsSUFBZixDQUF4QjtBQUNBLFFBQU0sQ0FBQzhFLGNBQUQsRUFBaUJDLFdBQWpCLElBQStCRiw0Q0FBSyxDQUFDN0UsUUFBTixlQUFlLHFFQUFDLGlEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFBZixDQUFyQyxDQUh1QyxDQUl6QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7O0FBRUUsUUFBTWdGLGdCQUFnQixHQUFDLE1BQU1DLFFBQU4sSUFBaUI7QUFDdEMsWUFBT0EsUUFBUDtBQUNFLFdBQUssQ0FBTDtBQUNFdEcsZUFBTyxDQUFDQyxHQUFSLENBQVksR0FBWixFQUFnQixDQUFoQjtBQUNGbUcsbUJBQVcsZUFBQyxxRUFBQyxpREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUFELENBQVg7QUFDQTs7QUFDQSxXQUFLLENBQUw7QUFDQUEsbUJBQVcsZUFBQyxxRUFBQyxxREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUFELENBQVg7QUFDQTs7QUFDQSxXQUFLLENBQUw7QUFDQUEsbUJBQVcsZUFBQyxxRUFBQywrREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUFELENBQVg7QUFDQTtBQVZGO0FBWUQsR0FiRDs7QUFlQSxRQUFNRyxnQkFBZ0IsR0FBRyxNQUFNO0FBQzdCTixXQUFPLENBQUMsSUFBRCxDQUFQO0FBQ0QsR0FGRDs7QUFJQSxRQUFNTyxpQkFBaUIsR0FBRyxNQUFNO0FBQzlCUCxXQUFPLENBQUMsS0FBRCxDQUFQO0FBQ0QsR0FGRDs7QUFJQSxRQUFNUSxnQkFBZ0IsR0FBR0MsMkNBQUksQ0FBQ1gsT0FBTyxDQUFDTCxLQUFULEVBQWdCSyxPQUFPLENBQUNILFdBQXhCLENBQTdCO0FBRUEsc0JBQ0U7QUFBQSw0QkFDRSxxRUFBQyxvRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFFRSxxRUFBQywrREFBRDtBQUFRLGNBQVEsRUFBQyxVQUFqQjtBQUE0QixlQUFTLEVBQUVjLDJDQUFJLENBQUNYLE9BQU8sQ0FBQ3JDLE1BQVQsRUFBaUJzQyxJQUFJLElBQUlELE9BQU8sQ0FBQzNCLFdBQWpDLENBQTNDO0FBQUEsNkJBQ0UscUVBQUMsaUVBQUQ7QUFBUyxpQkFBUyxFQUFFMkIsT0FBTyxDQUFDM0MsT0FBNUI7QUFBQSxnQ0FDRSxxRUFBQyxvRUFBRDtBQUNFLGNBQUksRUFBQyxPQURQO0FBRUUsZUFBSyxFQUFDLFNBRlI7QUFHRSx3QkFBVyxhQUhiO0FBSUUsaUJBQU8sRUFBRW1ELGdCQUpYO0FBS0UsbUJBQVMsRUFBRUcsMkNBQUksQ0FBQ1gsT0FBTyxDQUFDeEIsVUFBVCxFQUFxQnlCLElBQUksSUFBSUQsT0FBTyxDQUFDdEIsZ0JBQXJDLENBTGpCO0FBQUEsaUNBT0UscUVBQUMsK0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUFVRSxxRUFBQyxtRUFBRDtBQUFZLG1CQUFTLEVBQUMsSUFBdEI7QUFBMkIsaUJBQU8sRUFBQyxJQUFuQztBQUF3QyxlQUFLLEVBQUMsU0FBOUM7QUFBd0QsZ0JBQU0sTUFBOUQ7QUFBK0QsbUJBQVMsRUFBRXNCLE9BQU8sQ0FBQ3JCLEtBQWxGO0FBQUEsaUNBQ0E7QUFBSyxxQkFBUyxFQUFFcUIsT0FBTyxDQUFDWSxPQUF4QjtBQUFBLG1DQUlJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFWRixlQW9CRSxxRUFBQyxnRUFBRDtBQUFRLGFBQUcsRUFBQyxZQUFaO0FBQXlCLG1CQUFTLEVBQUVaLE9BQU8sQ0FBQ2E7QUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUZGLGVBaUNFLHFFQUFDLGdFQUFEO0FBQ0UsYUFBTyxFQUFDLFdBRFY7QUFFRSxhQUFPLEVBQUU7QUFDUGxCLGFBQUssRUFBRWdCLDJDQUFJLENBQUNYLE9BQU8sQ0FBQ25CLFdBQVQsRUFBc0IsQ0FBQ29CLElBQUQsSUFBU0QsT0FBTyxDQUFDaEIsZ0JBQXZDO0FBREosT0FGWDtBQUtFLFVBQUksRUFBRWlCLElBTFI7QUFBQSw4QkFPRTtBQUFLLGlCQUFTLEVBQUVELE9BQU8sQ0FBQ3pDLFdBQXhCO0FBQUEsK0JBQ0UscUVBQUMsb0VBQUQ7QUFBWSxpQkFBTyxFQUFFa0QsaUJBQXJCO0FBQUEsaUNBQ0UscUVBQUMsc0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUEYsZUFhRSxxRUFBQyxpRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBYkYsZUFjRSxxRUFBQyw4REFBRDtBQUFBLCtCQUFNLHFFQUFDLG1EQUFEO0FBQVcsMkJBQWlCLEVBQUVIO0FBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBakNGLGVBaURFO0FBQU0sZUFBUyxFQUFFTixPQUFPLENBQUNWLE9BQXpCO0FBQUEsOEJBQ0U7QUFBSyxpQkFBUyxFQUFFVSxPQUFPLENBQUNYO0FBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQUVJLHFFQUFDLG1FQUFEO0FBQVcsZ0JBQVEsRUFBQyxJQUFwQjtBQUF5QixpQkFBUyxFQUFFVyxPQUFPLENBQUNSLFNBQTVDO0FBQUEsZ0NBQ0UscUVBQUMsOERBQUQ7QUFBTSxtQkFBUyxNQUFmO0FBQWdCLGlCQUFPLEVBQUUsQ0FBekI7QUFBQSxpQ0FDRSxxRUFBQyw4REFBRDtBQUFNLGdCQUFJLE1BQVY7QUFBVyxjQUFFLEVBQUUsRUFBZjtBQUFtQixjQUFFLEVBQUUsRUFBdkI7QUFBQSxzQkFDQ1k7QUFERDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQU1DO0FBQUEsaUNBQ0MscUVBQUMsNkRBQUQ7QUFBSyxjQUFFLEVBQUUsRUFBVDtBQUFBLG1DQUNFLHFFQUFDLFNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERDtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWpERjtBQUFBLGtCQURGO0FBbUVHLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDek9MO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRWdCLFNBQVNVLHNCQUFULEdBQWtDO0FBQ2hELFFBQU07QUFBQSxPQUFDaEcsSUFBRDtBQUFBLE9BQU9pRztBQUFQLE1BQWtCekYsc0RBQVEsQ0FBQyxFQUFELENBQWhDO0FBQ0EsUUFBTTtBQUFBLE9BQUMyRSxJQUFEO0FBQUEsT0FBT0M7QUFBUCxNQUFrQjVFLHNEQUFRLENBQUMsS0FBRCxDQUFoQztBQUNBLFFBQU07QUFBQSxPQUFDMEYsYUFBRDtBQUFBLE9BQWdCQztBQUFoQixNQUFnQzNGLHNEQUFRLENBQUMsRUFBRCxDQUE5QztBQUNBLFFBQU07QUFBQSxPQUFDRixPQUFEO0FBQUEsT0FBVUM7QUFBVixNQUFxQkMsc0RBQVEsQ0FBQyxFQUFELENBQW5DO0FBQ0EsUUFBTTtBQUFBLE9BQUNDLGNBQUQ7QUFBQSxPQUFpQkM7QUFBakIsTUFBbUNGLHNEQUFRLENBQUMsRUFBRCxDQUFqRDtBQUNBLFFBQU07QUFBQSxPQUFDRyxRQUFEO0FBQUEsT0FBV0M7QUFBWCxNQUFxQkosc0RBQVEsQ0FBQztBQUFDSyxRQUFJLEVBQUMsRUFBTjtBQUFVQyxRQUFJLEVBQUM7QUFBZixHQUFELENBQW5DO0FBQ0EsUUFBTTtBQUFBLE9BQUNDLFVBQUQ7QUFBQSxPQUFhQztBQUFiLE1BQTJCUixzREFBUSxDQUFDLEVBQUQsQ0FBekM7QUFDQSxRQUFNO0FBQUEsT0FBQzRGLFVBQUQ7QUFBQSxPQUFhQztBQUFiLE1BQTJCN0Ysc0RBQVEsQ0FBQztBQUN4QzhGLFdBQU8sRUFBQyxDQUNSO0FBQUV6QyxXQUFLLEVBQUUsTUFBVDtBQUFpQjBDLFdBQUssRUFBRTtBQUF4QixLQURRLEVBRVI7QUFBRTFDLFdBQUssRUFBRSxhQUFUO0FBQXdCMEMsV0FBSyxFQUFFO0FBQS9CLEtBRlEsRUFHUjtBQUFFMUMsV0FBSyxFQUFFLE9BQVQ7QUFBa0IwQyxXQUFLLEVBQUUsT0FBekI7QUFDQUMsWUFBTSxFQUFHQyxPQUFELGlCQUNKO0FBQUEsK0JBQ0UscUVBQUMsK0RBQUQ7QUFDRSxpQkFBTyxFQUFDLFNBRFY7QUFFRSxhQUFHLEVBQUcsR0FBRS9ILHdEQUFVLFdBQVUrSCxPQUFPLENBQUNDLEtBQU07QUFGNUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFGSixLQUhRO0FBRGdDLEdBQUQsQ0FBekM7O0FBaUJBLFFBQU1DLFNBQVMsR0FBRyxZQUFZO0FBQzVCLFVBQU01SCxNQUFNLEdBQUcsTUFBTUosOERBQU8sQ0FBQyxxQkFBRCxDQUE1QjtBQUNBUSxXQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaLEVBQW1CTCxNQUFuQjtBQUNBQSxVQUFNLENBQUM2SCxNQUFQLElBQWlCWCxPQUFPLENBQUNsSCxNQUFNLENBQUNBLE1BQVIsQ0FBeEI7QUFDRCxHQUpEOztBQU1BOEgseURBQVMsQ0FBQyxNQUFNO0FBQ2RGLGFBQVM7QUFDVixHQUZRLEVBRU4sRUFGTSxDQUFUOztBQUlBLFFBQU1HLFdBQVcsR0FBRyxNQUFNO0FBQ3hCMUIsV0FBTyxDQUFDLEtBQUQsQ0FBUCxDQUR3QixDQUV4QjtBQUNELEdBSEQ7QUFLQTs7O0FBQ0EsUUFBTW5FLFdBQVcsR0FBSUMsS0FBRCxJQUFXO0FBQzdCTixZQUFRLENBQUM7QUFDUEMsVUFBSSxFQUFFTSxHQUFHLENBQUNDLGVBQUosQ0FBb0JGLEtBQUssQ0FBQ0csTUFBTixDQUFhQyxLQUFiLENBQW1CLENBQW5CLENBQXBCLENBREM7QUFFUFIsVUFBSSxFQUFFSSxLQUFLLENBQUNHLE1BQU4sQ0FBYUMsS0FBYixDQUFtQixDQUFuQjtBQUZDLEtBQUQsQ0FBUjtBQUlELEdBTEQ7O0FBT0EsUUFBTXlGLFlBQVksR0FBSU4sT0FBRCxJQUFhO0FBQ2hDTixpQkFBYSxDQUFDTSxPQUFPLENBQUNPLGVBQVQsQ0FBYjtBQUNBekcsV0FBTyxDQUFDa0csT0FBTyxDQUFDUSxJQUFULENBQVA7QUFDQXZHLGtCQUFjLENBQUMrRixPQUFPLENBQUNTLFdBQVQsQ0FBZDtBQUNBdEcsWUFBUSxDQUFDO0FBQUVDLFVBQUksRUFBRyxHQUFFbkMsd0RBQVUsV0FBVStILE9BQU8sQ0FBQ0MsS0FBTSxFQUE3QztBQUFnRDVGLFVBQUksRUFBRTtBQUF0RCxLQUFELENBQVI7QUFDQXNFLFdBQU8sQ0FBQyxJQUFELENBQVA7QUFDRCxHQU5ELENBaERnRCxDQXdEaEQ7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLFFBQU0rQixZQUFZLEdBQUcsTUFBT0MsT0FBUCxJQUFtQjtBQUN0QztBQUNFLFVBQU1uSCxzRUFBZSxDQUFFLHNCQUFxQm1ILE9BQU8sQ0FBQ0osZUFBZ0IsRUFBL0MsQ0FBckI7QUFDSCxHQUhEOztBQU1BLFFBQU1LLFlBQVksR0FBRyxNQUFPbkksQ0FBUCxJQUFhO0FBRTVCLFFBQUlXLFFBQVEsR0FBRyxJQUFJMkIsUUFBSixFQUFmO0FBQ0kzQixZQUFRLENBQUM0QixNQUFULENBQWdCLGlCQUFoQixFQUFrQ3lFLGFBQWxDO0FBQ0FyRyxZQUFRLENBQUM0QixNQUFULENBQWdCLE1BQWhCLEVBQXVCbkIsT0FBdkIsR0FDQVQsUUFBUSxDQUFDNEIsTUFBVCxDQUFnQixhQUFoQixFQUE4QmhCLGNBQTlCLENBREEsRUFFQVosUUFBUSxDQUFDNEIsTUFBVCxDQUFnQixPQUFoQixFQUF3QmQsUUFBUSxDQUFDRyxJQUFqQyxDQUZBO0FBR0EsUUFBSWhCLE1BQU0sR0FBQztBQUFDNEIsWUFBTSxFQUFDO0FBQUMsd0JBQWU7QUFBaEI7QUFBUixLQUFYLENBUHdCLENBUXhCO0FBQ0E7O0FBQ0EsUUFBSTNDLE1BQU0sR0FBRyxNQUFNYSx1RUFBZ0IsQ0FBRSxzQkFBcUJzRyxhQUFjLEVBQXJDLEVBQXVDckcsUUFBdkMsRUFBZ0RDLE1BQWhELENBQW5DO0FBQ1I2RyxhQUFTO0FBQ1RHLGVBQVc7O0FBRVgsUUFBRy9ILE1BQUgsRUFDQTtBQUFFO0FBQ0ZpQyxnQkFBVSxDQUFDLGdCQUFELENBQVY7QUFDQyxLQUhELE1BSUk7QUFDUjtBQUNJQSxnQkFBVSxDQUFDLHVCQUFELENBQVY7QUFDQztBQUVGLEdBdkJEOztBQXlCQSxRQUFNc0csY0FBYyxHQUFJcEksQ0FBRCxJQUFPO0FBQzVCLFVBQU1xSSxLQUFLLEdBQUc7QUFDWjFGLFdBQUssRUFBRSxHQURLO0FBRVpjLGFBQU8sRUFBRSxFQUZHO0FBR1o2RSxrQkFBWSxFQUFFLENBSEY7QUFJWkMsZUFBUyxFQUFFO0FBSkMsS0FBZDtBQU1BLHdCQUNKO0FBQUssUUFBRSxFQUFDLDBCQUFSO0FBQUEsOEJBQ1c7QUFBSyxVQUFFLEVBQUMsbUJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FEWCxlQUVnQjtBQUFLLGFBQUssRUFBQyxVQUFYO0FBQUEsZ0NBQ0k7QUFBSyxlQUFLLEVBQUMsZUFBWDtBQUFBLGtDQUNBO0FBQU8sZUFBRyxFQUFDLG9CQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURBLGVBRUE7QUFBTyxnQkFBSSxFQUFDLE1BQVo7QUFBbUIsaUJBQUssRUFBQyxjQUF6QjtBQUF3QyxjQUFFLEVBQUMsb0JBQTNDO0FBQ0EsaUJBQUssRUFBRW5ILE9BRFA7QUFDZ0Isb0JBQVEsRUFBR1ksS0FBRCxJQUFTWCxPQUFPLENBQUNXLEtBQUssQ0FBQ0csTUFBTixDQUFhTSxLQUFkLENBRDFDO0FBQ2dFLG9CQUFRO0FBRHhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRkEsZUFJQTtBQUFLLGlCQUFLLEVBQUMsZ0JBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURKLGVBU0k7QUFBSyxlQUFLLEVBQUMsZUFBWDtBQUFBLGtDQUNBO0FBQU8sZUFBRyxFQUFDLG9CQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURBLGVBRUE7QUFBTyxnQkFBSSxFQUFDLE1BQVo7QUFBbUIsaUJBQUssRUFBQyxjQUF6QjtBQUF3QyxjQUFFLEVBQUMsb0JBQTNDO0FBQ0EsaUJBQUssRUFBRWxCLGNBRFA7QUFDdUIsb0JBQVEsRUFBR1MsS0FBRCxJQUFTUixjQUFjLENBQUNRLEtBQUssQ0FBQ0csTUFBTixDQUFhTSxLQUFkLENBRHhEO0FBQzhFLG9CQUFRO0FBRHRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRkEsZUFJQTtBQUFLLGlCQUFLLEVBQUMsZ0JBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZoQixlQW9CbUI7QUFBSyxhQUFLLEVBQUMsVUFBWDtBQUFBLCtCQUNDO0FBQUssZUFBSyxFQUFDLGVBQVg7QUFBQSxrQ0FHQTtBQUNLLGtCQUFNLEVBQUMsU0FEWixDQUVJO0FBRko7QUFHSyxjQUFFLEVBQUMsdUJBSFI7QUFJSyxvQkFBUSxNQUpiO0FBS0ssZ0JBQUksRUFBQyxNQUxWO0FBTUksaUJBQUssRUFBRTtBQUFDQyxxQkFBTyxFQUFDO0FBQVQsYUFOWDtBQU9JLG9CQUFRLEVBQUdWLEtBQUQsSUFBU0QsV0FBVyxDQUFDQyxLQUFEO0FBUGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSEEsZUFZQTtBQUFPLG1CQUFPLEVBQUMsdUJBQWY7QUFBQSxtQ0FDSSxxRUFBQywrREFBRDtBQUFRLHFCQUFPLEVBQUMsV0FBaEI7QUFBNEIsbUJBQUssRUFBQyxTQUFsQztBQUE0Qyx1QkFBUyxFQUFDLE1BQXREO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFaQSxlQWlCQSxxRUFBQywrREFBRDtBQUFRLGNBQUUsRUFBQyxnQkFBWDtBQUE0QixpQkFBSyxFQUFFO0FBQUNXLG1CQUFLLEVBQUMsRUFBUDtBQUFVQyxvQkFBTSxFQUFDO0FBQWpCLGFBQW5DO0FBQXlELGVBQUcsRUFBRW5CLFFBQVEsQ0FBQ0U7QUFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFqQkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXBCbkIsZUEwQ29CLHFFQUFDLCtEQUFEO0FBQVEsZUFBTyxFQUFDLFdBQWhCO0FBQTRCLGFBQUssRUFBQyxTQUFsQztBQUE0Qyx3QkFBZ0IsTUFBNUQ7QUFBNkQsVUFBRSxFQUFDLGFBQWhFO0FBQThFLGVBQU8sRUFBRSxNQUFJd0csWUFBWSxFQUF2RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQTFDcEIsZUE4Q2dCO0FBQUEsZ0NBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQUVFO0FBQUEsaUNBQVE7QUFBQSxzQkFBSXRHO0FBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBOUNoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFESTtBQXNERCxHQTdERDs7QUErREEsc0JBQ0U7QUFBQSw0QkFDRSxxRUFBQyxxREFBRDtBQUNFLFdBQUssRUFBQyxrQkFEUjtBQUVFLGFBQU8sRUFBRXFGLFVBQVUsQ0FBQ0UsT0FGdEI7QUFHRSxVQUFJLEVBQUV0RyxJQUhSO0FBSUUsYUFBTyxFQUFFO0FBQ1AwSCxtQkFBVyxFQUFFO0FBQ1hDLHlCQUFlLEVBQUUsU0FETjtBQUVYQyxlQUFLLEVBQUU7QUFGSSxTQUROO0FBS1BDLHdCQUFnQixFQUFFO0FBQ2hCbEYsaUJBQU8sRUFBRTtBQURPO0FBTFgsT0FKWDtBQWFFLGFBQU8sRUFBRSxDQUNQO0FBQ0U5QixZQUFJLEVBQUUsTUFEUjtBQUVFaUgsZUFBTyxFQUFFLE1BRlg7QUFHRUMsZUFBTyxFQUFFLENBQUM3RyxLQUFELEVBQVF1RixPQUFSLEtBQW9CO0FBQzNCTSxzQkFBWSxDQUFDTixPQUFELENBQVo7QUFDRDtBQUxILE9BRE8sQ0FiWDtBQXNCRSxjQUFRLEVBQUU7QUFDUnVCLG1CQUFXLEVBQUdaLE9BQUQsSUFDWCxJQUFJYSxPQUFKLENBQVksQ0FBQ0MsT0FBRCxFQUFVQyxNQUFWLEtBQXFCO0FBQy9CQyxvQkFBVSxDQUFDLE1BQU07QUFDZixrQkFBTUMsVUFBVSxHQUFHLENBQUMsR0FBR3JJLElBQUosQ0FBbkI7QUFDQSxrQkFBTXNJLEtBQUssR0FBR2xCLE9BQU8sQ0FBQ21CLFNBQVIsQ0FBa0JDLEVBQWhDO0FBQ0FILHNCQUFVLENBQUNJLE1BQVgsQ0FBa0JILEtBQWxCLEVBQXlCLENBQXpCO0FBQ0FyQyxtQkFBTyxDQUFDLENBQUMsR0FBR29DLFVBQUosQ0FBRCxDQUFQO0FBQ0FsQix3QkFBWSxDQUFDQyxPQUFELENBQVo7QUFDQWMsbUJBQU87QUFDUixXQVBTLEVBT1AsSUFQTyxDQUFWO0FBUUQsU0FURDtBQUZNO0FBdEJaO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQXFDRSxxRUFBQyx3REFBRCxDQUNFO0FBREY7QUFFRSxjQUFRLEVBQUMsSUFGWDtBQUdFLFVBQUksRUFBRS9DLElBSFI7QUFJRSxhQUFPLEVBQUUyQixXQUpYO0FBS0UseUJBQWdCLHlCQUxsQjtBQUFBLGdCQU9HUSxjQUFjO0FBUGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFyQ0Y7QUFBQSxrQkFERjtBQWlERDtBQUVELE1BQU1DLEtBQUssR0FBRztBQUNabUIsVUFBUSxFQUFFLEtBREU7QUFFWkMsUUFBTSxFQUFFLFdBRkk7QUFHWm5CLGNBQVksRUFBRSxDQUhGO0FBSVpDLFdBQVMsRUFBRTtBQUpDLENBQWQsQyxDQU9BO0FBQ0E7QUFDQSxLOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbE9BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNdEYsU0FBUyxHQUFHQyw0RUFBVSxDQUFDQyxLQUFLLEtBQUcsRUFBSCxDQUFOLENBQTVCO0FBR2UsU0FBU3VHLFNBQVQsQ0FBbUIzRCxLQUFuQixFQUF5QjtBQUN0QyxRQUFNQyxPQUFPLEdBQUcvQyxTQUFTLEVBQXpCO0FBQ0EsUUFBTSxDQUFDZ0QsSUFBRCxFQUFPQyxPQUFQLElBQWtCQyw0Q0FBSyxDQUFDN0UsUUFBTixDQUFlLEtBQWYsQ0FBeEI7QUFDQSxRQUFNLENBQUNxSSxLQUFELEVBQVFDLFFBQVIsSUFBb0J6RCw0Q0FBSyxDQUFDN0UsUUFBTixDQUFlLEtBQWYsQ0FBMUI7QUFDQSxRQUFNLENBQUN1SSxPQUFELEVBQVVDLFVBQVYsSUFBd0IzRCw0Q0FBSyxDQUFDN0UsUUFBTixDQUFlLEtBQWYsQ0FBOUI7QUFDQSxRQUFNLENBQUN5SSxLQUFELEVBQVFDLFFBQVIsSUFBb0I3RCw0Q0FBSyxDQUFDN0UsUUFBTixDQUFlLEtBQWYsQ0FBMUIsQ0FMc0MsQ0FNdEM7O0FBRUMsUUFBTTJJLGVBQWUsR0FBRUMsUUFBRCxJQUFZO0FBQ2hDLFFBQUdBLFFBQVEsSUFBSSxjQUFmLEVBQThCO0FBQzdCaEUsYUFBTyxDQUFDLENBQUNELElBQUYsQ0FBUDtBQUNBLEtBRkQsTUFHTSxJQUFHaUUsUUFBUSxJQUFJLFlBQWYsRUFBNEI7QUFDL0JOLGNBQVEsQ0FBQyxDQUFDRCxLQUFGLENBQVI7QUFDRCxLQUZJLE1BR0EsSUFBR08sUUFBUSxJQUFJLGNBQWYsRUFBOEI7QUFDakNKLGdCQUFVLENBQUMsQ0FBQ0QsT0FBRixDQUFWO0FBQ0QsS0FGSSxNQUdBLElBQUdLLFFBQVEsSUFBSSxZQUFmLEVBQTRCO0FBQy9CRixjQUFRLENBQUMsQ0FBQ0QsS0FBRixDQUFSO0FBQ0Q7QUFDSCxHQWJEOztBQWdCRCxRQUFNSSxXQUFXLEdBQUVDLFFBQUQsSUFBWTtBQUM5QnJFLFNBQUssQ0FBQ3NFLGlCQUFOLENBQXdCRCxRQUF4QjtBQUNDLEdBRkQ7O0FBSUYsc0JBQ0U7QUFBQSw0QkFDRSxxRUFBQyxpRUFBRDtBQUFVLFlBQU0sTUFBaEI7QUFBa0IsYUFBTyxFQUFFLE1BQUlELFdBQVcsQ0FBQyxDQUFELENBQTFDO0FBQUEsOEJBQ0UscUVBQUMscUVBQUQ7QUFBQSwrQkFDRSxxRUFBQyxtRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBSUUscUVBQUMscUVBQUQ7QUFBYyxlQUFPLEVBQUM7QUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGLGVBUUUscUVBQUMsaUVBQUQ7QUFBVSxZQUFNLE1BQWhCO0FBQWlCLGFBQU8sRUFBRSxNQUFJRixlQUFlLENBQUMsY0FBRCxDQUE3QztBQUFBLDhCQUNFLHFFQUFDLHFFQUFEO0FBQUEsK0JBQ0UscUVBQUMsc0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQUlFLHFFQUFDLHFFQUFEO0FBQWMsZUFBTyxFQUFDO0FBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FKRixFQUtLaEUsSUFBSSxnQkFBRyxxRUFBQyxxRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBQUgsZ0JBQW9CLHFFQUFDLHFFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FMN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUkYsZUFlRSxxRUFBQyxrRUFBRDtBQUFVLFFBQUUsRUFBRUEsSUFBZDtBQUFvQixhQUFPLEVBQUMsTUFBNUI7QUFBbUMsbUJBQWEsTUFBaEQ7QUFBQSw2QkFDSSxxRUFBQyw4REFBRDtBQUFNLGlCQUFTLEVBQUMsS0FBaEI7QUFBc0Isc0JBQWMsTUFBcEM7QUFBQSxnQ0FDRSxxRUFBQyxpRUFBRDtBQUFVLGdCQUFNLE1BQWhCO0FBQWlCLG1CQUFTLEVBQUVELE9BQU8sQ0FBQ3NFLE1BQXBDO0FBQTRDLGlCQUFPLEVBQUUsTUFBSUgsV0FBVyxDQUFDLENBQUQsQ0FBcEU7QUFBQSxrQ0FDRSxxRUFBQyxxRUFBRDtBQUFBLG1DQUNFLHFFQUFDLHFFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURGLGVBSUUscUVBQUMscUVBQUQ7QUFBYyxtQkFBTyxFQUFDO0FBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBUUUscUVBQUMsaUVBQUQ7QUFBVSxnQkFBTSxNQUFoQjtBQUFpQixtQkFBUyxFQUFFbkUsT0FBTyxDQUFDc0UsTUFBcEM7QUFBNEMsaUJBQU8sRUFBRSxNQUFJSCxXQUFXLENBQUMsQ0FBRCxDQUFwRTtBQUFBLGtDQUNFLHFFQUFDLHFFQUFEO0FBQUEsbUNBQ0UscUVBQUMscUVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREYsZUFJRSxxRUFBQyxxRUFBRDtBQUFjLG1CQUFPLEVBQUM7QUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBaUpDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcE1EO0FBRWUsU0FBU0ksUUFBVCxHQUFvQjtBQUMvQixzQkFDSTtBQUFBO0FBQUEsbUJBREo7QUFNSCxDOzs7Ozs7Ozs7OztBQ1RELDhDOzs7Ozs7Ozs7OztBQ0FBLHFEOzs7Ozs7Ozs7OztBQ0FBLHFEOzs7Ozs7Ozs7OztBQ0FBLG9EOzs7Ozs7Ozs7OztBQ0FBLGtEOzs7Ozs7Ozs7OztBQ0FBLHFEOzs7Ozs7Ozs7OztBQ0FBLHVEOzs7Ozs7Ozs7OztBQ0FBLHdEOzs7Ozs7Ozs7OztBQ0FBLDBEOzs7Ozs7Ozs7OztBQ0FBLHNEOzs7Ozs7Ozs7OztBQ0FBLHFEOzs7Ozs7Ozs7OztBQ0FBLG1EOzs7Ozs7Ozs7OztBQ0FBLHlEOzs7Ozs7Ozs7OztBQ0FBLG1EOzs7Ozs7Ozs7OztBQ0FBLG1EOzs7Ozs7Ozs7OztBQ0FBLHVEOzs7Ozs7Ozs7OztBQ0FBLDJEOzs7Ozs7Ozs7OztBQ0FBLDJEOzs7Ozs7Ozs7OztBQ0FBLDREOzs7Ozs7Ozs7OztBQ0FBLG9EOzs7Ozs7Ozs7OztBQ0FBLHNEOzs7Ozs7Ozs7OztBQ0FBLHlEOzs7Ozs7Ozs7OztBQ0FBLHFEOzs7Ozs7Ozs7OztBQ0FBLDBEOzs7Ozs7Ozs7OztBQ0FBLHdEOzs7Ozs7Ozs7OztBQ0FBLDJEOzs7Ozs7Ozs7OztBQ0FBLHlEOzs7Ozs7Ozs7OztBQ0FBLHNEOzs7Ozs7Ozs7OztBQ0FBLDBEOzs7Ozs7Ozs7OztBQ0FBLDBEOzs7Ozs7Ozs7OztBQ0FBLHNEOzs7Ozs7Ozs7OztBQ0FBLG9EOzs7Ozs7Ozs7OztBQ0FBLDJEOzs7Ozs7Ozs7OztBQ0FBLHNEOzs7Ozs7Ozs7OztBQ0FBLG9EOzs7Ozs7Ozs7OztBQ0FBLDREOzs7Ozs7Ozs7OztBQ0FBLDBEOzs7Ozs7Ozs7OztBQ0FBLGtDOzs7Ozs7Ozs7OztBQ0FBLGlDOzs7Ozs7Ozs7OztBQ0FBLDJDOzs7Ozs7Ozs7OztBQ0FBLGtDOzs7Ozs7Ozs7OztBQ0FBLGtEOzs7Ozs7Ozs7OztBQ0FBLHdDIiwiZmlsZSI6InBhZ2VzL0FkbWluL0Rhc2hib2FyZC5qcyIsInNvdXJjZXNDb250ZW50IjpbIiBcdC8vIFRoZSBtb2R1bGUgY2FjaGVcbiBcdHZhciBpbnN0YWxsZWRNb2R1bGVzID0gcmVxdWlyZSgnLi4vLi4vc3NyLW1vZHVsZS1jYWNoZS5qcycpO1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHR2YXIgdGhyZXcgPSB0cnVlO1xuIFx0XHR0cnkge1xuIFx0XHRcdG1vZHVsZXNbbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuIFx0XHRcdHRocmV3ID0gZmFsc2U7XG4gXHRcdH0gZmluYWxseSB7XG4gXHRcdFx0aWYodGhyZXcpIGRlbGV0ZSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXTtcbiBcdFx0fVxuXG4gXHRcdC8vIEZsYWcgdGhlIG1vZHVsZSBhcyBsb2FkZWRcbiBcdFx0bW9kdWxlLmwgPSB0cnVlO1xuXG4gXHRcdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG4gXHRcdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbiBcdH1cblxuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tID0gbW9kdWxlcztcblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGUgY2FjaGVcbiBcdF9fd2VicGFja19yZXF1aXJlX18uYyA9IGluc3RhbGxlZE1vZHVsZXM7XG5cbiBcdC8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb24gZm9yIGhhcm1vbnkgZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kID0gZnVuY3Rpb24oZXhwb3J0cywgbmFtZSwgZ2V0dGVyKSB7XG4gXHRcdGlmKCFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywgbmFtZSkpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgbmFtZSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGdldHRlciB9KTtcbiBcdFx0fVxuIFx0fTtcblxuIFx0Ly8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yID0gZnVuY3Rpb24oZXhwb3J0cykge1xuIFx0XHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcbiBcdFx0fVxuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xuIFx0fTtcblxuIFx0Ly8gY3JlYXRlIGEgZmFrZSBuYW1lc3BhY2Ugb2JqZWN0XG4gXHQvLyBtb2RlICYgMTogdmFsdWUgaXMgYSBtb2R1bGUgaWQsIHJlcXVpcmUgaXRcbiBcdC8vIG1vZGUgJiAyOiBtZXJnZSBhbGwgcHJvcGVydGllcyBvZiB2YWx1ZSBpbnRvIHRoZSBuc1xuIFx0Ly8gbW9kZSAmIDQ6IHJldHVybiB2YWx1ZSB3aGVuIGFscmVhZHkgbnMgb2JqZWN0XG4gXHQvLyBtb2RlICYgOHwxOiBiZWhhdmUgbGlrZSByZXF1aXJlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnQgPSBmdW5jdGlvbih2YWx1ZSwgbW9kZSkge1xuIFx0XHRpZihtb2RlICYgMSkgdmFsdWUgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKHZhbHVlKTtcbiBcdFx0aWYobW9kZSAmIDgpIHJldHVybiB2YWx1ZTtcbiBcdFx0aWYoKG1vZGUgJiA0KSAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlICYmIHZhbHVlLl9fZXNNb2R1bGUpIHJldHVybiB2YWx1ZTtcbiBcdFx0dmFyIG5zID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yKG5zKTtcbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KG5zLCAnZGVmYXVsdCcsIHsgZW51bWVyYWJsZTogdHJ1ZSwgdmFsdWU6IHZhbHVlIH0pO1xuIFx0XHRpZihtb2RlICYgMiAmJiB0eXBlb2YgdmFsdWUgIT0gJ3N0cmluZycpIGZvcih2YXIga2V5IGluIHZhbHVlKSBfX3dlYnBhY2tfcmVxdWlyZV9fLmQobnMsIGtleSwgZnVuY3Rpb24oa2V5KSB7IHJldHVybiB2YWx1ZVtrZXldOyB9LmJpbmQobnVsbCwga2V5KSk7XG4gXHRcdHJldHVybiBucztcbiBcdH07XG5cbiBcdC8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSBmdW5jdGlvbihtb2R1bGUpIHtcbiBcdFx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0RGVmYXVsdCgpIHsgcmV0dXJuIG1vZHVsZVsnZGVmYXVsdCddOyB9IDpcbiBcdFx0XHRmdW5jdGlvbiBnZXRNb2R1bGVFeHBvcnRzKCkgeyByZXR1cm4gbW9kdWxlOyB9O1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCAnYScsIGdldHRlcik7XG4gXHRcdHJldHVybiBnZXR0ZXI7XG4gXHR9O1xuXG4gXHQvLyBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGxcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubyA9IGZ1bmN0aW9uKG9iamVjdCwgcHJvcGVydHkpIHsgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIHByb3BlcnR5KTsgfTtcblxuIFx0Ly8gX193ZWJwYWNrX3B1YmxpY19wYXRoX19cbiBcdF9fd2VicGFja19yZXF1aXJlX18ucCA9IFwiXCI7XG5cblxuIFx0Ly8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4gXHRyZXR1cm4gX193ZWJwYWNrX3JlcXVpcmVfXyhfX3dlYnBhY2tfcmVxdWlyZV9fLnMgPSBcIi4vcGFnZXMvQWRtaW4vRGFzaGJvYXJkLmpzXCIpO1xuIiwidmFyIGF4aW9zPXJlcXVpcmUoXCJheGlvc1wiKVxuY29uc3QgU2VydmVyVVJMPSdodHRwOi8vbG9jYWxob3N0OjQwMDAnXG4vL3RvIHJlYWQgYWxsIGRhdGEgZnJvbSBub2RlXG5cbi8qIGdldCBkYXRhKi9cbmNvbnN0IGdldERhdGE9YXN5bmModXJsKT0+e1xuICAgIHRyeXtcbiAgICAgIGNvbnN0IHJlc3BvbnNlPWF3YWl0IGZldGNoKGAke1NlcnZlclVSTH0vJHt1cmx9YClcbiAgICAgIGNvbnN0IHJlc3VsdD1hd2FpdCByZXNwb25zZS5qc29uKClcbiAgICAgIGlmKHJlc3VsdD09J1Nlc3Npb24gRXhwaXJlZCBQbHMgTG9naW4gQWdhaW4nKVxuICAgICAge1xuICAgICAgICBhbGVydChyZXN1bHQpXG4gICAgICAgIHJldHVybihbXSlcbiAgICAgIH1cbiAgICAgICBlbHNle1xuICAgICAgICByZXR1cm4gcmVzdWx0XG4gICAgICAgfVxuICAgIH1jYXRjaChlKXtcbiAgICAgICAgIGNvbnNvbGUubG9nKGUpXG4gICAgIHJldHVybiBudWxsXG5cbiAgICB9XG59XG5cbi8qIHBvc3QgZGF0YSAqLyAgICAgICAgICAgICAgICAgICAgICAgIFxuY29uc3QgcG9zdERhdGE9YXN5bmModXJsLGJvZHkpPT57XG4gICAgdHJ5e1xuICAgICAgY29uc3QgcmVzcG9uc2U9YXdhaXQgZmV0Y2goYCR7U2VydmVyVVJMfS8ke3VybH1gLFxuICAgICAge21ldGhvZDpcIlBPU1RcIixtb2RlOlwiY29yc1wiLFxuICAgICAgIGhlYWRlcnM6e1wiQ29udGVudC1UeXBlXCI6XCJhcHBsaWNhdGlvbi9qc29uO2NoYXJzZXQ9dXRmLThcIn0sXG4gICAgICAgYm9keTpKU09OLnN0cmluZ2lmeShib2R5KVxuICAgICAgfSlcbiAgICAgIGNvbnN0IHJlc3VsdD1hd2FpdCByZXNwb25zZS5qc29uKClcbiAgICAgIGlmKHJlc3VsdD09J1Nlc3Npb24gRXhwaXJlZCBQbHMgTG9naW4gQWdhaW4nKSBcbiAgICAgIHsgYWxlcnQocmVzdWx0KVxuICAgICAgIHJldHVybihbXSlcbiAgICAgIH1cbiAgICAgIGVsc2V7XG5cbiAgICAgIC8vY29uc3QgcmVzdWx0PWF3YWl0IHJlc3BvbnNlLmpzb24oKVxuICAgICAgcmV0dXJuIHJlc3VsdFxuICAgICAgfVxuXG4gICAgfWNhdGNoKGUpe1xuICAgICAgICAgY29uc29sZS5sb2coZSlcbiAgICAgcmV0dXJuIG51bGxcblxuICAgIH1cbn1cblxuLyogcG9zdCBhbmQgaW1hZ2UgZGF0YSovXG5jb25zdCBwb3N0RGF0YUFuZEltYWdlPWFzeW5jKHVybCxmb3JtRGF0YSxjb25maWcpPT57XG4gICAgdHJ5e1xuICAgICAgIHZhciByZXNwb25zZT1hd2FpdCBheGlvcy5wb3N0KGAke1NlcnZlclVSTH0vJHt1cmx9YCxmb3JtRGF0YSxjb25maWcpXG4gICAgICAvLyAgY29uc3QgcmVzdWx0PWF3YWl0IHJlc3BvbnNlLmRhdGEuUkVTVUxUIFxuICAgICAgIGlmKHJlc3BvbnNlLmRhdGE9PSdTZXNzaW9uIEV4cGlyZWQgUGxzIExvZ2luIEFnYWluJykgXG4gICAgICB7IGFsZXJ0KHJlc3BvbnNlLmRhdGEpXG4gICAgICAgcmV0dXJuKGZhbHNlKVxuICAgICAgfVxuICAgICAgZWxzZXtcbiAgICAgIFxuICAgICAgIGNvbnN0IHJlc3VsdD1hd2FpdCByZXNwb25zZS5kYXRhIFxuICAgICAgIHJldHVybiAocmVzdWx0KVxuICAgICAgfVxuICAgICAgXG4gICAgfVxuICAgIGNhdGNoKGUpe1xuICAgICAgXG4gICAgICByZXR1cm4gbnVsbFxuICAgIH1cbiAgfVxuICBjb25zdCBkZWxldGVEYXRhQXhpb3MgPSBhc3luYyAoVXJsKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIHZhciB1cmwgPSBgJHtTZXJ2ZXJVUkx9LyR7VXJsfWA7XG4gICAgICBjb25zdCBjb25maWcgPSB7IFwiY29udGVudC10eXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH07XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGF4aW9zLmRlbGV0ZSh1cmwsIGNvbmZpZyk7XG4gICAgICB2YXIgcmVzdWx0ID0gcmVzcG9uc2UuZGF0YTtcbiAgICAgIGNvbnNvbGUubG9nKHJlc3VsdCk7XG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmxvZyhlcnJvcik7XG4gICAgfVxuICB9O1xuXG4gICAgZXhwb3J0IHtnZXREYXRhLHBvc3REYXRhLHBvc3REYXRhQW5kSW1hZ2UsZGVsZXRlRGF0YUF4aW9zLFNlcnZlclVSTH0iLCJpbXBvcnQgUmVhY3Qse3VzZVN0YXRlfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHtwb3N0RGF0YSxnZXREYXRhLHBvc3REYXRhQW5kSW1hZ2V9IGZyb20gJy4uLy4uL0ZldGNoU2VydmljZXMnO1xyXG5pbXBvcnQgSWNvbkJ1dHRvbiBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9JY29uQnV0dG9uJztcclxuaW1wb3J0IEJ1dHRvbiBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9CdXR0b24nO1xyXG5pbXBvcnQgQXZhdGFyIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0F2YXRhcic7XHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENvbnNvbGVUeXBlKCkge1xyXG4gICAgXHJcbiAgICBjb25zdCBbZ2V0VHlwZSwgc2V0VHlwZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIGNvbnN0IFtnZXREZXNjcmlwdGlvbiwgc2V0RGVzY3JpcHRpb25dID0gdXNlU3RhdGUoXCJcIilcclxuICAgIGNvbnN0IFtnZXRJbWFnZSwgc2V0SW1hZ2VdPXVzZVN0YXRlKHtpY29uOicnLCBmaWxlOicnfSlcclxuICAgIGNvbnN0IFtnZXRNZXNzYWdlLCBzZXRNZXNzYWdlXSA9IHVzZVN0YXRlKFwiXCIpXHJcblxyXG4gICAgICAvKiBoYW5kbGUgaW4gaW1hZ2UqL1xyXG4gICBjb25zdCBoYW5kbGVJbWFnZT0oZXZlbnQpPT57XHJcbiAgICBzZXRJbWFnZSh7aWNvbjpVUkwuY3JlYXRlT2JqZWN0VVJMKGV2ZW50LnRhcmdldC5maWxlc1swXSksZmlsZTpldmVudC50YXJnZXQuZmlsZXNbMF19KVxyXG4gfVxyXG4gICAgXHJcbiAgICBjb25zdCBoYW5kbGVzdWJtaXQ9YXN5bmMoKT0+e1xyXG4gICAgICAgIFxyXG4gICAgICAgIHZhciBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YSgpXHJcbiAgICAgICAgICAgIGZvcm1EYXRhLmFwcGVuZCgndHlwZScsZ2V0VHlwZSksXHJcbiAgICAgICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnZGVzY3JpcHRpb24nLGdldERlc2NyaXB0aW9uKSxcclxuICAgICAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbWFnZScsZ2V0SW1hZ2UuZmlsZSlcclxuICAgICAgICAgICAgdmFyIGNvbmZpZz17aGVhZGVyOnsnY29udGVudC10eXBlJzonbXVsdGlwYXJ0L2Zvcm0tZGF0YSd9fVxyXG4gICAgICAgICAgICB2YXIgcmVzdWx0ID0gYXdhaXQgcG9zdERhdGFBbmRJbWFnZSgnY29uc29sZXR5cGUvYWRkdHlwZScsZm9ybURhdGEsY29uZmlnKVxyXG4gICAgY29uc29sZS5sb2coJ3Jlc3VsdCcscmVzdWx0KTtcclxuICAgICAgICBpZihyZXN1bHQpXHJcbiAgICAgICAgICAgIHsgLy9hbGVydChcIlJlY29yZCBTdWJtaXR0ZWRcIilcclxuICAgICAgICAgICAgc2V0TWVzc2FnZSgnUmVjb3JkIFN1Ym1pdHRlZCcpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZXtcclxuICAgICAgICAvLyBhbGVydCgnRmFpbCB0byBTdWJtaXQgUmVjb3JkJylcclxuICAgICAgICAgICAgc2V0TWVzc2FnZSgnRmFpbCB0byBTdWJtaXQgUmVjb3JkJylcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgIH1cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICA8ZGl2IGlkPVwiY29uc29sZXR5cGVfZm9ybVwiPiBcclxuICAgICAgICAgICA8ZGl2IGlkPVwiY29uc29sdHlwZWhlYWRpbmdcIj5Db25zb2xlIFR5cGU8L2Rpdj5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1yb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLW1kLTYgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBmb3I9XCJ2YWxpZGF0aW9uU2VydmVyMDFcIj5UeXBlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBjbGFzcz1cImZvcm0tY29udHJvbFwiIGlkPVwidmFsaWRhdGlvblNlcnZlcjAxXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2dldFR5cGV9IG9uQ2hhbmdlPXsoZXZlbnQpPT5zZXRUeXBlKGV2ZW50LnRhcmdldC52YWx1ZSl9IHJlcXVpcmVkLz5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidmFsaWQtZmVlZGJhY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgTG9va3MgZ29vZCFcclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLW1kLTYgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBmb3I9XCJ2YWxpZGF0aW9uU2VydmVyMDJcIj5EZXNjcmlwdGlvbjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgY2xhc3M9XCJmb3JtLWNvbnRyb2xcIiBpZD1cInZhbGlkYXRpb25TZXJ2ZXIwMlwiIFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtnZXREZXNjcmlwdGlvbn0gb25DaGFuZ2U9eyhldmVudCk9PnNldERlc2NyaXB0aW9uKGV2ZW50LnRhcmdldC52YWx1ZSl9IHJlcXVpcmVkLz5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidmFsaWQtZmVlZGJhY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgTG9va3MgZ29vZCFcclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tcm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC1tZC02IG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICB7LyogPGxhYmVsIGZvcj1cInZhbGlkYXRpb25TZXJ2ZXIwM1wiPlVwbG9hZCBJbWFnZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJmaWxlXCIgY2xhc3M9XCJmb3JtLWNvbnRyb2xcIiBpZD1cInZhbGlkYXRpb25TZXJ2ZXIwM1wiIGFyaWEtZGVzY3JpYmVkYnk9XCJ2YWxpZGF0aW9uU2VydmVyMDNGZWVkYmFja1wiIHJlcXVpcmVkLz4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gIGNsYXNzTmFtZT17Y2xhc3Nlcy5pbnB1dH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiY29udGFpbmVkLWJ1dHRvbi1maWxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgIG11bHRpcGxlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7ZGlzcGxheTonbm9uZSd9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KT0+aGFuZGxlSW1hZ2UoZXZlbnQpfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJjb250YWluZWQtYnV0dG9uLWZpbGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgY29sb3I9XCJwcmltYXJ5XCIgY29tcG9uZW50PVwic3BhblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBVcGxvYWQgSW1hZ2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8QXZhdGFyIGlkPVwiQXZldGVyXCIgc3R5bGU9e3t3aWR0aDo2MCxoZWlnaHQ6NjB9fSBzcmM9e2dldEltYWdlLmljb259IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICB7LyogPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tcHJpbWFyeVwiID48L2J1dHRvbj4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgY29sb3I9XCJwcmltYXJ5XCIgb25DbGljaz17KCk9PmhhbmRsZXN1Ym1pdCgpfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFN1Ym1pdCBmb3JtXHJcbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAge2dldE1lc3NhZ2V9XHJcbiAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC8+XHJcbiAgICApXHJcbn1cclxuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IGNsc3ggZnJvbSAnY2xzeCc7XHJcbmltcG9ydCB7IG1ha2VTdHlsZXMgfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXMnO1xyXG5pbXBvcnQgVHlwb2dyYXBoeSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9UeXBvZ3JhcGh5JztcclxuaW1wb3J0IENvbnNvbGVfdHlwZSBmcm9tICcuL0NvbnNvbGVfdHlwZSc7XHJcbmltcG9ydCBEaXNwbGF5YWxsX2NvbnNvbGV0eXBlIGZyb20gJy4vRGlzcGxheWFsbF9jb25zb2xldHlwZSc7XHJcbmltcG9ydCBNYWlucGFnZSBmcm9tICcuL01haW5wYWdlJztcclxuaW1wb3J0IENzc0Jhc2VsaW5lIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0Nzc0Jhc2VsaW5lJztcclxuaW1wb3J0IEFwcEJhciBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9BcHBCYXInO1xyXG5pbXBvcnQgVG9vbGJhciBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9Ub29sYmFyJztcclxuaW1wb3J0IExpc3QgZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvTGlzdCc7XHJcbmltcG9ydCBEaXZpZGVyIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0RpdmlkZXInO1xyXG5pbXBvcnQgSWNvbkJ1dHRvbiBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9JY29uQnV0dG9uJztcclxuaW1wb3J0IEJhZGdlIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0JhZGdlJztcclxuaW1wb3J0IENvbnRhaW5lciBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9Db250YWluZXInO1xyXG5pbXBvcnQgR3JpZCBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9HcmlkJztcclxuaW1wb3J0IFBhcGVyIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL1BhcGVyJztcclxuaW1wb3J0IExpbmsgZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvTGluayc7XHJcbmltcG9ydCBNZW51SWNvbiBmcm9tICdAbWF0ZXJpYWwtdWkvaWNvbnMvTWVudSc7XHJcbmltcG9ydCBBdmF0YXIgZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvQXZhdGFyJztcclxuaW1wb3J0IERyYXdlciBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9EcmF3ZXInO1xyXG5pbXBvcnQgQ2hldnJvbkxlZnRJY29uIGZyb20gJ0BtYXRlcmlhbC11aS9pY29ucy9DaGV2cm9uTGVmdCc7XHJcbmltcG9ydCBMaXN0SXRlbXMgZnJvbSAnLi9MaXN0SXRlbXMnO1xyXG5pbXBvcnQgQm94IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0JveCc7XHJcbmZ1bmN0aW9uIENvcHlyaWdodCgpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImJvZHkyXCIgY29sb3I9XCJ0ZXh0U2Vjb25kYXJ5XCIgYWxpZ249XCJjZW50ZXJcIj5cclxuICAgICAgeydDb3B5cmlnaHQgwqkgJ31cclxuICAgICAgPExpbmsgY29sb3I9XCJpbmhlcml0XCIgaHJlZj1cImh0dHBzOi8vbWF0ZXJpYWwtdWkuY29tL1wiPlxyXG4gICAgICAgIFlvdXIgV2Vic2l0ZVxyXG4gICAgICA8L0xpbms+eycgJ31cclxuICAgICAge25ldyBEYXRlKCkuZ2V0RnVsbFllYXIoKX1cclxuICAgICAgeycuJ31cclxuICAgIDwvVHlwb2dyYXBoeT5cclxuICApO1xyXG59XHJcblxyXG5jb25zdCBkcmF3ZXJXaWR0aCA9IDI0MDtcclxuXHJcbmNvbnN0IHVzZVN0eWxlcyA9IG1ha2VTdHlsZXMoKHRoZW1lKSA9PiAoe1xyXG4gIHJvb3Q6IHtcclxuICAgIGRpc3BsYXk6ICdmbGV4JyxcclxuICB9LFxyXG4gIHRvb2xiYXI6IHtcclxuICAgIHBhZGRpbmdSaWdodDogMjQsIC8vIGtlZXAgcmlnaHQgcGFkZGluZyB3aGVuIGRyYXdlciBjbG9zZWRcclxuICB9LFxyXG4gIHRvb2xiYXJJY29uOiB7XHJcbiAgICBkaXNwbGF5OiAnZmxleCcsXHJcbiAgICAvLyBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcclxuICAgIGp1c3RpZnlDb250ZW50OiAnZmxleC1lbmQnLFxyXG4gICAgcGFkZGluZzogJzAgOHB4JyxcclxuICAgIC4uLnRoZW1lLm1peGlucy50b29sYmFyLFxyXG4gIH0sXHJcbiAgYXBwQmFyOiB7XHJcbiAgICB6SW5kZXg6IHRoZW1lLnpJbmRleC5kcmF3ZXIgKyAxLFxyXG4gICAgdHJhbnNpdGlvbjogdGhlbWUudHJhbnNpdGlvbnMuY3JlYXRlKFsnd2lkdGgnLCAnbWFyZ2luJ10sIHtcclxuICAgICAgZWFzaW5nOiB0aGVtZS50cmFuc2l0aW9ucy5lYXNpbmcuc2hhcnAsXHJcbiAgICAgIGR1cmF0aW9uOiB0aGVtZS50cmFuc2l0aW9ucy5kdXJhdGlvbi5sZWF2aW5nU2NyZWVuLFxyXG4gICAgfSksXHJcbiAgfSxcclxuICBhcHBCYXJTaGlmdDoge1xyXG4gICAgbWFyZ2luTGVmdDogZHJhd2VyV2lkdGgsXHJcbiAgICB3aWR0aDogYGNhbGMoMTAwJSAtICR7ZHJhd2VyV2lkdGh9cHgpYCxcclxuICAgIHRyYW5zaXRpb246IHRoZW1lLnRyYW5zaXRpb25zLmNyZWF0ZShbJ3dpZHRoJywgJ21hcmdpbiddLCB7XHJcbiAgICAgIGVhc2luZzogdGhlbWUudHJhbnNpdGlvbnMuZWFzaW5nLnNoYXJwLFxyXG4gICAgICBkdXJhdGlvbjogdGhlbWUudHJhbnNpdGlvbnMuZHVyYXRpb24uZW50ZXJpbmdTY3JlZW4sXHJcbiAgICB9KSxcclxuICB9LFxyXG4gIG1lbnVCdXR0b246IHtcclxuICAgIG1hcmdpblJpZ2h0OiAzNixcclxuICB9LFxyXG4gIG1lbnVCdXR0b25IaWRkZW46IHtcclxuICAgIGRpc3BsYXk6ICdub25lJyxcclxuICB9LFxyXG4gIHRpdGxlOiB7XHJcbiAgICBmbGV4R3JvdzogMSxcclxuICB9LFxyXG4gIGRyYXdlclBhcGVyOiB7XHJcbiAgICBwb3NpdGlvbjogJ3JlbGF0aXZlJyxcclxuICAgIHdoaXRlU3BhY2U6ICdub3dyYXAnLFxyXG4gICAgd2lkdGg6IGRyYXdlcldpZHRoLFxyXG4gICAgdHJhbnNpdGlvbjogdGhlbWUudHJhbnNpdGlvbnMuY3JlYXRlKCd3aWR0aCcsIHtcclxuICAgICAgZWFzaW5nOiB0aGVtZS50cmFuc2l0aW9ucy5lYXNpbmcuc2hhcnAsXHJcbiAgICAgIGR1cmF0aW9uOiB0aGVtZS50cmFuc2l0aW9ucy5kdXJhdGlvbi5lbnRlcmluZ1NjcmVlbixcclxuICAgIH0pLFxyXG4gIH0sXHJcbiAgZHJhd2VyUGFwZXJDbG9zZToge1xyXG4gICAgb3ZlcmZsb3dYOiAnaGlkZGVuJyxcclxuICAgIHRyYW5zaXRpb246IHRoZW1lLnRyYW5zaXRpb25zLmNyZWF0ZSgnd2lkdGgnLCB7XHJcbiAgICAgIGVhc2luZzogdGhlbWUudHJhbnNpdGlvbnMuZWFzaW5nLnNoYXJwLFxyXG4gICAgICBkdXJhdGlvbjogdGhlbWUudHJhbnNpdGlvbnMuZHVyYXRpb24ubGVhdmluZ1NjcmVlbixcclxuICAgIH0pLFxyXG4gICAgd2lkdGg6IHRoZW1lLnNwYWNpbmcoNyksXHJcbiAgICBbdGhlbWUuYnJlYWtwb2ludHMudXAoJ3NtJyldOiB7XHJcbiAgICAgIHdpZHRoOiB0aGVtZS5zcGFjaW5nKDkpLFxyXG4gICAgfSxcclxuICB9LFxyXG4gIGFwcEJhclNwYWNlcjogdGhlbWUubWl4aW5zLnRvb2xiYXIsXHJcbiAgY29udGVudDoge1xyXG4gICAgZmxleEdyb3c6IDEsXHJcbiAgICBoZWlnaHQ6ICcxMDB2aCcsXHJcbiAgICBvdmVyZmxvdzogJ2F1dG8nLFxyXG4gIH0sXHJcbiAgY29udGFpbmVyOiB7XHJcbiAgICBwYWRkaW5nVG9wOiB0aGVtZS5zcGFjaW5nKDQpLFxyXG4gICAgcGFkZGluZ0JvdHRvbTogdGhlbWUuc3BhY2luZyg0KSxcclxuICAgIC8vIGJhY2tncm91bmRDb2xvcjonI2VjZWNkOScsXHJcbiAgfSxcclxuICBwYXBlcjoge1xyXG4gICAgcGFkZGluZzogdGhlbWUuc3BhY2luZygyKSxcclxuICAgIGRpc3BsYXk6ICdmbGV4JyxcclxuICAgIG92ZXJmbG93OiAnYXV0bycsXHJcbiAgICBmbGV4RGlyZWN0aW9uOiAnY29sdW1uJyxcclxuICB9LFxyXG4gIGZpeGVkSGVpZ2h0OiB7XHJcbiAgICBoZWlnaHQ6IDI0MCxcclxuICB9LFxyXG59KSk7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBEYXNoYm9hcmQocHJvcHMpIHtcclxuICBjb25zdCBjbGFzc2VzID0gdXNlU3R5bGVzKCk7XHJcbiAgY29uc3QgW29wZW4sIHNldE9wZW5dID0gUmVhY3QudXNlU3RhdGUodHJ1ZSk7XHJcbiAgY29uc3QgW1Nob3dDb21wb25lbnRzLCBzZXRDb21wb25ldF09IFJlYWN0LnVzZVN0YXRlKDxNYWlucGFnZS8+KTtcclxuLy8gICBjb25zdCBbYWRtaW4sc2V0QWRtaW5dPVJlYWN0LnVzZVN0YXRlKFtdKVxyXG4vLyAgIGNvbnN0IENoZWNrU2Vzc2lvbj1hc3luYygpPT57XHJcbi8vICAgdmFyIHJlc3VsdD1hd2FpdCBnZXREYXRhKCdhZG1pbi9jaGt0b2tlbicpXHJcbi8vICAgaWYoIXJlc3VsdClcclxuLy8gICB7XHJcbi8vICAgIHByb3BzLmhpc3RvcnkucmVwbGFjZSh7cGF0aG5hbWU6Jy9TaWduaW4nfSlcclxuLy8gICB9XHJcbi8vICAgZWxzZXtcclxuLy8gICAgIHZhciBhZG1pbj1KU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdhZG1pbicpKVxyXG4vLyAgICBjb25zb2xlLmxvZyhcIkFETUlOXCIsYWRtaW4pXHJcbi8vICAgIHNldEFkbWluKGFkbWluKVxyXG4vLyAgIH1cclxuXHJcblxyXG4vLyB1c2VFZmZlY3QoZnVuY3Rpb24oKXtcclxuLy8gICBDaGVja1Nlc3Npb24oKTtcclxuLy8gfSxbXSlcclxuXHJcbiAgY29uc3QgaGFuZGxlQ29tcG9uZW50cz1hc3luYyhTaG93RGF0YSk9PntcclxuICAgIHN3aXRjaChTaG93RGF0YSlcclxuICAgIHsgY2FzZSAwOlxyXG4gICAgICAgIGNvbnNvbGUubG9nKCcwJywwKVxyXG4gICAgICBzZXRDb21wb25ldCg8TWFpbnBhZ2UvPik7XHJcbiAgICAgIGJyZWFrXHJcbiAgICAgIGNhc2UgMTogXHJcbiAgICAgIHNldENvbXBvbmV0KDxDb25zb2xlX3R5cGUvPilcclxuICAgICAgYnJlYWtcclxuICAgICAgY2FzZSAyOlxyXG4gICAgICBzZXRDb21wb25ldCg8RGlzcGxheWFsbF9jb25zb2xldHlwZS8+KVxyXG4gICAgICBicmVha1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgY29uc3QgaGFuZGxlRHJhd2VyT3BlbiA9ICgpID0+IHtcclxuICAgIHNldE9wZW4odHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRHJhd2VyQ2xvc2UgPSAoKSA9PiB7XHJcbiAgICBzZXRPcGVuKGZhbHNlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBmaXhlZEhlaWdodFBhcGVyID0gY2xzeChjbGFzc2VzLnBhcGVyLCBjbGFzc2VzLmZpeGVkSGVpZ2h0KTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxDc3NCYXNlbGluZSAvPlxyXG4gICAgICA8QXBwQmFyIHBvc2l0aW9uPVwiYWJzb2x1dGVcIiBjbGFzc05hbWU9e2Nsc3goY2xhc3Nlcy5hcHBCYXIsIG9wZW4gJiYgY2xhc3Nlcy5hcHBCYXJTaGlmdCl9PlxyXG4gICAgICAgIDxUb29sYmFyIGNsYXNzTmFtZT17Y2xhc3Nlcy50b29sYmFyfT5cclxuICAgICAgICAgIDxJY29uQnV0dG9uXHJcbiAgICAgICAgICAgIGVkZ2U9XCJzdGFydFwiXHJcbiAgICAgICAgICAgIGNvbG9yPVwiaW5oZXJpdFwiXHJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJvcGVuIGRyYXdlclwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURyYXdlck9wZW59XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xzeChjbGFzc2VzLm1lbnVCdXR0b24sIG9wZW4gJiYgY2xhc3Nlcy5tZW51QnV0dG9uSGlkZGVuKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPE1lbnVJY29uIC8+XHJcbiAgICAgICAgICA8L0ljb25CdXR0b24+XHJcbiAgICAgICAgICA8VHlwb2dyYXBoeSBjb21wb25lbnQ9XCJoMVwiIHZhcmlhbnQ9XCJoNlwiIGNvbG9yPVwiaW5oZXJpdFwiIG5vV3JhcCBjbGFzc05hbWU9e2NsYXNzZXMudGl0bGV9PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2NsYXNzZXMuaGVhZGluZ30+XHJcbiAgICAgICAgICAgICB7LyogPGRpdj5cclxuICAgICAgICAgICAgICBBZG1pbiBEYXNoYm9hcmRcclxuICAgICAgICAgICAgICA8L2Rpdj4gKi99XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIHsvKiB7YWRtaW4uYWRtaW5uYW1lfSAqL31cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICA8QXZhdGFyIGFsdD1cIlJlbXkgU2hhcnBcIiBjbGFzc05hbWU9e2NsYXNzZXMubGFyZ2V9IC8+XHJcbiAgICAgICAgICAgey8qIDxBdmF0YXIgYWx0PVwiUmVteSBTaGFycFwiIHNyYz17YCR7U2VydmVyVVJMfS9pbWFnZXMvJHthZG1pbi5waWN0dXJlfWB9IGNsYXNzTmFtZT17Y2xhc3Nlcy5sYXJnZX0gLz4gKi99XHJcblxyXG4gICAgICAgICAgey8qIDxJY29uQnV0dG9uIGNvbG9yPVwiaW5oZXJpdFwiPlxyXG4gICAgICAgICAgICA8QmFkZ2UgYmFkZ2VDb250ZW50PXs0fSBjb2xvcj1cInNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgIDxOb3RpZmljYXRpb25zSWNvbiAvPlxyXG4gICAgICAgICAgICA8L0JhZGdlPlxyXG4gICAgICAgICAgPC9JY29uQnV0dG9uPiAqL31cclxuICAgICAgICA8L1Rvb2xiYXI+XHJcbiAgICAgIDwvQXBwQmFyPlxyXG4gICAgICA8RHJhd2VyXHJcbiAgICAgICAgdmFyaWFudD1cInBlcm1hbmVudFwiXHJcbiAgICAgICAgY2xhc3Nlcz17e1xyXG4gICAgICAgICAgcGFwZXI6IGNsc3goY2xhc3Nlcy5kcmF3ZXJQYXBlciwgIW9wZW4gJiYgY2xhc3Nlcy5kcmF3ZXJQYXBlckNsb3NlKSxcclxuICAgICAgICB9fVxyXG4gICAgICAgIG9wZW49e29wZW59XHJcbiAgICAgID5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17Y2xhc3Nlcy50b29sYmFySWNvbn0+XHJcbiAgICAgICAgICA8SWNvbkJ1dHRvbiBvbkNsaWNrPXtoYW5kbGVEcmF3ZXJDbG9zZX0+XHJcbiAgICAgICAgICAgIDxDaGV2cm9uTGVmdEljb24gLz5cclxuICAgICAgICAgIDwvSWNvbkJ1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPERpdmlkZXIgLz5cclxuICAgICAgICA8TGlzdD48TGlzdEl0ZW1zIGhhbmRsZV9Db21wb25lbnRzPXtoYW5kbGVDb21wb25lbnRzfS8+PC9MaXN0PlxyXG4gICAgICAgPC9EcmF3ZXI+XHJcbiAgICAgIDxtYWluIGNsYXNzTmFtZT17Y2xhc3Nlcy5jb250ZW50fT5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17Y2xhc3Nlcy5hcHBCYXJTcGFjZXJ9IC8+XHJcbiAgICAgICAgICA8Q29udGFpbmVyIG1heFdpZHRoPVwibGdcIiBjbGFzc05hbWU9e2NsYXNzZXMuY29udGFpbmVyfT5cclxuICAgICAgICAgICAgPEdyaWQgY29udGFpbmVyIHNwYWNpbmc9ezJ9PlxyXG4gICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBzbT17MTJ9PlxyXG4gICAgICAgICAgICAgIHtTaG93Q29tcG9uZW50c31cclxuICAgICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8Qm94IHB0PXsxMn0+XHJcbiAgICAgICAgICAgICAgPENvcHlyaWdodCAvPlxyXG4gICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgPC9kaXY+ICBcclxuICAgICAgICAgIDwvQ29udGFpbmVyPlxyXG4gICAgICA8L21haW4+XHJcbiAgICA8Lz5cclxuICApXHJcbiAgICB9IiwiaW1wb3J0IHsgRGlhbG9nIH0gZnJvbSBcIkBtYXRlcmlhbC11aS9jb3JlXCI7XHJcbmltcG9ydCBNYXRlcmlhbFRhYmxlIGZyb20gXCJtYXRlcmlhbC10YWJsZVwiO1xyXG5pbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgQnV0dG9uIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0J1dHRvbic7XHJcbmltcG9ydCBBdmF0YXIgZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvQXZhdGFyJztcclxuaW1wb3J0IHtnZXREYXRhLHBvc3REYXRhLHBvc3REYXRhQW5kSW1hZ2UsZGVsZXRlRGF0YUF4aW9zLFNlcnZlclVSTH0gZnJvbSAnLi4vLi4vRmV0Y2hTZXJ2aWNlcyc7XHJcbmltcG9ydCBTd2FsIGZyb20gJ3N3ZWV0YWxlcnQyJ1xyXG4vKipcclxuICogQGF1dGhvclxyXG4gKiBAZnVuY3Rpb24gQ2F0ZWdvcnlEaXNwbGF5XHJcbiAqKi9cclxuXHJcbiBleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBEaXNwbGF5YWxsX2NvbnNvbGV0eXBlKCkge1xyXG4gIGNvbnN0IFtkYXRhLCBzZXREYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbb3Blbiwgc2V0T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2dldENvbnNvbGVfSWQsIHNldENvbnNvbGVfSWRdPSB1c2VTdGF0ZShcIlwiKVxyXG4gIGNvbnN0IFtnZXRUeXBlLCBzZXRUeXBlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtnZXREZXNjcmlwdGlvbiwgc2V0RGVzY3JpcHRpb25dID0gdXNlU3RhdGUoXCJcIilcclxuICBjb25zdCBbZ2V0SW1hZ2UsIHNldEltYWdlXT11c2VTdGF0ZSh7aWNvbjonJywgZmlsZTonJ30pXHJcbiAgY29uc3QgW2dldE1lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUoXCJcIilcclxuICBjb25zdCBbZ2V0Q29sdW1ucywgc2V0Q29sdW1uc10gPSB1c2VTdGF0ZSh7XHJcbiAgICBjb2x1bW5zOlsgIFxyXG4gICAgeyB0aXRsZTogXCJUeXBlXCIsIGZpZWxkOiBcInR5cGVcIiB9LFxyXG4gICAgeyB0aXRsZTogXCJEZXNjcmlwdGlvblwiLCBmaWVsZDogXCJkZXNjcmlwdGlvblwiIH0sXHJcbiAgICB7IHRpdGxlOiBcIkltYWdlXCIsIGZpZWxkOiBcImltYWdlXCIsXHJcbiAgICByZW5kZXI6IChyb3dEYXRhKSA9PiAoXHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxBdmF0YXJcclxuICAgICAgICAgICAgdmFyaWFudD1cInJvdW5kZWRcIlxyXG4gICAgICAgICAgICBzcmM9e2Ake1NlcnZlclVSTH0vaW1hZ2VzLyR7cm93RGF0YS5pbWFnZX1gfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSxcclxufSxcclxuICAgIF1cclxuICAgIH0pO1xyXG5cclxuICBjb25zdCBmZXRjaERhdGEgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBnZXREYXRhKFwiY29uc29sZXR5cGUvZGlzcGxheVwiKTtcclxuICAgIGNvbnNvbGUubG9nKFwiZGF0YVwiLHJlc3VsdCk7XHJcbiAgICByZXN1bHQuc3RhdHVzICYmIHNldERhdGEocmVzdWx0LnJlc3VsdCk7XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoRGF0YSgpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2xvc2UgPSAoKSA9PiB7XHJcbiAgICBzZXRPcGVuKGZhbHNlKTtcclxuICAgIC8vIGZldGNoRGF0YSgpXHJcbiAgfTtcclxuXHJcbiAgLyogaGFuZGxlIGluIGljb24qL1xyXG4gIGNvbnN0IGhhbmRsZUltYWdlID0gKGV2ZW50KSA9PiB7XHJcbiAgICBzZXRJbWFnZSh7XHJcbiAgICAgIGljb246IFVSTC5jcmVhdGVPYmplY3RVUkwoZXZlbnQudGFyZ2V0LmZpbGVzWzBdKSxcclxuICAgICAgZmlsZTogZXZlbnQudGFyZ2V0LmZpbGVzWzBdLFxyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlID0gKHJvd0RhdGEpID0+IHtcclxuICAgIHNldENvbnNvbGVfSWQocm93RGF0YS5jb25zb2xlX3R5cGVfaWQpO1xyXG4gICAgc2V0VHlwZShyb3dEYXRhLnR5cGUpO1xyXG4gICAgc2V0RGVzY3JpcHRpb24ocm93RGF0YS5kZXNjcmlwdGlvbik7XHJcbiAgICBzZXRJbWFnZSh7IGljb246IGAke1NlcnZlclVSTH0vaW1hZ2VzLyR7cm93RGF0YS5pbWFnZX1gLCBmaWxlOiBcIlwiIH0pO1xyXG4gICAgc2V0T3Blbih0cnVlKTtcclxuICB9O1xyXG5cclxuICAvLyBjb25zdCBoYW5kbGVEZWxldGUgPSBhc3luYyAob2xkRGF0YSkgPT4ge1xyXG4gIC8vICAgLy8gbGV0IGJvZHkgPSB7IGdldENvbnNvbGVfSWQ6IG9sZERhdGEuY29uc29sZV90eXBlX2lkIH07XHJcbiAgLy8gICBhd2FpdCBkZWxldGVEYXRhQXhpb3MoYGNvbnNvbGV0eXBlL2RlbGV0ZS8ke29sZERhdGEuZ2V0Q29uc29sZV9JZH1gKTtcclxuICAvLyB9O1xyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZSA9IGFzeW5jIChvbGREYXRhKSA9PiB7XHJcbiAgICAvLyBjb25zb2xlLmxvZyhcIm9sZERhdGFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhXCIsSlNPTi5zdHJpbmdpZnkob2xkRGF0YSkpXHJcbiAgICAgIGF3YWl0IGRlbGV0ZURhdGFBeGlvcyhgY29uc29sZXR5cGUvZGVsZXRlLyR7b2xkRGF0YS5jb25zb2xlX3R5cGVfaWR9YCk7XHJcbiAgfTtcclxuXHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBcclxuICAgICAgICB2YXIgZm9ybURhdGEgPSBuZXcgRm9ybURhdGEoKVxyXG4gICAgICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2NvbnNvbGVfdHlwZV9pZCcsZ2V0Q29uc29sZV9JZClcclxuICAgICAgICAgICAgZm9ybURhdGEuYXBwZW5kKCd0eXBlJyxnZXRUeXBlKSxcclxuICAgICAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdkZXNjcmlwdGlvbicsZ2V0RGVzY3JpcHRpb24pLFxyXG4gICAgICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ltYWdlJyxnZXRJbWFnZS5maWxlKVxyXG4gICAgICAgICAgICB2YXIgY29uZmlnPXtoZWFkZXI6eydjb250ZW50LXR5cGUnOidtdWx0aXBhcnQvZm9ybS1kYXRhJ319XHJcbiAgICAgICAgICAgIC8vIHZhciByZXN1bHQgPSBhd2FpdCBwb3N0RGF0YUFuZEltYWdlKGBjb25zb2xldHlwZS91cGRhdGUvJHtjb25zb2xlX3R5cGVfaWR9YCwgY29uZmlnKVxyXG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZygncmVzdWx0JyxyZXN1bHQpO1xyXG4gICAgICAgICAgICB2YXIgcmVzdWx0ID0gYXdhaXQgcG9zdERhdGFBbmRJbWFnZShgY29uc29sZXR5cGUvdXBkYXRlLyR7Z2V0Q29uc29sZV9JZH1gLGZvcm1EYXRhLGNvbmZpZyk7XHJcbiAgICBmZXRjaERhdGEoKTtcclxuICAgIGhhbmRsZUNsb3NlKCk7XHJcblxyXG4gICAgaWYocmVzdWx0KVxyXG4gICAgeyAvL2FsZXJ0KFwiUmVjb3JkIFN1Ym1pdHRlZFwiKVxyXG4gICAgc2V0TWVzc2FnZSgnUmVjb3JkIFVwZGF0ZWQnKVxyXG4gICAgfVxyXG4gICAgZWxzZXtcclxuLy8gYWxlcnQoJ0ZhaWwgdG8gU3VibWl0IFJlY29yZCcpXHJcbiAgICBzZXRNZXNzYWdlKCdGYWlsIHRvIFVwZGF0ZSBSZWNvcmQnKVxyXG4gICAgfVxyXG5cclxuICB9O1xyXG5cclxuICBjb25zdCByZW5kZXJFZGl0Rm9ybSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCBzdHlsZSA9IHtcclxuICAgICAgd2lkdGg6IDYwMCxcclxuICAgICAgcGFkZGluZzogMTYsXHJcbiAgICAgIGJvcmRlclJhZGl1czogNSxcclxuICAgICAgYm94U2hhZG93OiBcIjAgMCAxMHB4IC0xcHggI2NjY1wiLFxyXG4gICAgfTtcclxuICAgIHJldHVybiAoXHJcbjxkaXYgaWQ9XCJjb25zb2xldHlwZV9mb3JtZGlsb2dib3hcIj4gXHJcbiAgICAgICAgICAgPGRpdiBpZD1cImNvbnNvbHR5cGVoZWFkaW5nXCI+Q29uc29sZSBUeXBlPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1yb3dcIiA+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC1tZC02IG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgZm9yPVwidmFsaWRhdGlvblNlcnZlcjAxXCI+VHlwZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgY2xhc3M9XCJmb3JtLWNvbnRyb2xcIiBpZD1cInZhbGlkYXRpb25TZXJ2ZXIwMVwiIFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtnZXRUeXBlfSBvbkNoYW5nZT17KGV2ZW50KT0+c2V0VHlwZShldmVudC50YXJnZXQudmFsdWUpfSByZXF1aXJlZC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInZhbGlkLWZlZWRiYWNrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIExvb2tzIGdvb2QhXHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC1tZC02IG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgZm9yPVwidmFsaWRhdGlvblNlcnZlcjAyXCI+RGVzY3JpcHRpb248L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIGNsYXNzPVwiZm9ybS1jb250cm9sXCIgaWQ9XCJ2YWxpZGF0aW9uU2VydmVyMDJcIiBcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z2V0RGVzY3JpcHRpb259IG9uQ2hhbmdlPXsoZXZlbnQpPT5zZXREZXNjcmlwdGlvbihldmVudC50YXJnZXQudmFsdWUpfSByZXF1aXJlZC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInZhbGlkLWZlZWRiYWNrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIExvb2tzIGdvb2QhXHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLXJvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtbWQtNiBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgey8qIDxsYWJlbCBmb3I9XCJ2YWxpZGF0aW9uU2VydmVyMDNcIj5VcGxvYWQgSW1hZ2U8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZmlsZVwiIGNsYXNzPVwiZm9ybS1jb250cm9sXCIgaWQ9XCJ2YWxpZGF0aW9uU2VydmVyMDNcIiBhcmlhLWRlc2NyaWJlZGJ5PVwidmFsaWRhdGlvblNlcnZlcjAzRmVlZGJhY2tcIiByZXF1aXJlZC8+ICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvKlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICBjbGFzc05hbWU9e2NsYXNzZXMuaW5wdXR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImNvbnRhaW5lZC1idXR0b24tZmlsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICBtdWx0aXBsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e2Rpc3BsYXk6J25vbmUnfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCk9PmhhbmRsZUltYWdlKGV2ZW50KX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiY29udGFpbmVkLWJ1dHRvbi1maWxlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIGNvbG9yPVwicHJpbWFyeVwiIGNvbXBvbmVudD1cInNwYW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgVXBsb2FkIEltYWdlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPEF2YXRhciBpZD1cIkF2ZXRlcmRpbG9nYm94XCIgc3R5bGU9e3t3aWR0aDo2MCxoZWlnaHQ6NjB9fSBzcmM9e2dldEltYWdlLmljb259IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICB7LyogPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tcHJpbWFyeVwiID48L2J1dHRvbj4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgY29sb3I9XCJwcmltYXJ5XCIgZGlzYWJsZUVsZXZhdGlvbiBpZD1cImJ1dHRvblN1bWl0XCIgb25DbGljaz17KCk9PmhhbmRsZVN1Ym1pdCgpfT5cclxuICAgICAgICAgICAgICAgICAgICB7LyogPEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgY29sb3I9XCJwcmltYXJ5XCIgb25DbGljaz17KCk9PmFsZXJ0KGdldERlc2NyaXB0aW9uKX0+ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgU3VibWl0IGZvcm1cclxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxici8+XHJcbiAgICAgICAgICAgICAgICAgIDxjZW50ZXI+PGI+e2dldE1lc3NhZ2V9PC9iPjwvY2VudGVyPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxNYXRlcmlhbFRhYmxlXHJcbiAgICAgICAgdGl0bGU9XCJDb25zb2wgVHlwZSBEYXRhXCJcclxuICAgICAgICBjb2x1bW5zPXtnZXRDb2x1bW5zLmNvbHVtbnN9XHJcbiAgICAgICAgZGF0YT17ZGF0YX1cclxuICAgICAgICBvcHRpb25zPXt7XHJcbiAgICAgICAgICBoZWFkZXJTdHlsZToge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwiIzAwMzM5OVwiLFxyXG4gICAgICAgICAgICBjb2xvcjogXCIjRkZGXCIsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgYWN0aW9uc0NlbGxTdHlsZToge1xyXG4gICAgICAgICAgICBwYWRkaW5nOiBcIjAgMjBweFwiLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9fVxyXG4gICAgICAgIGFjdGlvbnM9e1tcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgaWNvbjogXCJlZGl0XCIsXHJcbiAgICAgICAgICAgIHRvb2x0aXA6IFwiRWRpdFwiLFxyXG4gICAgICAgICAgICBvbkNsaWNrOiAoZXZlbnQsIHJvd0RhdGEpID0+IHtcclxuICAgICAgICAgICAgICBoYW5kbGVVcGRhdGUocm93RGF0YSk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIF19XHJcbiAgICAgICAgZWRpdGFibGU9e3tcclxuICAgICAgICAgIG9uUm93RGVsZXRlOiAob2xkRGF0YSkgPT5cclxuICAgICAgICAgICAgbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgZGF0YURlbGV0ZSA9IFsuLi5kYXRhXTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGluZGV4ID0gb2xkRGF0YS50YWJsZURhdGEuaWQ7XHJcbiAgICAgICAgICAgICAgICBkYXRhRGVsZXRlLnNwbGljZShpbmRleCwgMSk7XHJcbiAgICAgICAgICAgICAgICBzZXREYXRhKFsuLi5kYXRhRGVsZXRlXSk7XHJcbiAgICAgICAgICAgICAgICBoYW5kbGVEZWxldGUob2xkRGF0YSk7XHJcbiAgICAgICAgICAgICAgICByZXNvbHZlKCk7XHJcbiAgICAgICAgICAgICAgfSwgMTAwMCk7XHJcbiAgICAgICAgICAgIH0pLFxyXG4gICAgICAgIH19XHJcbiAgICAgIC8+XHJcbiAgICAgIDxEaWFsb2dcclxuICAgICAgICAvLyBmdWxsU2NyZWVuPXtmdWxsU2NyZWVufVxyXG4gICAgICAgIG1heFdpZHRoPVwibGdcIlxyXG4gICAgICAgIG9wZW49e29wZW59XHJcbiAgICAgICAgb25DbG9zZT17aGFuZGxlQ2xvc2V9XHJcbiAgICAgICAgYXJpYS1sYWJlbGxlZGJ5PVwicmVzcG9uc2l2ZS1kaWFsb2ctdGl0bGVcIlxyXG4gICAgICA+XHJcbiAgICAgICAge3JlbmRlckVkaXRGb3JtKCl9XHJcbiAgICAgIDwvRGlhbG9nPlxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG5cclxuY29uc3Qgc3R5bGUgPSB7XHJcbiAgbWF4V2lkdGg6IFwiOTUlXCIsXHJcbiAgbWFyZ2luOiBcIjIwcHggYXV0b1wiLFxyXG4gIGJvcmRlclJhZGl1czogNSxcclxuICBib3hTaGFkb3c6IFwiMCAwIDEwcHggLTFweCAjY2NjXCIsXHJcbn07XHJcblxyXG4vLyBjb25zdCBDYXRlZ29yeURpc3BsYXkgPSAocHJvcHMpID0+IHtcclxuLy8gICByZXR1cm4gPGRpdiBzdHlsZT17c3R5bGV9PntFZGl0YWJsZSgpfTwvZGl2PjtcclxuLy8gfTtcclxuXHJcblxyXG4iLCJpbXBvcnQgUmVhY3QsIHt1c2VTdGF0ZX0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgTGlzdEl0ZW0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvTGlzdEl0ZW0nO1xyXG5pbXBvcnQgTGlzdEl0ZW1JY29uIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0xpc3RJdGVtSWNvbic7XHJcbmltcG9ydCBMaXN0SXRlbVRleHQgZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvTGlzdEl0ZW1UZXh0JztcclxuaW1wb3J0IExpc3RTdWJoZWFkZXIgZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvTGlzdFN1YmhlYWRlcic7XHJcbmltcG9ydCBEYXNoYm9hcmRJY29uIGZyb20gJ0BtYXRlcmlhbC11aS9pY29ucy9EYXNoYm9hcmQnO1xyXG5pbXBvcnQgU2hvcHBpbmdDYXJ0SWNvbiBmcm9tICdAbWF0ZXJpYWwtdWkvaWNvbnMvU2hvcHBpbmdDYXJ0JztcclxuaW1wb3J0IFBlb3BsZUljb24gZnJvbSAnQG1hdGVyaWFsLXVpL2ljb25zL1Blb3BsZSc7XHJcbmltcG9ydCBCYXJDaGFydEljb24gZnJvbSAnQG1hdGVyaWFsLXVpL2ljb25zL0JhckNoYXJ0JztcclxuaW1wb3J0IExheWVyc0ljb24gZnJvbSAnQG1hdGVyaWFsLXVpL2ljb25zL0xheWVycyc7XHJcbmltcG9ydCBBc3NpZ25tZW50SWNvbiBmcm9tICdAbWF0ZXJpYWwtdWkvaWNvbnMvQXNzaWdubWVudCc7XHJcbmltcG9ydCB7IG1ha2VTdHlsZXMgfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXMnO1xyXG5pbXBvcnQgTGlzdCBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9MaXN0JztcclxuaW1wb3J0IENvbGxhcHNlIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0NvbGxhcHNlJztcclxuaW1wb3J0IEluYm94SWNvbiBmcm9tICdAbWF0ZXJpYWwtdWkvaWNvbnMvTW92ZVRvSW5ib3gnO1xyXG5pbXBvcnQgRHJhZnRzSWNvbiBmcm9tICdAbWF0ZXJpYWwtdWkvaWNvbnMvRHJhZnRzJztcclxuaW1wb3J0IFNlbmRJY29uIGZyb20gJ0BtYXRlcmlhbC11aS9pY29ucy9TZW5kJztcclxuaW1wb3J0IEV4cGFuZExlc3MgZnJvbSAnQG1hdGVyaWFsLXVpL2ljb25zL0V4cGFuZExlc3MnO1xyXG5pbXBvcnQgRXhwYW5kTW9yZSBmcm9tICdAbWF0ZXJpYWwtdWkvaWNvbnMvRXhwYW5kTW9yZSc7XHJcbmltcG9ydCBTdGFyQm9yZGVyIGZyb20gJ0BtYXRlcmlhbC11aS9pY29ucy9TdGFyQm9yZGVyJztcclxuY29uc3QgdXNlU3R5bGVzID0gbWFrZVN0eWxlcyh0aGVtZT0+KHtcclxuXHJcbn0pKTtcclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTGlzdEl0ZW1zKHByb3BzKXtcclxuICBjb25zdCBjbGFzc2VzID0gdXNlU3R5bGVzKCk7XHJcbiAgY29uc3QgW29wZW4sIHNldE9wZW5dID0gUmVhY3QudXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFticmFuZCwgc2V0QnJhbmRdID0gUmVhY3QudXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtvdXRsYXRlLCBzZXRPdXRsYXRlXSA9IFJlYWN0LnVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbW9kbGUsIHNldE1vZGxlXSA9IFJlYWN0LnVzZVN0YXRlKGZhbHNlKTtcclxuICAvLyAgY29uc3QgW2NhdGVnb3J5LCBzZXRDYXRlZ29yeV09UmVhY3QudXNlU3RhdGUoZmFsc2UpXHJcblxyXG4gICBjb25zdCBoYW5kbGVDbGlja09wZW49KGxpc3REYXRhKT0+e1xyXG4gICAgIGlmKGxpc3REYXRhID09ICdDb25zb2xlX3R5cGUnKXtcclxuICAgICAgc2V0T3Blbighb3Blbik7XHJcbiAgICAgfVxyXG4gICAgICBlbHNlIGlmKGxpc3REYXRhID09ICdicmFuZF9kYXRhJyl7XHJcbiAgICAgICAgc2V0QnJhbmQoIWJyYW5kKTtcclxuICAgICAgfVxyXG4gICAgICBlbHNlIGlmKGxpc3REYXRhID09ICdvdXRsYXRlX2RhdGEnKXtcclxuICAgICAgICBzZXRPdXRsYXRlKCFvdXRsYXRlKTtcclxuICAgICAgfVxyXG4gICAgICBlbHNlIGlmKGxpc3REYXRhID09ICdtb2RsZV9kYXRhJyl7XHJcbiAgICAgICAgc2V0TW9kbGUoIW1vZGxlKTtcclxuICAgICAgfVxyXG4gICB9XHJcblxyXG5cclxuICBjb25zdCBoYW5kbGVDbGljaz0oc2hvd0RhdGEpPT57XHJcbiAgcHJvcHMuaGFuZGxlX0NvbXBvbmVudHMoc2hvd0RhdGEpO1xyXG4gIH1cclxuXHJcbnJldHVybiAoXHJcbiAgPGRpdj5cclxuICAgIDxMaXN0SXRlbSBidXR0b24gIG9uQ2xpY2s9eygpPT5oYW5kbGVDbGljaygwKX0+XHJcbiAgICAgIDxMaXN0SXRlbUljb24+XHJcbiAgICAgICAgPERhc2hib2FyZEljb24gLz5cclxuICAgICAgPC9MaXN0SXRlbUljb24+XHJcbiAgICAgIDxMaXN0SXRlbVRleHQgcHJpbWFyeT1cIkRhc2hib2FyZFwiIC8+XHJcbiAgICA8L0xpc3RJdGVtPlxyXG5cclxuICAgIDxMaXN0SXRlbSBidXR0b24gb25DbGljaz17KCk9PmhhbmRsZUNsaWNrT3BlbignQ29uc29sZV90eXBlJyl9PlxyXG4gICAgICA8TGlzdEl0ZW1JY29uPlxyXG4gICAgICAgIDxTaG9wcGluZ0NhcnRJY29uIC8+XHJcbiAgICAgIDwvTGlzdEl0ZW1JY29uPlxyXG4gICAgICA8TGlzdEl0ZW1UZXh0IHByaW1hcnk9XCJDb25zb2xlIFR5cGVcIiAvPlxyXG4gICAgICAgIHtvcGVuID8gPEV4cGFuZExlc3MgLz4gOiA8RXhwYW5kTW9yZSAvPn1cclxuICAgIDwvTGlzdEl0ZW0+XHJcbiAgICA8Q29sbGFwc2UgaW49e29wZW59IHRpbWVvdXQ9XCJhdXRvXCIgdW5tb3VudE9uRXhpdD5cclxuICAgICAgICA8TGlzdCBjb21wb25lbnQ9XCJkaXZcIiBkaXNhYmxlUGFkZGluZz5cclxuICAgICAgICAgIDxMaXN0SXRlbSBidXR0b24gY2xhc3NOYW1lPXtjbGFzc2VzLm5lc3RlZH0gb25DbGljaz17KCk9PmhhbmRsZUNsaWNrKDEpfT5cclxuICAgICAgICAgICAgPExpc3RJdGVtSWNvbj5cclxuICAgICAgICAgICAgICA8U3RhckJvcmRlciAvPlxyXG4gICAgICAgICAgICA8L0xpc3RJdGVtSWNvbj5cclxuICAgICAgICAgICAgPExpc3RJdGVtVGV4dCBwcmltYXJ5PVwiRGlzcGxheSBhbGwgY29uc29sZSB0eXBlIFwiIC8+XHJcbiAgICAgICAgICA8L0xpc3RJdGVtPlxyXG5cclxuICAgICAgICAgIDxMaXN0SXRlbSBidXR0b24gY2xhc3NOYW1lPXtjbGFzc2VzLm5lc3RlZH0gb25DbGljaz17KCk9PmhhbmRsZUNsaWNrKDIpfT5cclxuICAgICAgICAgICAgPExpc3RJdGVtSWNvbj5cclxuICAgICAgICAgICAgICA8U3RhckJvcmRlciAvPlxyXG4gICAgICAgICAgICA8L0xpc3RJdGVtSWNvbj5cclxuICAgICAgICAgICAgPExpc3RJdGVtVGV4dCBwcmltYXJ5PVwiRGlzcGxheWFsbF9jb25zb2xldHlwZVwiIC8+XHJcbiAgICAgICAgICA8L0xpc3RJdGVtPlxyXG5cclxuICAgICAgICA8L0xpc3Q+XHJcbiAgICA8L0NvbGxhcHNlPlxyXG5cclxuICAgIHsvKiA8TGlzdEl0ZW0gYnV0dG9uIG9uQ2xpY2s9eygpPT5oYW5kbGVDbGlja09wZW4oJ2JyYW5kX2RhdGEnKX0+XHJcbiAgICAgIDxMaXN0SXRlbUljb24+XHJcbiAgICAgICAgPFNob3BwaW5nQ2FydEljb24gLz5cclxuICAgICAgPC9MaXN0SXRlbUljb24+XHJcbiAgICAgIDxMaXN0SXRlbVRleHQgcHJpbWFyeT1cIkJyYW5kXCIgLz5cclxuICAgICAgICB7YnJhbmQgPyA8RXhwYW5kTGVzcyAvPiA6IDxFeHBhbmRNb3JlIC8+fVxyXG4gICAgPC9MaXN0SXRlbT4gKi99XHJcbiAgICB7LyogPENvbGxhcHNlIGluPXticmFuZH0gdGltZW91dD1cImF1dG9cIiB1bm1vdW50T25FeGl0PlxyXG4gICAgICAgIDxMaXN0IGNvbXBvbmVudD1cImRpdlwiIGRpc2FibGVQYWRkaW5nPlxyXG4gICAgICAgICAgPExpc3RJdGVtIGJ1dHRvbiBjbGFzc05hbWU9e2NsYXNzZXMubmVzdGVkfSBvbkNsaWNrPXsoKT0+aGFuZGxlQ2xpY2soMyl9PlxyXG4gICAgICAgICAgICA8TGlzdEl0ZW1JY29uPlxyXG4gICAgICAgICAgICAgIDxTdGFyQm9yZGVyIC8+XHJcbiAgICAgICAgICAgIDwvTGlzdEl0ZW1JY29uPlxyXG4gICAgICAgICAgICA8TGlzdEl0ZW1UZXh0IHByaW1hcnk9XCJCcmFuZEludGVyZmFjZVwiIC8+XHJcbiAgICAgICAgICA8L0xpc3RJdGVtPlxyXG5cclxuICAgICAgICAgIDxMaXN0SXRlbSBidXR0b24gY2xhc3NOYW1lPXtjbGFzc2VzLm5lc3RlZH0gb25DbGljaz17KCk9PmhhbmRsZUNsaWNrKDQpfT5cclxuICAgICAgICAgICAgPExpc3RJdGVtSWNvbj5cclxuICAgICAgICAgICAgICA8U3RhckJvcmRlciAvPlxyXG4gICAgICAgICAgICA8L0xpc3RJdGVtSWNvbj5cclxuICAgICAgICAgICAgPExpc3RJdGVtVGV4dCBwcmltYXJ5PVwiRGlzcGxheUFsbEJyYW5kXCIgLz5cclxuICAgICAgICAgIDwvTGlzdEl0ZW0+XHJcblxyXG4gICAgICAgIDwvTGlzdD5cclxuICAgIDwvQ29sbGFwc2U+ICovfVxyXG5cclxuICAgIHsvKiA8TGlzdEl0ZW0gYnV0dG9uIG9uQ2xpY2s9eygpPT5oYW5kbGVDbGlja09wZW4oJ291dGxhdGVfZGF0YScpfT5cclxuICAgICAgPExpc3RJdGVtSWNvbj5cclxuICAgICAgICA8U2hvcHBpbmdDYXJ0SWNvbiAvPlxyXG4gICAgICA8L0xpc3RJdGVtSWNvbj5cclxuICAgICAgPExpc3RJdGVtVGV4dCBwcmltYXJ5PVwiT3V0bGV0XCIgLz5cclxuICAgICAgICB7b3V0bGF0ZSA/IDxFeHBhbmRMZXNzIC8+IDogPEV4cGFuZE1vcmUgLz59XHJcbiAgICA8L0xpc3RJdGVtPlxyXG4gICAgPENvbGxhcHNlIGluPXtvdXRsYXRlfSB0aW1lb3V0PVwiYXV0b1wiIHVubW91bnRPbkV4aXQ+XHJcbiAgICAgICAgPExpc3QgY29tcG9uZW50PVwiZGl2XCIgZGlzYWJsZVBhZGRpbmc+XHJcbiAgICAgICAgICA8TGlzdEl0ZW0gYnV0dG9uIGNsYXNzTmFtZT17Y2xhc3Nlcy5uZXN0ZWR9IG9uQ2xpY2s9eygpPT5oYW5kbGVDbGljayg1KX0+XHJcbiAgICAgICAgICAgIDxMaXN0SXRlbUljb24+XHJcbiAgICAgICAgICAgICAgPFN0YXJCb3JkZXIgLz5cclxuICAgICAgICAgICAgPC9MaXN0SXRlbUljb24+XHJcbiAgICAgICAgICAgIDxMaXN0SXRlbVRleHQgcHJpbWFyeT1cIk91dGxldEludGVyZmFjZVwiIC8+XHJcbiAgICAgICAgICA8L0xpc3RJdGVtPlxyXG5cclxuICAgICAgICAgIDxMaXN0SXRlbSBidXR0b24gY2xhc3NOYW1lPXtjbGFzc2VzLm5lc3RlZH0gb25DbGljaz17KCk9PmhhbmRsZUNsaWNrKDYpfT5cclxuICAgICAgICAgICAgPExpc3RJdGVtSWNvbj5cclxuICAgICAgICAgICAgICA8U3RhckJvcmRlciAvPlxyXG4gICAgICAgICAgICA8L0xpc3RJdGVtSWNvbj5cclxuICAgICAgICAgICAgPExpc3RJdGVtVGV4dCBwcmltYXJ5PVwiRGlzcGxheUFsbE91dGxldHNcIiAvPlxyXG4gICAgICAgICAgPC9MaXN0SXRlbT5cclxuXHJcbiAgICAgICAgPC9MaXN0PlxyXG4gICAgPC9Db2xsYXBzZT5cclxuXHJcbiAgICA8TGlzdEl0ZW0gYnV0dG9uIG9uQ2xpY2s9eygpPT5oYW5kbGVDbGlja09wZW4oJ21vZGxlX2RhdGEnKX0+XHJcbiAgICAgIDxMaXN0SXRlbUljb24+XHJcbiAgICAgICAgPFNob3BwaW5nQ2FydEljb24gLz5cclxuICAgICAgPC9MaXN0SXRlbUljb24+XHJcbiAgICAgIDxMaXN0SXRlbVRleHQgcHJpbWFyeT1cIk1vZGxlXCIgLz5cclxuICAgICAgICB7bW9kbGUgPyA8RXhwYW5kTGVzcyAvPiA6IDxFeHBhbmRNb3JlIC8+fVxyXG4gICAgPC9MaXN0SXRlbT5cclxuICAgIDxDb2xsYXBzZSBpbj17bW9kbGV9IHRpbWVvdXQ9XCJhdXRvXCIgdW5tb3VudE9uRXhpdD5cclxuICAgICAgICA8TGlzdCBjb21wb25lbnQ9XCJkaXZcIiBkaXNhYmxlUGFkZGluZz5cclxuICAgICAgICAgIDxMaXN0SXRlbSBidXR0b24gY2xhc3NOYW1lPXtjbGFzc2VzLm5lc3RlZH0gb25DbGljaz17KCk9PmhhbmRsZUNsaWNrKDcpfT5cclxuICAgICAgICAgICAgPExpc3RJdGVtSWNvbj5cclxuICAgICAgICAgICAgICA8U3RhckJvcmRlciAvPlxyXG4gICAgICAgICAgICA8L0xpc3RJdGVtSWNvbj5cclxuICAgICAgICAgICAgPExpc3RJdGVtVGV4dCBwcmltYXJ5PVwiTW9kbGVJbnRlcmZhY2VcIiAvPlxyXG4gICAgICAgICAgPC9MaXN0SXRlbT5cclxuXHJcbiAgICAgICAgICA8TGlzdEl0ZW0gYnV0dG9uIGNsYXNzTmFtZT17Y2xhc3Nlcy5uZXN0ZWR9IG9uQ2xpY2s9eygpPT5oYW5kbGVDbGljayg4KX0+XHJcbiAgICAgICAgICAgIDxMaXN0SXRlbUljb24+XHJcbiAgICAgICAgICAgICAgPFN0YXJCb3JkZXIgLz5cclxuICAgICAgICAgICAgPC9MaXN0SXRlbUljb24+XHJcbiAgICAgICAgICAgIDxMaXN0SXRlbVRleHQgcHJpbWFyeT1cIkRpc3BsYXlBbGxNb2RsZVwiIC8+XHJcbiAgICAgICAgICA8L0xpc3RJdGVtPlxyXG4gICAgICAgIDwvTGlzdD5cclxuICAgIDwvQ29sbGFwc2U+ICovfVxyXG4gICAgICAgey8qIDxMaXN0SXRlbSBidXR0b24gY2xhc3NOYW1lPXtjbGFzc2VzLm5lc3RlZH0gb25DbGljaz17KCk9PmhhbmRsZUNsaWNrKDkpfT5cclxuICAgICAgICAgIDxMaXN0SXRlbUljb24+XHJcbiAgICAgICAgICAgIDxMYXllcnNJY29uIC8+XHJcbiAgICAgICAgICA8L0xpc3RJdGVtSWNvbj5cclxuICAgICAgICAgIDxMaXN0SXRlbVRleHQgcHJpbWFyeT1cIkxvZ291dFwiLz5cclxuICAgICAgICA8L0xpc3RJdGVtPiAqL31cclxuXHJcblxyXG4gICAgey8qIDxMaXN0SXRlbSBidXR0b24gb25DbGljaz17KCk9PmhhbmRsZUNsaWNrKDIpfT5cclxuICAgICAgPExpc3RJdGVtSWNvbj5cclxuICAgICAgICA8UGVvcGxlSWNvbiAvPlxyXG4gICAgICA8L0xpc3RJdGVtSWNvbj5cclxuICAgICAgPExpc3RJdGVtVGV4dCBwcmltYXJ5PVwiQnJhbmRcIiAvPlxyXG4gICAgPC9MaXN0SXRlbT5cclxuICAgIDxMaXN0SXRlbSBidXR0b24gb25DbGljaz17KCk9PmhhbmRsZUNsaWNrKDMpfT5cclxuICAgICAgPExpc3RJdGVtSWNvbj5cclxuICAgICAgICA8QmFyQ2hhcnRJY29uIC8+XHJcbiAgICAgIDwvTGlzdEl0ZW1JY29uPlxyXG4gICAgICA8TGlzdEl0ZW1UZXh0IHByaW1hcnk9XCJPdXRsZXRcIiAvPlxyXG4gICAgPC9MaXN0SXRlbT5cclxuICAgIDxMaXN0SXRlbSBidXR0b24gb25DbGljaz17KCk9PmhhbmRsZUNsaWNrKDQpfT5cclxuICAgICAgPExpc3RJdGVtSWNvbj5cclxuICAgICAgICA8TGF5ZXJzSWNvbiAvPlxyXG4gICAgICA8L0xpc3RJdGVtSWNvbj5cclxuICAgICAgPExpc3RJdGVtVGV4dCBwcmltYXJ5PVwiTW9kbGVcIiAvPlxyXG4gICAgPC9MaXN0SXRlbT5cclxuICAgIDxMaXN0SXRlbSBidXR0b24+XHJcbiAgICAgIDxMaXN0SXRlbUljb24+XHJcbiAgICAgICAgPExheWVyc0ljb24gLz5cclxuICAgICAgPC9MaXN0SXRlbUljb24+XHJcbiAgICAgIDxMaXN0SXRlbVRleHQgcHJpbWFyeT1cIkxvZ291dFwiIG9uQ2xpY2s9eygpPT5oYW5kbGVDbGljayg1KX0gLz5cclxuICAgIDwvTGlzdEl0ZW0+ICovfVxyXG4gIDwvZGl2PlxyXG4pO1xyXG59XHJcblxyXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNYWlucGFnZSgpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgbWFpbiBwYWdldGh0eXR5dHl0eXRyeXJcclxuICAgICAgICB7LyogPCEtLS1Db250YWluZXIgRmx1aWQtLT4gICAqL31cclxuICAgICAgICA8Lz5cclxuICAgIClcclxufVxyXG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS9BcHBCYXJcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvQXZhdGFyXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlL0JhZGdlXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlL0JveFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS9CdXR0b25cIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvQ29sbGFwc2VcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvQ29udGFpbmVyXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlL0Nzc0Jhc2VsaW5lXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlL0RpdmlkZXJcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvRHJhd2VyXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlL0dyaWRcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvSWNvbkJ1dHRvblwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS9MaW5rXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlL0xpc3RcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvTGlzdEl0ZW1cIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvTGlzdEl0ZW1JY29uXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlL0xpc3RJdGVtVGV4dFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS9MaXN0U3ViaGVhZGVyXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlL1BhcGVyXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlL1Rvb2xiYXJcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvVHlwb2dyYXBoeVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2ljb25zL0Fzc2lnbm1lbnRcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2ljb25zL0JhckNoYXJ0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9pY29ucy9DaGV2cm9uTGVmdFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvaWNvbnMvRGFzaGJvYXJkXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9pY29ucy9EcmFmdHNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2ljb25zL0V4cGFuZExlc3NcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2ljb25zL0V4cGFuZE1vcmVcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2ljb25zL0xheWVyc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvaWNvbnMvTWVudVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvaWNvbnMvTW92ZVRvSW5ib3hcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2ljb25zL1Blb3BsZVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvaWNvbnMvU2VuZFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvaWNvbnMvU2hvcHBpbmdDYXJ0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9pY29ucy9TdGFyQm9yZGVyXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImF4aW9zXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImNsc3hcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibWF0ZXJpYWwtdGFibGVcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3RcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QvanN4LWRldi1ydW50aW1lXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInN3ZWV0YWxlcnQyXCIpOyJdLCJzb3VyY2VSb290IjoiIn0=