module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./pages/Admin/Displayall_consoletype.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./FetchServices.js":
/*!**************************!*\
  !*** ./FetchServices.js ***!
  \**************************/
/*! exports provided: getData, postData, postDataAndImage, deleteDataAxios, ServerURL */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getData", function() { return getData; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "postData", function() { return postData; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "postDataAndImage", function() { return postDataAndImage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "deleteDataAxios", function() { return deleteDataAxios; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServerURL", function() { return ServerURL; });
var axios = __webpack_require__(/*! axios */ "axios");

const ServerURL = 'http://localhost:4000'; //to read all data from node

/* get data*/

const getData = async url => {
  try {
    const response = await fetch(`${ServerURL}/${url}`);
    const result = await response.json();

    if (result == 'Session Expired Pls Login Again') {
      alert(result);
      return [];
    } else {
      return result;
    }
  } catch (e) {
    console.log(e);
    return null;
  }
};
/* post data */


const postData = async (url, body) => {
  try {
    const response = await fetch(`${ServerURL}/${url}`, {
      method: "POST",
      mode: "cors",
      headers: {
        "Content-Type": "application/json;charset=utf-8"
      },
      body: JSON.stringify(body)
    });
    const result = await response.json();

    if (result == 'Session Expired Pls Login Again') {
      alert(result);
      return [];
    } else {
      //const result=await response.json()
      return result;
    }
  } catch (e) {
    console.log(e);
    return null;
  }
};
/* post and image data*/


const postDataAndImage = async (url, formData, config) => {
  try {
    var response = await axios.post(`${ServerURL}/${url}`, formData, config); //  const result=await response.data.RESULT 

    if (response.data == 'Session Expired Pls Login Again') {
      alert(response.data);
      return false;
    } else {
      const result = await response.data;
      return result;
    }
  } catch (e) {
    return null;
  }
};

const deleteDataAxios = async Url => {
  try {
    var url = `${ServerURL}/${Url}`;
    const config = {
      "content-type": "application/json"
    };
    const response = await axios.delete(url, config);
    var result = response.data;
    console.log(result);
    return result;
  } catch (error) {
    console.log(error);
  }
};



/***/ }),

/***/ "./pages/Admin/Displayall_consoletype.js":
/*!***********************************************!*\
  !*** ./pages/Admin/Displayall_consoletype.js ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Displayall_consoletype; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var material_table__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! material-table */ "material-table");
/* harmony import */ var material_table__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(material_table__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core_Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/Button */ "@material-ui/core/Button");
/* harmony import */ var _material_ui_core_Button__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _material_ui_core_Avatar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/Avatar */ "@material-ui/core/Avatar");
/* harmony import */ var _material_ui_core_Avatar__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Avatar__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _FetchServices__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../FetchServices */ "./FetchServices.js");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! sweetalert2 */ "sweetalert2");
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_7__);


var _jsxFileName = "E:\\gamestation\\pages\\Admin\\Displayall_consoletype.js";







/**
 * @author
 * @function CategoryDisplay
 **/

function Displayall_consoletype() {
  const {
    0: data,
    1: setData
  } = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])([]);
  const {
    0: open,
    1: setOpen
  } = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])(false);
  const {
    0: getConsole_Id,
    1: setConsole_Id
  } = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])("");
  const {
    0: getType,
    1: setType
  } = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])("");
  const {
    0: getDescription,
    1: setDescription
  } = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])("");
  const {
    0: getImage,
    1: setImage
  } = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])({
    icon: '',
    file: ''
  });
  const {
    0: getMessage,
    1: setMessage
  } = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])("");
  const {
    0: getColumns,
    1: setColumns
  } = Object(react__WEBPACK_IMPORTED_MODULE_3__["useState"])({
    columns: [{
      title: "Type",
      field: "type"
    }, {
      title: "Description",
      field: "description"
    }, {
      title: "Image",
      field: "image",
      render: rowData => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Avatar__WEBPACK_IMPORTED_MODULE_5___default.a, {
          variant: "rounded",
          src: `${_FetchServices__WEBPACK_IMPORTED_MODULE_6__["ServerURL"]}/images/${rowData.image}`
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 28,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 9
      }, this)
    }]
  });

  const fetchData = async () => {
    const result = await Object(_FetchServices__WEBPACK_IMPORTED_MODULE_6__["getData"])("consoletype/display");
    console.log("data", result);
    result.status && setData(result.result);
  };

  Object(react__WEBPACK_IMPORTED_MODULE_3__["useEffect"])(() => {
    fetchData();
  }, []);

  const handleClose = () => {
    setOpen(false); // fetchData()
  };
  /* handle in icon*/


  const handleImage = event => {
    setImage({
      icon: URL.createObjectURL(event.target.files[0]),
      file: event.target.files[0]
    });
  };

  const handleUpdate = rowData => {
    setConsole_Id(rowData.console_type_id);
    setType(rowData.type);
    setDescription(rowData.description);
    setImage({
      icon: `${_FetchServices__WEBPACK_IMPORTED_MODULE_6__["ServerURL"]}/images/${rowData.image}`,
      file: ""
    });
    setOpen(true);
  }; // const handleDelete = async (oldData) => {
  //   // let body = { getConsole_Id: oldData.console_type_id };
  //   await deleteDataAxios(`consoletype/delete/${oldData.getConsole_Id}`);
  // };


  const handleDelete = async oldData => {
    // console.log("oldDataaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",JSON.stringify(oldData))
    await Object(_FetchServices__WEBPACK_IMPORTED_MODULE_6__["deleteDataAxios"])(`consoletype/delete/${oldData.console_type_id}`);
  };

  const handleSubmit = async e => {
    var formData = new FormData();
    formData.append('console_type_id', getConsole_Id);
    formData.append('type', getType), formData.append('description', getDescription), formData.append('image', getImage.file);
    var config = {
      header: {
        'content-type': 'multipart/form-data'
      }
    }; // var result = await postDataAndImage(`consoletype/update/${console_type_id}`, config)
    // console.log('result',result);

    var result = await Object(_FetchServices__WEBPACK_IMPORTED_MODULE_6__["postDataAndImage"])(`consoletype/update/${getConsole_Id}`, formData, config);
    fetchData();
    handleClose();

    if (result) {
      //alert("Record Submitted")
      setMessage('Record Updated');
    } else {
      // alert('Fail to Submit Record')
      setMessage('Fail to Update Record');
    }
  };

  const renderEditForm = e => {
    const style = {
      width: 600,
      padding: 16,
      borderRadius: 5,
      boxShadow: "0 0 10px -1px #ccc"
    };
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      id: "consoletype_formdilogbox",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        id: "consoltypeheading",
        children: "Console Type"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 113,
        columnNumber: 12
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        class: "form-row",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          class: "col-md-6 mb-3",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
            for: "validationServer01",
            children: "Type"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 116,
            columnNumber: 21
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
            type: "text",
            class: "form-control",
            id: "validationServer01",
            value: getType,
            onChange: event => setType(event.target.value),
            required: true
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 117,
            columnNumber: 21
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            class: "valid-feedback",
            children: "Looks good!"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 119,
            columnNumber: 21
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 115,
          columnNumber: 21
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          class: "col-md-6 mb-3",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
            for: "validationServer02",
            children: "Description"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 124,
            columnNumber: 21
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
            type: "text",
            class: "form-control",
            id: "validationServer02",
            value: getDescription,
            onChange: event => setDescription(event.target.value),
            required: true
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 125,
            columnNumber: 21
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            class: "valid-feedback",
            children: "Looks good!"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 127,
            columnNumber: 21
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 123,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 114,
        columnNumber: 17
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        class: "form-row",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          class: "col-md-6 mb-3",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
            accept: "image/*" //  className={classes.input}
            ,
            id: "contained-button-file",
            multiple: true,
            type: "file",
            style: {
              display: 'none'
            },
            onChange: event => handleImage(event)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 136,
            columnNumber: 21
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
            htmlFor: "contained-button-file",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_4___default.a, {
              variant: "contained",
              color: "primary",
              component: "span",
              children: "Upload Image"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 146,
              columnNumber: 25
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 145,
            columnNumber: 21
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Avatar__WEBPACK_IMPORTED_MODULE_5___default.a, {
            id: "Aveterdilogbox",
            style: {
              width: 60,
              height: 60
            },
            src: getImage.icon
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 150,
            columnNumber: 21
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 133,
          columnNumber: 21
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 132,
        columnNumber: 20
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_4___default.a, {
        variant: "contained",
        color: "primary",
        disableElevation: true,
        id: "buttonSumit",
        onClick: () => handleSubmit(),
        children: "Submit form"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 154,
        columnNumber: 21
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 159,
          columnNumber: 19
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("center", {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
            children: getMessage
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 160,
            columnNumber: 27
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 160,
          columnNumber: 19
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 158,
        columnNumber: 17
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 112,
      columnNumber: 1
    }, this);
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(material_table__WEBPACK_IMPORTED_MODULE_2___default.a, {
      title: "Consol Type Data",
      columns: getColumns.columns,
      data: data,
      options: {
        headerStyle: {
          backgroundColor: "#003399",
          color: "#FFF"
        },
        actionsCellStyle: {
          padding: "0 20px"
        }
      },
      actions: [{
        icon: "edit",
        tooltip: "Edit",
        onClick: (event, rowData) => {
          handleUpdate(rowData);
        }
      }],
      editable: {
        onRowDelete: oldData => new Promise((resolve, reject) => {
          setTimeout(() => {
            const dataDelete = [...data];
            const index = oldData.tableData.id;
            dataDelete.splice(index, 1);
            setData([...dataDelete]);
            handleDelete(oldData);
            resolve();
          }, 1000);
        })
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 169,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Dialog"] // fullScreen={fullScreen}
    , {
      maxWidth: "lg",
      open: open,
      onClose: handleClose,
      "aria-labelledby": "responsive-dialog-title",
      children: renderEditForm()
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 205,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}
const style = {
  maxWidth: "95%",
  margin: "20px auto",
  borderRadius: 5,
  boxShadow: "0 0 10px -1px #ccc"
}; // const CategoryDisplay = (props) => {
//   return <div style={style}>{Editable()}</div>;
// };

/***/ }),

/***/ "@material-ui/core":
/*!************************************!*\
  !*** external "@material-ui/core" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core");

/***/ }),

/***/ "@material-ui/core/Avatar":
/*!*******************************************!*\
  !*** external "@material-ui/core/Avatar" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Avatar");

/***/ }),

/***/ "@material-ui/core/Button":
/*!*******************************************!*\
  !*** external "@material-ui/core/Button" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Button");

/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("axios");

/***/ }),

/***/ "material-table":
/*!*********************************!*\
  !*** external "material-table" ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("material-table");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "sweetalert2":
/*!******************************!*\
  !*** external "sweetalert2" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sweetalert2");

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vRmV0Y2hTZXJ2aWNlcy5qcyIsIndlYnBhY2s6Ly8vLi9wYWdlcy9BZG1pbi9EaXNwbGF5YWxsX2NvbnNvbGV0eXBlLmpzIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvQXZhdGFyXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvQnV0dG9uXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiYXhpb3NcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJtYXRlcmlhbC10YWJsZVwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicmVhY3QvanN4LWRldi1ydW50aW1lXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwic3dlZXRhbGVydDJcIiJdLCJuYW1lcyI6WyJheGlvcyIsInJlcXVpcmUiLCJTZXJ2ZXJVUkwiLCJnZXREYXRhIiwidXJsIiwicmVzcG9uc2UiLCJmZXRjaCIsInJlc3VsdCIsImpzb24iLCJhbGVydCIsImUiLCJjb25zb2xlIiwibG9nIiwicG9zdERhdGEiLCJib2R5IiwibWV0aG9kIiwibW9kZSIsImhlYWRlcnMiLCJKU09OIiwic3RyaW5naWZ5IiwicG9zdERhdGFBbmRJbWFnZSIsImZvcm1EYXRhIiwiY29uZmlnIiwicG9zdCIsImRhdGEiLCJkZWxldGVEYXRhQXhpb3MiLCJVcmwiLCJkZWxldGUiLCJlcnJvciIsIkRpc3BsYXlhbGxfY29uc29sZXR5cGUiLCJzZXREYXRhIiwidXNlU3RhdGUiLCJvcGVuIiwic2V0T3BlbiIsImdldENvbnNvbGVfSWQiLCJzZXRDb25zb2xlX0lkIiwiZ2V0VHlwZSIsInNldFR5cGUiLCJnZXREZXNjcmlwdGlvbiIsInNldERlc2NyaXB0aW9uIiwiZ2V0SW1hZ2UiLCJzZXRJbWFnZSIsImljb24iLCJmaWxlIiwiZ2V0TWVzc2FnZSIsInNldE1lc3NhZ2UiLCJnZXRDb2x1bW5zIiwic2V0Q29sdW1ucyIsImNvbHVtbnMiLCJ0aXRsZSIsImZpZWxkIiwicmVuZGVyIiwicm93RGF0YSIsImltYWdlIiwiZmV0Y2hEYXRhIiwic3RhdHVzIiwidXNlRWZmZWN0IiwiaGFuZGxlQ2xvc2UiLCJoYW5kbGVJbWFnZSIsImV2ZW50IiwiVVJMIiwiY3JlYXRlT2JqZWN0VVJMIiwidGFyZ2V0IiwiZmlsZXMiLCJoYW5kbGVVcGRhdGUiLCJjb25zb2xlX3R5cGVfaWQiLCJ0eXBlIiwiZGVzY3JpcHRpb24iLCJoYW5kbGVEZWxldGUiLCJvbGREYXRhIiwiaGFuZGxlU3VibWl0IiwiRm9ybURhdGEiLCJhcHBlbmQiLCJoZWFkZXIiLCJyZW5kZXJFZGl0Rm9ybSIsInN0eWxlIiwid2lkdGgiLCJwYWRkaW5nIiwiYm9yZGVyUmFkaXVzIiwiYm94U2hhZG93IiwidmFsdWUiLCJkaXNwbGF5IiwiaGVpZ2h0IiwiaGVhZGVyU3R5bGUiLCJiYWNrZ3JvdW5kQ29sb3IiLCJjb2xvciIsImFjdGlvbnNDZWxsU3R5bGUiLCJ0b29sdGlwIiwib25DbGljayIsIm9uUm93RGVsZXRlIiwiUHJvbWlzZSIsInJlc29sdmUiLCJyZWplY3QiLCJzZXRUaW1lb3V0IiwiZGF0YURlbGV0ZSIsImluZGV4IiwidGFibGVEYXRhIiwiaWQiLCJzcGxpY2UiLCJtYXhXaWR0aCIsIm1hcmdpbiJdLCJtYXBwaW5ncyI6Ijs7UUFBQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLElBQUk7UUFDSjtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBOzs7UUFHQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMENBQTBDLGdDQUFnQztRQUMxRTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLHdEQUF3RCxrQkFBa0I7UUFDMUU7UUFDQSxpREFBaUQsY0FBYztRQUMvRDs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EseUNBQXlDLGlDQUFpQztRQUMxRSxnSEFBZ0gsbUJBQW1CLEVBQUU7UUFDckk7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwyQkFBMkIsMEJBQTBCLEVBQUU7UUFDdkQsaUNBQWlDLGVBQWU7UUFDaEQ7UUFDQTtRQUNBOztRQUVBO1FBQ0Esc0RBQXNELCtEQUErRDs7UUFFckg7UUFDQTs7O1FBR0E7UUFDQTs7Ozs7Ozs7Ozs7OztBQ3hGQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUFJQSxLQUFLLEdBQUNDLG1CQUFPLENBQUMsb0JBQUQsQ0FBakI7O0FBQ0EsTUFBTUMsU0FBUyxHQUFDLHVCQUFoQixDLENBQ0E7O0FBRUE7O0FBQ0EsTUFBTUMsT0FBTyxHQUFDLE1BQU1DLEdBQU4sSUFBWTtBQUN0QixNQUFHO0FBQ0QsVUFBTUMsUUFBUSxHQUFDLE1BQU1DLEtBQUssQ0FBRSxHQUFFSixTQUFVLElBQUdFLEdBQUksRUFBckIsQ0FBMUI7QUFDQSxVQUFNRyxNQUFNLEdBQUMsTUFBTUYsUUFBUSxDQUFDRyxJQUFULEVBQW5COztBQUNBLFFBQUdELE1BQU0sSUFBRSxpQ0FBWCxFQUNBO0FBQ0VFLFdBQUssQ0FBQ0YsTUFBRCxDQUFMO0FBQ0EsYUFBTyxFQUFQO0FBQ0QsS0FKRCxNQUtLO0FBQ0gsYUFBT0EsTUFBUDtBQUNBO0FBQ0gsR0FYRCxDQVdDLE9BQU1HLENBQU4sRUFBUTtBQUNKQyxXQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNKLFdBQU8sSUFBUDtBQUVBO0FBQ0osQ0FqQkQ7QUFtQkE7OztBQUNBLE1BQU1HLFFBQVEsR0FBQyxPQUFNVCxHQUFOLEVBQVVVLElBQVYsS0FBaUI7QUFDNUIsTUFBRztBQUNELFVBQU1ULFFBQVEsR0FBQyxNQUFNQyxLQUFLLENBQUUsR0FBRUosU0FBVSxJQUFHRSxHQUFJLEVBQXJCLEVBQzFCO0FBQUNXLFlBQU0sRUFBQyxNQUFSO0FBQWVDLFVBQUksRUFBQyxNQUFwQjtBQUNDQyxhQUFPLEVBQUM7QUFBQyx3QkFBZTtBQUFoQixPQURUO0FBRUNILFVBQUksRUFBQ0ksSUFBSSxDQUFDQyxTQUFMLENBQWVMLElBQWY7QUFGTixLQUQwQixDQUExQjtBQUtBLFVBQU1QLE1BQU0sR0FBQyxNQUFNRixRQUFRLENBQUNHLElBQVQsRUFBbkI7O0FBQ0EsUUFBR0QsTUFBTSxJQUFFLGlDQUFYLEVBQ0E7QUFBRUUsV0FBSyxDQUFDRixNQUFELENBQUw7QUFDRCxhQUFPLEVBQVA7QUFDQSxLQUhELE1BSUk7QUFFSjtBQUNBLGFBQU9BLE1BQVA7QUFDQztBQUVGLEdBakJELENBaUJDLE9BQU1HLENBQU4sRUFBUTtBQUNKQyxXQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNKLFdBQU8sSUFBUDtBQUVBO0FBQ0osQ0F2QkQ7QUF5QkE7OztBQUNBLE1BQU1VLGdCQUFnQixHQUFDLE9BQU1oQixHQUFOLEVBQVVpQixRQUFWLEVBQW1CQyxNQUFuQixLQUE0QjtBQUMvQyxNQUFHO0FBQ0EsUUFBSWpCLFFBQVEsR0FBQyxNQUFNTCxLQUFLLENBQUN1QixJQUFOLENBQVksR0FBRXJCLFNBQVUsSUFBR0UsR0FBSSxFQUEvQixFQUFpQ2lCLFFBQWpDLEVBQTBDQyxNQUExQyxDQUFuQixDQURBLENBRUQ7O0FBQ0MsUUFBR2pCLFFBQVEsQ0FBQ21CLElBQVQsSUFBZSxpQ0FBbEIsRUFDRDtBQUFFZixXQUFLLENBQUNKLFFBQVEsQ0FBQ21CLElBQVYsQ0FBTDtBQUNELGFBQU8sS0FBUDtBQUNBLEtBSEEsTUFJRztBQUVILFlBQU1qQixNQUFNLEdBQUMsTUFBTUYsUUFBUSxDQUFDbUIsSUFBNUI7QUFDQSxhQUFRakIsTUFBUjtBQUNBO0FBRUYsR0FiRCxDQWNBLE9BQU1HLENBQU4sRUFBUTtBQUVOLFdBQU8sSUFBUDtBQUNEO0FBQ0YsQ0FuQkg7O0FBb0JFLE1BQU1lLGVBQWUsR0FBRyxNQUFPQyxHQUFQLElBQWU7QUFDckMsTUFBSTtBQUNGLFFBQUl0QixHQUFHLEdBQUksR0FBRUYsU0FBVSxJQUFHd0IsR0FBSSxFQUE5QjtBQUNBLFVBQU1KLE1BQU0sR0FBRztBQUFFLHNCQUFnQjtBQUFsQixLQUFmO0FBQ0EsVUFBTWpCLFFBQVEsR0FBRyxNQUFNTCxLQUFLLENBQUMyQixNQUFOLENBQWF2QixHQUFiLEVBQWtCa0IsTUFBbEIsQ0FBdkI7QUFDQSxRQUFJZixNQUFNLEdBQUdGLFFBQVEsQ0FBQ21CLElBQXRCO0FBQ0FiLFdBQU8sQ0FBQ0MsR0FBUixDQUFZTCxNQUFaO0FBQ0EsV0FBT0EsTUFBUDtBQUNELEdBUEQsQ0FPRSxPQUFPcUIsS0FBUCxFQUFjO0FBQ2RqQixXQUFPLENBQUNDLEdBQVIsQ0FBWWdCLEtBQVo7QUFDRDtBQUNGLENBWEQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN2RUY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFZ0IsU0FBU0Msc0JBQVQsR0FBa0M7QUFDaEQsUUFBTTtBQUFBLE9BQUNMLElBQUQ7QUFBQSxPQUFPTTtBQUFQLE1BQWtCQyxzREFBUSxDQUFDLEVBQUQsQ0FBaEM7QUFDQSxRQUFNO0FBQUEsT0FBQ0MsSUFBRDtBQUFBLE9BQU9DO0FBQVAsTUFBa0JGLHNEQUFRLENBQUMsS0FBRCxDQUFoQztBQUNBLFFBQU07QUFBQSxPQUFDRyxhQUFEO0FBQUEsT0FBZ0JDO0FBQWhCLE1BQWdDSixzREFBUSxDQUFDLEVBQUQsQ0FBOUM7QUFDQSxRQUFNO0FBQUEsT0FBQ0ssT0FBRDtBQUFBLE9BQVVDO0FBQVYsTUFBcUJOLHNEQUFRLENBQUMsRUFBRCxDQUFuQztBQUNBLFFBQU07QUFBQSxPQUFDTyxjQUFEO0FBQUEsT0FBaUJDO0FBQWpCLE1BQW1DUixzREFBUSxDQUFDLEVBQUQsQ0FBakQ7QUFDQSxRQUFNO0FBQUEsT0FBQ1MsUUFBRDtBQUFBLE9BQVdDO0FBQVgsTUFBcUJWLHNEQUFRLENBQUM7QUFBQ1csUUFBSSxFQUFDLEVBQU47QUFBVUMsUUFBSSxFQUFDO0FBQWYsR0FBRCxDQUFuQztBQUNBLFFBQU07QUFBQSxPQUFDQyxVQUFEO0FBQUEsT0FBYUM7QUFBYixNQUEyQmQsc0RBQVEsQ0FBQyxFQUFELENBQXpDO0FBQ0EsUUFBTTtBQUFBLE9BQUNlLFVBQUQ7QUFBQSxPQUFhQztBQUFiLE1BQTJCaEIsc0RBQVEsQ0FBQztBQUN4Q2lCLFdBQU8sRUFBQyxDQUNSO0FBQUVDLFdBQUssRUFBRSxNQUFUO0FBQWlCQyxXQUFLLEVBQUU7QUFBeEIsS0FEUSxFQUVSO0FBQUVELFdBQUssRUFBRSxhQUFUO0FBQXdCQyxXQUFLLEVBQUU7QUFBL0IsS0FGUSxFQUdSO0FBQUVELFdBQUssRUFBRSxPQUFUO0FBQWtCQyxXQUFLLEVBQUUsT0FBekI7QUFDQUMsWUFBTSxFQUFHQyxPQUFELGlCQUNKO0FBQUEsK0JBQ0UscUVBQUMsK0RBQUQ7QUFDRSxpQkFBTyxFQUFDLFNBRFY7QUFFRSxhQUFHLEVBQUcsR0FBRWxELHdEQUFVLFdBQVVrRCxPQUFPLENBQUNDLEtBQU07QUFGNUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFGSixLQUhRO0FBRGdDLEdBQUQsQ0FBekM7O0FBaUJBLFFBQU1DLFNBQVMsR0FBRyxZQUFZO0FBQzVCLFVBQU0vQyxNQUFNLEdBQUcsTUFBTUosOERBQU8sQ0FBQyxxQkFBRCxDQUE1QjtBQUNBUSxXQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaLEVBQW1CTCxNQUFuQjtBQUNBQSxVQUFNLENBQUNnRCxNQUFQLElBQWlCekIsT0FBTyxDQUFDdkIsTUFBTSxDQUFDQSxNQUFSLENBQXhCO0FBQ0QsR0FKRDs7QUFNQWlELHlEQUFTLENBQUMsTUFBTTtBQUNkRixhQUFTO0FBQ1YsR0FGUSxFQUVOLEVBRk0sQ0FBVDs7QUFJQSxRQUFNRyxXQUFXLEdBQUcsTUFBTTtBQUN4QnhCLFdBQU8sQ0FBQyxLQUFELENBQVAsQ0FEd0IsQ0FFeEI7QUFDRCxHQUhEO0FBS0E7OztBQUNBLFFBQU15QixXQUFXLEdBQUlDLEtBQUQsSUFBVztBQUM3QmxCLFlBQVEsQ0FBQztBQUNQQyxVQUFJLEVBQUVrQixHQUFHLENBQUNDLGVBQUosQ0FBb0JGLEtBQUssQ0FBQ0csTUFBTixDQUFhQyxLQUFiLENBQW1CLENBQW5CLENBQXBCLENBREM7QUFFUHBCLFVBQUksRUFBRWdCLEtBQUssQ0FBQ0csTUFBTixDQUFhQyxLQUFiLENBQW1CLENBQW5CO0FBRkMsS0FBRCxDQUFSO0FBSUQsR0FMRDs7QUFPQSxRQUFNQyxZQUFZLEdBQUlaLE9BQUQsSUFBYTtBQUNoQ2pCLGlCQUFhLENBQUNpQixPQUFPLENBQUNhLGVBQVQsQ0FBYjtBQUNBNUIsV0FBTyxDQUFDZSxPQUFPLENBQUNjLElBQVQsQ0FBUDtBQUNBM0Isa0JBQWMsQ0FBQ2EsT0FBTyxDQUFDZSxXQUFULENBQWQ7QUFDQTFCLFlBQVEsQ0FBQztBQUFFQyxVQUFJLEVBQUcsR0FBRXhDLHdEQUFVLFdBQVVrRCxPQUFPLENBQUNDLEtBQU0sRUFBN0M7QUFBZ0RWLFVBQUksRUFBRTtBQUF0RCxLQUFELENBQVI7QUFDQVYsV0FBTyxDQUFDLElBQUQsQ0FBUDtBQUNELEdBTkQsQ0FoRGdELENBd0RoRDtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsUUFBTW1DLFlBQVksR0FBRyxNQUFPQyxPQUFQLElBQW1CO0FBQ3RDO0FBQ0UsVUFBTTVDLHNFQUFlLENBQUUsc0JBQXFCNEMsT0FBTyxDQUFDSixlQUFnQixFQUEvQyxDQUFyQjtBQUNILEdBSEQ7O0FBTUEsUUFBTUssWUFBWSxHQUFHLE1BQU81RCxDQUFQLElBQWE7QUFFNUIsUUFBSVcsUUFBUSxHQUFHLElBQUlrRCxRQUFKLEVBQWY7QUFDSWxELFlBQVEsQ0FBQ21ELE1BQVQsQ0FBZ0IsaUJBQWhCLEVBQWtDdEMsYUFBbEM7QUFDQWIsWUFBUSxDQUFDbUQsTUFBVCxDQUFnQixNQUFoQixFQUF1QnBDLE9BQXZCLEdBQ0FmLFFBQVEsQ0FBQ21ELE1BQVQsQ0FBZ0IsYUFBaEIsRUFBOEJsQyxjQUE5QixDQURBLEVBRUFqQixRQUFRLENBQUNtRCxNQUFULENBQWdCLE9BQWhCLEVBQXdCaEMsUUFBUSxDQUFDRyxJQUFqQyxDQUZBO0FBR0EsUUFBSXJCLE1BQU0sR0FBQztBQUFDbUQsWUFBTSxFQUFDO0FBQUMsd0JBQWU7QUFBaEI7QUFBUixLQUFYLENBUHdCLENBUXhCO0FBQ0E7O0FBQ0EsUUFBSWxFLE1BQU0sR0FBRyxNQUFNYSx1RUFBZ0IsQ0FBRSxzQkFBcUJjLGFBQWMsRUFBckMsRUFBdUNiLFFBQXZDLEVBQWdEQyxNQUFoRCxDQUFuQztBQUNSZ0MsYUFBUztBQUNURyxlQUFXOztBQUVYLFFBQUdsRCxNQUFILEVBQ0E7QUFBRTtBQUNGc0MsZ0JBQVUsQ0FBQyxnQkFBRCxDQUFWO0FBQ0MsS0FIRCxNQUlJO0FBQ1I7QUFDSUEsZ0JBQVUsQ0FBQyx1QkFBRCxDQUFWO0FBQ0M7QUFFRixHQXZCRDs7QUF5QkEsUUFBTTZCLGNBQWMsR0FBSWhFLENBQUQsSUFBTztBQUM1QixVQUFNaUUsS0FBSyxHQUFHO0FBQ1pDLFdBQUssRUFBRSxHQURLO0FBRVpDLGFBQU8sRUFBRSxFQUZHO0FBR1pDLGtCQUFZLEVBQUUsQ0FIRjtBQUlaQyxlQUFTLEVBQUU7QUFKQyxLQUFkO0FBTUEsd0JBQ0o7QUFBSyxRQUFFLEVBQUMsMEJBQVI7QUFBQSw4QkFDVztBQUFLLFVBQUUsRUFBQyxtQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURYLGVBRWdCO0FBQUssYUFBSyxFQUFDLFVBQVg7QUFBQSxnQ0FDSTtBQUFLLGVBQUssRUFBQyxlQUFYO0FBQUEsa0NBQ0E7QUFBTyxlQUFHLEVBQUMsb0JBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREEsZUFFQTtBQUFPLGdCQUFJLEVBQUMsTUFBWjtBQUFtQixpQkFBSyxFQUFDLGNBQXpCO0FBQXdDLGNBQUUsRUFBQyxvQkFBM0M7QUFDQSxpQkFBSyxFQUFFM0MsT0FEUDtBQUNnQixvQkFBUSxFQUFHdUIsS0FBRCxJQUFTdEIsT0FBTyxDQUFDc0IsS0FBSyxDQUFDRyxNQUFOLENBQWFrQixLQUFkLENBRDFDO0FBQ2dFLG9CQUFRO0FBRHhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRkEsZUFJQTtBQUFLLGlCQUFLLEVBQUMsZ0JBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURKLGVBU0k7QUFBSyxlQUFLLEVBQUMsZUFBWDtBQUFBLGtDQUNBO0FBQU8sZUFBRyxFQUFDLG9CQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURBLGVBRUE7QUFBTyxnQkFBSSxFQUFDLE1BQVo7QUFBbUIsaUJBQUssRUFBQyxjQUF6QjtBQUF3QyxjQUFFLEVBQUMsb0JBQTNDO0FBQ0EsaUJBQUssRUFBRTFDLGNBRFA7QUFDdUIsb0JBQVEsRUFBR3FCLEtBQUQsSUFBU3BCLGNBQWMsQ0FBQ29CLEtBQUssQ0FBQ0csTUFBTixDQUFha0IsS0FBZCxDQUR4RDtBQUM4RSxvQkFBUTtBQUR0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUZBLGVBSUE7QUFBSyxpQkFBSyxFQUFDLGdCQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUpBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFUSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGaEIsZUFvQm1CO0FBQUssYUFBSyxFQUFDLFVBQVg7QUFBQSwrQkFDQztBQUFLLGVBQUssRUFBQyxlQUFYO0FBQUEsa0NBR0E7QUFDSyxrQkFBTSxFQUFDLFNBRFosQ0FFSTtBQUZKO0FBR0ssY0FBRSxFQUFDLHVCQUhSO0FBSUssb0JBQVEsTUFKYjtBQUtLLGdCQUFJLEVBQUMsTUFMVjtBQU1JLGlCQUFLLEVBQUU7QUFBQ0MscUJBQU8sRUFBQztBQUFULGFBTlg7QUFPSSxvQkFBUSxFQUFHdEIsS0FBRCxJQUFTRCxXQUFXLENBQUNDLEtBQUQ7QUFQbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFIQSxlQVlBO0FBQU8sbUJBQU8sRUFBQyx1QkFBZjtBQUFBLG1DQUNJLHFFQUFDLCtEQUFEO0FBQVEscUJBQU8sRUFBQyxXQUFoQjtBQUE0QixtQkFBSyxFQUFDLFNBQWxDO0FBQTRDLHVCQUFTLEVBQUMsTUFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVpBLGVBaUJBLHFFQUFDLCtEQUFEO0FBQVEsY0FBRSxFQUFDLGdCQUFYO0FBQTRCLGlCQUFLLEVBQUU7QUFBQ2lCLG1CQUFLLEVBQUMsRUFBUDtBQUFVTSxvQkFBTSxFQUFDO0FBQWpCLGFBQW5DO0FBQXlELGVBQUcsRUFBRTFDLFFBQVEsQ0FBQ0U7QUFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFqQkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXBCbkIsZUEwQ29CLHFFQUFDLCtEQUFEO0FBQVEsZUFBTyxFQUFDLFdBQWhCO0FBQTRCLGFBQUssRUFBQyxTQUFsQztBQUE0Qyx3QkFBZ0IsTUFBNUQ7QUFBNkQsVUFBRSxFQUFDLGFBQWhFO0FBQThFLGVBQU8sRUFBRSxNQUFJNEIsWUFBWSxFQUF2RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQTFDcEIsZUE4Q2dCO0FBQUEsZ0NBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQUVFO0FBQUEsaUNBQVE7QUFBQSxzQkFBSTFCO0FBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBOUNoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFESTtBQXNERCxHQTdERDs7QUErREEsc0JBQ0U7QUFBQSw0QkFDRSxxRUFBQyxxREFBRDtBQUNFLFdBQUssRUFBQyxrQkFEUjtBQUVFLGFBQU8sRUFBRUUsVUFBVSxDQUFDRSxPQUZ0QjtBQUdFLFVBQUksRUFBRXhCLElBSFI7QUFJRSxhQUFPLEVBQUU7QUFDUDJELG1CQUFXLEVBQUU7QUFDWEMseUJBQWUsRUFBRSxTQUROO0FBRVhDLGVBQUssRUFBRTtBQUZJLFNBRE47QUFLUEMsd0JBQWdCLEVBQUU7QUFDaEJULGlCQUFPLEVBQUU7QUFETztBQUxYLE9BSlg7QUFhRSxhQUFPLEVBQUUsQ0FDUDtBQUNFbkMsWUFBSSxFQUFFLE1BRFI7QUFFRTZDLGVBQU8sRUFBRSxNQUZYO0FBR0VDLGVBQU8sRUFBRSxDQUFDN0IsS0FBRCxFQUFRUCxPQUFSLEtBQW9CO0FBQzNCWSxzQkFBWSxDQUFDWixPQUFELENBQVo7QUFDRDtBQUxILE9BRE8sQ0FiWDtBQXNCRSxjQUFRLEVBQUU7QUFDUnFDLG1CQUFXLEVBQUdwQixPQUFELElBQ1gsSUFBSXFCLE9BQUosQ0FBWSxDQUFDQyxPQUFELEVBQVVDLE1BQVYsS0FBcUI7QUFDL0JDLG9CQUFVLENBQUMsTUFBTTtBQUNmLGtCQUFNQyxVQUFVLEdBQUcsQ0FBQyxHQUFHdEUsSUFBSixDQUFuQjtBQUNBLGtCQUFNdUUsS0FBSyxHQUFHMUIsT0FBTyxDQUFDMkIsU0FBUixDQUFrQkMsRUFBaEM7QUFDQUgsc0JBQVUsQ0FBQ0ksTUFBWCxDQUFrQkgsS0FBbEIsRUFBeUIsQ0FBekI7QUFDQWpFLG1CQUFPLENBQUMsQ0FBQyxHQUFHZ0UsVUFBSixDQUFELENBQVA7QUFDQTFCLHdCQUFZLENBQUNDLE9BQUQsQ0FBWjtBQUNBc0IsbUJBQU87QUFDUixXQVBTLEVBT1AsSUFQTyxDQUFWO0FBUUQsU0FURDtBQUZNO0FBdEJaO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQXFDRSxxRUFBQyx3REFBRCxDQUNFO0FBREY7QUFFRSxjQUFRLEVBQUMsSUFGWDtBQUdFLFVBQUksRUFBRTNELElBSFI7QUFJRSxhQUFPLEVBQUV5QixXQUpYO0FBS0UseUJBQWdCLHlCQUxsQjtBQUFBLGdCQU9HaUIsY0FBYztBQVBqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBckNGO0FBQUEsa0JBREY7QUFpREQ7QUFFRCxNQUFNQyxLQUFLLEdBQUc7QUFDWndCLFVBQVEsRUFBRSxLQURFO0FBRVpDLFFBQU0sRUFBRSxXQUZJO0FBR1p0QixjQUFZLEVBQUUsQ0FIRjtBQUlaQyxXQUFTLEVBQUU7QUFKQyxDQUFkLEMsQ0FPQTtBQUNBO0FBQ0EsSzs7Ozs7Ozs7Ozs7QUNsT0EsOEM7Ozs7Ozs7Ozs7O0FDQUEscUQ7Ozs7Ozs7Ozs7O0FDQUEscUQ7Ozs7Ozs7Ozs7O0FDQUEsa0M7Ozs7Ozs7Ozs7O0FDQUEsMkM7Ozs7Ozs7Ozs7O0FDQUEsa0M7Ozs7Ozs7Ozs7O0FDQUEsa0Q7Ozs7Ozs7Ozs7O0FDQUEsd0MiLCJmaWxlIjoicGFnZXMvQWRtaW4vRGlzcGxheWFsbF9jb25zb2xldHlwZS5qcyIsInNvdXJjZXNDb250ZW50IjpbIiBcdC8vIFRoZSBtb2R1bGUgY2FjaGVcbiBcdHZhciBpbnN0YWxsZWRNb2R1bGVzID0gcmVxdWlyZSgnLi4vLi4vc3NyLW1vZHVsZS1jYWNoZS5qcycpO1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHR2YXIgdGhyZXcgPSB0cnVlO1xuIFx0XHR0cnkge1xuIFx0XHRcdG1vZHVsZXNbbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuIFx0XHRcdHRocmV3ID0gZmFsc2U7XG4gXHRcdH0gZmluYWxseSB7XG4gXHRcdFx0aWYodGhyZXcpIGRlbGV0ZSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXTtcbiBcdFx0fVxuXG4gXHRcdC8vIEZsYWcgdGhlIG1vZHVsZSBhcyBsb2FkZWRcbiBcdFx0bW9kdWxlLmwgPSB0cnVlO1xuXG4gXHRcdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG4gXHRcdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbiBcdH1cblxuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tID0gbW9kdWxlcztcblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGUgY2FjaGVcbiBcdF9fd2VicGFja19yZXF1aXJlX18uYyA9IGluc3RhbGxlZE1vZHVsZXM7XG5cbiBcdC8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb24gZm9yIGhhcm1vbnkgZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kID0gZnVuY3Rpb24oZXhwb3J0cywgbmFtZSwgZ2V0dGVyKSB7XG4gXHRcdGlmKCFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywgbmFtZSkpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgbmFtZSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGdldHRlciB9KTtcbiBcdFx0fVxuIFx0fTtcblxuIFx0Ly8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yID0gZnVuY3Rpb24oZXhwb3J0cykge1xuIFx0XHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcbiBcdFx0fVxuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xuIFx0fTtcblxuIFx0Ly8gY3JlYXRlIGEgZmFrZSBuYW1lc3BhY2Ugb2JqZWN0XG4gXHQvLyBtb2RlICYgMTogdmFsdWUgaXMgYSBtb2R1bGUgaWQsIHJlcXVpcmUgaXRcbiBcdC8vIG1vZGUgJiAyOiBtZXJnZSBhbGwgcHJvcGVydGllcyBvZiB2YWx1ZSBpbnRvIHRoZSBuc1xuIFx0Ly8gbW9kZSAmIDQ6IHJldHVybiB2YWx1ZSB3aGVuIGFscmVhZHkgbnMgb2JqZWN0XG4gXHQvLyBtb2RlICYgOHwxOiBiZWhhdmUgbGlrZSByZXF1aXJlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnQgPSBmdW5jdGlvbih2YWx1ZSwgbW9kZSkge1xuIFx0XHRpZihtb2RlICYgMSkgdmFsdWUgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKHZhbHVlKTtcbiBcdFx0aWYobW9kZSAmIDgpIHJldHVybiB2YWx1ZTtcbiBcdFx0aWYoKG1vZGUgJiA0KSAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlICYmIHZhbHVlLl9fZXNNb2R1bGUpIHJldHVybiB2YWx1ZTtcbiBcdFx0dmFyIG5zID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yKG5zKTtcbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KG5zLCAnZGVmYXVsdCcsIHsgZW51bWVyYWJsZTogdHJ1ZSwgdmFsdWU6IHZhbHVlIH0pO1xuIFx0XHRpZihtb2RlICYgMiAmJiB0eXBlb2YgdmFsdWUgIT0gJ3N0cmluZycpIGZvcih2YXIga2V5IGluIHZhbHVlKSBfX3dlYnBhY2tfcmVxdWlyZV9fLmQobnMsIGtleSwgZnVuY3Rpb24oa2V5KSB7IHJldHVybiB2YWx1ZVtrZXldOyB9LmJpbmQobnVsbCwga2V5KSk7XG4gXHRcdHJldHVybiBucztcbiBcdH07XG5cbiBcdC8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSBmdW5jdGlvbihtb2R1bGUpIHtcbiBcdFx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0RGVmYXVsdCgpIHsgcmV0dXJuIG1vZHVsZVsnZGVmYXVsdCddOyB9IDpcbiBcdFx0XHRmdW5jdGlvbiBnZXRNb2R1bGVFeHBvcnRzKCkgeyByZXR1cm4gbW9kdWxlOyB9O1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCAnYScsIGdldHRlcik7XG4gXHRcdHJldHVybiBnZXR0ZXI7XG4gXHR9O1xuXG4gXHQvLyBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGxcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubyA9IGZ1bmN0aW9uKG9iamVjdCwgcHJvcGVydHkpIHsgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIHByb3BlcnR5KTsgfTtcblxuIFx0Ly8gX193ZWJwYWNrX3B1YmxpY19wYXRoX19cbiBcdF9fd2VicGFja19yZXF1aXJlX18ucCA9IFwiXCI7XG5cblxuIFx0Ly8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4gXHRyZXR1cm4gX193ZWJwYWNrX3JlcXVpcmVfXyhfX3dlYnBhY2tfcmVxdWlyZV9fLnMgPSBcIi4vcGFnZXMvQWRtaW4vRGlzcGxheWFsbF9jb25zb2xldHlwZS5qc1wiKTtcbiIsInZhciBheGlvcz1yZXF1aXJlKFwiYXhpb3NcIilcbmNvbnN0IFNlcnZlclVSTD0naHR0cDovL2xvY2FsaG9zdDo0MDAwJ1xuLy90byByZWFkIGFsbCBkYXRhIGZyb20gbm9kZVxuXG4vKiBnZXQgZGF0YSovXG5jb25zdCBnZXREYXRhPWFzeW5jKHVybCk9PntcbiAgICB0cnl7XG4gICAgICBjb25zdCByZXNwb25zZT1hd2FpdCBmZXRjaChgJHtTZXJ2ZXJVUkx9LyR7dXJsfWApXG4gICAgICBjb25zdCByZXN1bHQ9YXdhaXQgcmVzcG9uc2UuanNvbigpXG4gICAgICBpZihyZXN1bHQ9PSdTZXNzaW9uIEV4cGlyZWQgUGxzIExvZ2luIEFnYWluJylcbiAgICAgIHtcbiAgICAgICAgYWxlcnQocmVzdWx0KVxuICAgICAgICByZXR1cm4oW10pXG4gICAgICB9XG4gICAgICAgZWxzZXtcbiAgICAgICAgcmV0dXJuIHJlc3VsdFxuICAgICAgIH1cbiAgICB9Y2F0Y2goZSl7XG4gICAgICAgICBjb25zb2xlLmxvZyhlKVxuICAgICByZXR1cm4gbnVsbFxuXG4gICAgfVxufVxuXG4vKiBwb3N0IGRhdGEgKi8gICAgICAgICAgICAgICAgICAgICAgICBcbmNvbnN0IHBvc3REYXRhPWFzeW5jKHVybCxib2R5KT0+e1xuICAgIHRyeXtcbiAgICAgIGNvbnN0IHJlc3BvbnNlPWF3YWl0IGZldGNoKGAke1NlcnZlclVSTH0vJHt1cmx9YCxcbiAgICAgIHttZXRob2Q6XCJQT1NUXCIsbW9kZTpcImNvcnNcIixcbiAgICAgICBoZWFkZXJzOntcIkNvbnRlbnQtVHlwZVwiOlwiYXBwbGljYXRpb24vanNvbjtjaGFyc2V0PXV0Zi04XCJ9LFxuICAgICAgIGJvZHk6SlNPTi5zdHJpbmdpZnkoYm9keSlcbiAgICAgIH0pXG4gICAgICBjb25zdCByZXN1bHQ9YXdhaXQgcmVzcG9uc2UuanNvbigpXG4gICAgICBpZihyZXN1bHQ9PSdTZXNzaW9uIEV4cGlyZWQgUGxzIExvZ2luIEFnYWluJykgXG4gICAgICB7IGFsZXJ0KHJlc3VsdClcbiAgICAgICByZXR1cm4oW10pXG4gICAgICB9XG4gICAgICBlbHNle1xuXG4gICAgICAvL2NvbnN0IHJlc3VsdD1hd2FpdCByZXNwb25zZS5qc29uKClcbiAgICAgIHJldHVybiByZXN1bHRcbiAgICAgIH1cblxuICAgIH1jYXRjaChlKXtcbiAgICAgICAgIGNvbnNvbGUubG9nKGUpXG4gICAgIHJldHVybiBudWxsXG5cbiAgICB9XG59XG5cbi8qIHBvc3QgYW5kIGltYWdlIGRhdGEqL1xuY29uc3QgcG9zdERhdGFBbmRJbWFnZT1hc3luYyh1cmwsZm9ybURhdGEsY29uZmlnKT0+e1xuICAgIHRyeXtcbiAgICAgICB2YXIgcmVzcG9uc2U9YXdhaXQgYXhpb3MucG9zdChgJHtTZXJ2ZXJVUkx9LyR7dXJsfWAsZm9ybURhdGEsY29uZmlnKVxuICAgICAgLy8gIGNvbnN0IHJlc3VsdD1hd2FpdCByZXNwb25zZS5kYXRhLlJFU1VMVCBcbiAgICAgICBpZihyZXNwb25zZS5kYXRhPT0nU2Vzc2lvbiBFeHBpcmVkIFBscyBMb2dpbiBBZ2FpbicpIFxuICAgICAgeyBhbGVydChyZXNwb25zZS5kYXRhKVxuICAgICAgIHJldHVybihmYWxzZSlcbiAgICAgIH1cbiAgICAgIGVsc2V7XG4gICAgICBcbiAgICAgICBjb25zdCByZXN1bHQ9YXdhaXQgcmVzcG9uc2UuZGF0YSBcbiAgICAgICByZXR1cm4gKHJlc3VsdClcbiAgICAgIH1cbiAgICAgIFxuICAgIH1cbiAgICBjYXRjaChlKXtcbiAgICAgIFxuICAgICAgcmV0dXJuIG51bGxcbiAgICB9XG4gIH1cbiAgY29uc3QgZGVsZXRlRGF0YUF4aW9zID0gYXN5bmMgKFVybCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICB2YXIgdXJsID0gYCR7U2VydmVyVVJMfS8ke1VybH1gO1xuICAgICAgY29uc3QgY29uZmlnID0geyBcImNvbnRlbnQtdHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9O1xuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBheGlvcy5kZWxldGUodXJsLCBjb25maWcpO1xuICAgICAgdmFyIHJlc3VsdCA9IHJlc3BvbnNlLmRhdGE7XG4gICAgICBjb25zb2xlLmxvZyhyZXN1bHQpO1xuICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xuICAgIH1cbiAgfTtcblxuICAgIGV4cG9ydCB7Z2V0RGF0YSxwb3N0RGF0YSxwb3N0RGF0YUFuZEltYWdlLGRlbGV0ZURhdGFBeGlvcyxTZXJ2ZXJVUkx9IiwiaW1wb3J0IHsgRGlhbG9nIH0gZnJvbSBcIkBtYXRlcmlhbC11aS9jb3JlXCI7XHJcbmltcG9ydCBNYXRlcmlhbFRhYmxlIGZyb20gXCJtYXRlcmlhbC10YWJsZVwiO1xyXG5pbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgQnV0dG9uIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0J1dHRvbic7XHJcbmltcG9ydCBBdmF0YXIgZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvQXZhdGFyJztcclxuaW1wb3J0IHtnZXREYXRhLHBvc3REYXRhLHBvc3REYXRhQW5kSW1hZ2UsZGVsZXRlRGF0YUF4aW9zLFNlcnZlclVSTH0gZnJvbSAnLi4vLi4vRmV0Y2hTZXJ2aWNlcyc7XHJcbmltcG9ydCBTd2FsIGZyb20gJ3N3ZWV0YWxlcnQyJ1xyXG4vKipcclxuICogQGF1dGhvclxyXG4gKiBAZnVuY3Rpb24gQ2F0ZWdvcnlEaXNwbGF5XHJcbiAqKi9cclxuXHJcbiBleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBEaXNwbGF5YWxsX2NvbnNvbGV0eXBlKCkge1xyXG4gIGNvbnN0IFtkYXRhLCBzZXREYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbb3Blbiwgc2V0T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2dldENvbnNvbGVfSWQsIHNldENvbnNvbGVfSWRdPSB1c2VTdGF0ZShcIlwiKVxyXG4gIGNvbnN0IFtnZXRUeXBlLCBzZXRUeXBlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtnZXREZXNjcmlwdGlvbiwgc2V0RGVzY3JpcHRpb25dID0gdXNlU3RhdGUoXCJcIilcclxuICBjb25zdCBbZ2V0SW1hZ2UsIHNldEltYWdlXT11c2VTdGF0ZSh7aWNvbjonJywgZmlsZTonJ30pXHJcbiAgY29uc3QgW2dldE1lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUoXCJcIilcclxuICBjb25zdCBbZ2V0Q29sdW1ucywgc2V0Q29sdW1uc10gPSB1c2VTdGF0ZSh7XHJcbiAgICBjb2x1bW5zOlsgIFxyXG4gICAgeyB0aXRsZTogXCJUeXBlXCIsIGZpZWxkOiBcInR5cGVcIiB9LFxyXG4gICAgeyB0aXRsZTogXCJEZXNjcmlwdGlvblwiLCBmaWVsZDogXCJkZXNjcmlwdGlvblwiIH0sXHJcbiAgICB7IHRpdGxlOiBcIkltYWdlXCIsIGZpZWxkOiBcImltYWdlXCIsXHJcbiAgICByZW5kZXI6IChyb3dEYXRhKSA9PiAoXHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxBdmF0YXJcclxuICAgICAgICAgICAgdmFyaWFudD1cInJvdW5kZWRcIlxyXG4gICAgICAgICAgICBzcmM9e2Ake1NlcnZlclVSTH0vaW1hZ2VzLyR7cm93RGF0YS5pbWFnZX1gfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSxcclxufSxcclxuICAgIF1cclxuICAgIH0pO1xyXG5cclxuICBjb25zdCBmZXRjaERhdGEgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBnZXREYXRhKFwiY29uc29sZXR5cGUvZGlzcGxheVwiKTtcclxuICAgIGNvbnNvbGUubG9nKFwiZGF0YVwiLHJlc3VsdCk7XHJcbiAgICByZXN1bHQuc3RhdHVzICYmIHNldERhdGEocmVzdWx0LnJlc3VsdCk7XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoRGF0YSgpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2xvc2UgPSAoKSA9PiB7XHJcbiAgICBzZXRPcGVuKGZhbHNlKTtcclxuICAgIC8vIGZldGNoRGF0YSgpXHJcbiAgfTtcclxuXHJcbiAgLyogaGFuZGxlIGluIGljb24qL1xyXG4gIGNvbnN0IGhhbmRsZUltYWdlID0gKGV2ZW50KSA9PiB7XHJcbiAgICBzZXRJbWFnZSh7XHJcbiAgICAgIGljb246IFVSTC5jcmVhdGVPYmplY3RVUkwoZXZlbnQudGFyZ2V0LmZpbGVzWzBdKSxcclxuICAgICAgZmlsZTogZXZlbnQudGFyZ2V0LmZpbGVzWzBdLFxyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlID0gKHJvd0RhdGEpID0+IHtcclxuICAgIHNldENvbnNvbGVfSWQocm93RGF0YS5jb25zb2xlX3R5cGVfaWQpO1xyXG4gICAgc2V0VHlwZShyb3dEYXRhLnR5cGUpO1xyXG4gICAgc2V0RGVzY3JpcHRpb24ocm93RGF0YS5kZXNjcmlwdGlvbik7XHJcbiAgICBzZXRJbWFnZSh7IGljb246IGAke1NlcnZlclVSTH0vaW1hZ2VzLyR7cm93RGF0YS5pbWFnZX1gLCBmaWxlOiBcIlwiIH0pO1xyXG4gICAgc2V0T3Blbih0cnVlKTtcclxuICB9O1xyXG5cclxuICAvLyBjb25zdCBoYW5kbGVEZWxldGUgPSBhc3luYyAob2xkRGF0YSkgPT4ge1xyXG4gIC8vICAgLy8gbGV0IGJvZHkgPSB7IGdldENvbnNvbGVfSWQ6IG9sZERhdGEuY29uc29sZV90eXBlX2lkIH07XHJcbiAgLy8gICBhd2FpdCBkZWxldGVEYXRhQXhpb3MoYGNvbnNvbGV0eXBlL2RlbGV0ZS8ke29sZERhdGEuZ2V0Q29uc29sZV9JZH1gKTtcclxuICAvLyB9O1xyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZSA9IGFzeW5jIChvbGREYXRhKSA9PiB7XHJcbiAgICAvLyBjb25zb2xlLmxvZyhcIm9sZERhdGFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhXCIsSlNPTi5zdHJpbmdpZnkob2xkRGF0YSkpXHJcbiAgICAgIGF3YWl0IGRlbGV0ZURhdGFBeGlvcyhgY29uc29sZXR5cGUvZGVsZXRlLyR7b2xkRGF0YS5jb25zb2xlX3R5cGVfaWR9YCk7XHJcbiAgfTtcclxuXHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBcclxuICAgICAgICB2YXIgZm9ybURhdGEgPSBuZXcgRm9ybURhdGEoKVxyXG4gICAgICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2NvbnNvbGVfdHlwZV9pZCcsZ2V0Q29uc29sZV9JZClcclxuICAgICAgICAgICAgZm9ybURhdGEuYXBwZW5kKCd0eXBlJyxnZXRUeXBlKSxcclxuICAgICAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdkZXNjcmlwdGlvbicsZ2V0RGVzY3JpcHRpb24pLFxyXG4gICAgICAgICAgICBmb3JtRGF0YS5hcHBlbmQoJ2ltYWdlJyxnZXRJbWFnZS5maWxlKVxyXG4gICAgICAgICAgICB2YXIgY29uZmlnPXtoZWFkZXI6eydjb250ZW50LXR5cGUnOidtdWx0aXBhcnQvZm9ybS1kYXRhJ319XHJcbiAgICAgICAgICAgIC8vIHZhciByZXN1bHQgPSBhd2FpdCBwb3N0RGF0YUFuZEltYWdlKGBjb25zb2xldHlwZS91cGRhdGUvJHtjb25zb2xlX3R5cGVfaWR9YCwgY29uZmlnKVxyXG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZygncmVzdWx0JyxyZXN1bHQpO1xyXG4gICAgICAgICAgICB2YXIgcmVzdWx0ID0gYXdhaXQgcG9zdERhdGFBbmRJbWFnZShgY29uc29sZXR5cGUvdXBkYXRlLyR7Z2V0Q29uc29sZV9JZH1gLGZvcm1EYXRhLGNvbmZpZyk7XHJcbiAgICBmZXRjaERhdGEoKTtcclxuICAgIGhhbmRsZUNsb3NlKCk7XHJcblxyXG4gICAgaWYocmVzdWx0KVxyXG4gICAgeyAvL2FsZXJ0KFwiUmVjb3JkIFN1Ym1pdHRlZFwiKVxyXG4gICAgc2V0TWVzc2FnZSgnUmVjb3JkIFVwZGF0ZWQnKVxyXG4gICAgfVxyXG4gICAgZWxzZXtcclxuLy8gYWxlcnQoJ0ZhaWwgdG8gU3VibWl0IFJlY29yZCcpXHJcbiAgICBzZXRNZXNzYWdlKCdGYWlsIHRvIFVwZGF0ZSBSZWNvcmQnKVxyXG4gICAgfVxyXG5cclxuICB9O1xyXG5cclxuICBjb25zdCByZW5kZXJFZGl0Rm9ybSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCBzdHlsZSA9IHtcclxuICAgICAgd2lkdGg6IDYwMCxcclxuICAgICAgcGFkZGluZzogMTYsXHJcbiAgICAgIGJvcmRlclJhZGl1czogNSxcclxuICAgICAgYm94U2hhZG93OiBcIjAgMCAxMHB4IC0xcHggI2NjY1wiLFxyXG4gICAgfTtcclxuICAgIHJldHVybiAoXHJcbjxkaXYgaWQ9XCJjb25zb2xldHlwZV9mb3JtZGlsb2dib3hcIj4gXHJcbiAgICAgICAgICAgPGRpdiBpZD1cImNvbnNvbHR5cGVoZWFkaW5nXCI+Q29uc29sZSBUeXBlPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1yb3dcIiA+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC1tZC02IG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgZm9yPVwidmFsaWRhdGlvblNlcnZlcjAxXCI+VHlwZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgY2xhc3M9XCJmb3JtLWNvbnRyb2xcIiBpZD1cInZhbGlkYXRpb25TZXJ2ZXIwMVwiIFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtnZXRUeXBlfSBvbkNoYW5nZT17KGV2ZW50KT0+c2V0VHlwZShldmVudC50YXJnZXQudmFsdWUpfSByZXF1aXJlZC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInZhbGlkLWZlZWRiYWNrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIExvb2tzIGdvb2QhXHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC1tZC02IG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgZm9yPVwidmFsaWRhdGlvblNlcnZlcjAyXCI+RGVzY3JpcHRpb248L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIGNsYXNzPVwiZm9ybS1jb250cm9sXCIgaWQ9XCJ2YWxpZGF0aW9uU2VydmVyMDJcIiBcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z2V0RGVzY3JpcHRpb259IG9uQ2hhbmdlPXsoZXZlbnQpPT5zZXREZXNjcmlwdGlvbihldmVudC50YXJnZXQudmFsdWUpfSByZXF1aXJlZC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInZhbGlkLWZlZWRiYWNrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIExvb2tzIGdvb2QhXHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLXJvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjb2wtbWQtNiBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgey8qIDxsYWJlbCBmb3I9XCJ2YWxpZGF0aW9uU2VydmVyMDNcIj5VcGxvYWQgSW1hZ2U8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZmlsZVwiIGNsYXNzPVwiZm9ybS1jb250cm9sXCIgaWQ9XCJ2YWxpZGF0aW9uU2VydmVyMDNcIiBhcmlhLWRlc2NyaWJlZGJ5PVwidmFsaWRhdGlvblNlcnZlcjAzRmVlZGJhY2tcIiByZXF1aXJlZC8+ICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvKlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICBjbGFzc05hbWU9e2NsYXNzZXMuaW5wdXR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImNvbnRhaW5lZC1idXR0b24tZmlsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICBtdWx0aXBsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e2Rpc3BsYXk6J25vbmUnfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCk9PmhhbmRsZUltYWdlKGV2ZW50KX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiY29udGFpbmVkLWJ1dHRvbi1maWxlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIGNvbG9yPVwicHJpbWFyeVwiIGNvbXBvbmVudD1cInNwYW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgVXBsb2FkIEltYWdlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPEF2YXRhciBpZD1cIkF2ZXRlcmRpbG9nYm94XCIgc3R5bGU9e3t3aWR0aDo2MCxoZWlnaHQ6NjB9fSBzcmM9e2dldEltYWdlLmljb259IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICB7LyogPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tcHJpbWFyeVwiID48L2J1dHRvbj4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgY29sb3I9XCJwcmltYXJ5XCIgZGlzYWJsZUVsZXZhdGlvbiBpZD1cImJ1dHRvblN1bWl0XCIgb25DbGljaz17KCk9PmhhbmRsZVN1Ym1pdCgpfT5cclxuICAgICAgICAgICAgICAgICAgICB7LyogPEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgY29sb3I9XCJwcmltYXJ5XCIgb25DbGljaz17KCk9PmFsZXJ0KGdldERlc2NyaXB0aW9uKX0+ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgU3VibWl0IGZvcm1cclxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxici8+XHJcbiAgICAgICAgICAgICAgICAgIDxjZW50ZXI+PGI+e2dldE1lc3NhZ2V9PC9iPjwvY2VudGVyPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxNYXRlcmlhbFRhYmxlXHJcbiAgICAgICAgdGl0bGU9XCJDb25zb2wgVHlwZSBEYXRhXCJcclxuICAgICAgICBjb2x1bW5zPXtnZXRDb2x1bW5zLmNvbHVtbnN9XHJcbiAgICAgICAgZGF0YT17ZGF0YX1cclxuICAgICAgICBvcHRpb25zPXt7XHJcbiAgICAgICAgICBoZWFkZXJTdHlsZToge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwiIzAwMzM5OVwiLFxyXG4gICAgICAgICAgICBjb2xvcjogXCIjRkZGXCIsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgYWN0aW9uc0NlbGxTdHlsZToge1xyXG4gICAgICAgICAgICBwYWRkaW5nOiBcIjAgMjBweFwiLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9fVxyXG4gICAgICAgIGFjdGlvbnM9e1tcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgaWNvbjogXCJlZGl0XCIsXHJcbiAgICAgICAgICAgIHRvb2x0aXA6IFwiRWRpdFwiLFxyXG4gICAgICAgICAgICBvbkNsaWNrOiAoZXZlbnQsIHJvd0RhdGEpID0+IHtcclxuICAgICAgICAgICAgICBoYW5kbGVVcGRhdGUocm93RGF0YSk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIF19XHJcbiAgICAgICAgZWRpdGFibGU9e3tcclxuICAgICAgICAgIG9uUm93RGVsZXRlOiAob2xkRGF0YSkgPT5cclxuICAgICAgICAgICAgbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgZGF0YURlbGV0ZSA9IFsuLi5kYXRhXTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGluZGV4ID0gb2xkRGF0YS50YWJsZURhdGEuaWQ7XHJcbiAgICAgICAgICAgICAgICBkYXRhRGVsZXRlLnNwbGljZShpbmRleCwgMSk7XHJcbiAgICAgICAgICAgICAgICBzZXREYXRhKFsuLi5kYXRhRGVsZXRlXSk7XHJcbiAgICAgICAgICAgICAgICBoYW5kbGVEZWxldGUob2xkRGF0YSk7XHJcbiAgICAgICAgICAgICAgICByZXNvbHZlKCk7XHJcbiAgICAgICAgICAgICAgfSwgMTAwMCk7XHJcbiAgICAgICAgICAgIH0pLFxyXG4gICAgICAgIH19XHJcbiAgICAgIC8+XHJcbiAgICAgIDxEaWFsb2dcclxuICAgICAgICAvLyBmdWxsU2NyZWVuPXtmdWxsU2NyZWVufVxyXG4gICAgICAgIG1heFdpZHRoPVwibGdcIlxyXG4gICAgICAgIG9wZW49e29wZW59XHJcbiAgICAgICAgb25DbG9zZT17aGFuZGxlQ2xvc2V9XHJcbiAgICAgICAgYXJpYS1sYWJlbGxlZGJ5PVwicmVzcG9uc2l2ZS1kaWFsb2ctdGl0bGVcIlxyXG4gICAgICA+XHJcbiAgICAgICAge3JlbmRlckVkaXRGb3JtKCl9XHJcbiAgICAgIDwvRGlhbG9nPlxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG5cclxuY29uc3Qgc3R5bGUgPSB7XHJcbiAgbWF4V2lkdGg6IFwiOTUlXCIsXHJcbiAgbWFyZ2luOiBcIjIwcHggYXV0b1wiLFxyXG4gIGJvcmRlclJhZGl1czogNSxcclxuICBib3hTaGFkb3c6IFwiMCAwIDEwcHggLTFweCAjY2NjXCIsXHJcbn07XHJcblxyXG4vLyBjb25zdCBDYXRlZ29yeURpc3BsYXkgPSAocHJvcHMpID0+IHtcclxuLy8gICByZXR1cm4gPGRpdiBzdHlsZT17c3R5bGV9PntFZGl0YWJsZSgpfTwvZGl2PjtcclxuLy8gfTtcclxuXHJcblxyXG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS9BdmF0YXJcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvQnV0dG9uXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImF4aW9zXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm1hdGVyaWFsLXRhYmxlXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJzd2VldGFsZXJ0MlwiKTsiXSwic291cmNlUm9vdCI6IiJ9