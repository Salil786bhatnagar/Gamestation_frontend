module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./pages/Admin/Console_type.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./FetchServices.js":
/*!**************************!*\
  !*** ./FetchServices.js ***!
  \**************************/
/*! exports provided: getData, postData, postDataAndImage, deleteDataAxios, ServerURL */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getData", function() { return getData; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "postData", function() { return postData; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "postDataAndImage", function() { return postDataAndImage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "deleteDataAxios", function() { return deleteDataAxios; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServerURL", function() { return ServerURL; });
var axios = __webpack_require__(/*! axios */ "axios");

const ServerURL = 'http://localhost:4000'; //to read all data from node

/* get data*/

const getData = async url => {
  try {
    const response = await fetch(`${ServerURL}/${url}`);
    const result = await response.json();

    if (result == 'Session Expired Pls Login Again') {
      alert(result);
      return [];
    } else {
      return result;
    }
  } catch (e) {
    console.log(e);
    return null;
  }
};
/* post data */


const postData = async (url, body) => {
  try {
    const response = await fetch(`${ServerURL}/${url}`, {
      method: "POST",
      mode: "cors",
      headers: {
        "Content-Type": "application/json;charset=utf-8"
      },
      body: JSON.stringify(body)
    });
    const result = await response.json();

    if (result == 'Session Expired Pls Login Again') {
      alert(result);
      return [];
    } else {
      //const result=await response.json()
      return result;
    }
  } catch (e) {
    console.log(e);
    return null;
  }
};
/* post and image data*/


const postDataAndImage = async (url, formData, config) => {
  try {
    var response = await axios.post(`${ServerURL}/${url}`, formData, config); //  const result=await response.data.RESULT 

    if (response.data == 'Session Expired Pls Login Again') {
      alert(response.data);
      return false;
    } else {
      const result = await response.data;
      return result;
    }
  } catch (e) {
    return null;
  }
};

const deleteDataAxios = async Url => {
  try {
    var url = `${ServerURL}/${Url}`;
    const config = {
      "content-type": "application/json"
    };
    const response = await axios.delete(url, config);
    var result = response.data;
    console.log(result);
    return result;
  } catch (error) {
    console.log(error);
  }
};



/***/ }),

/***/ "./pages/Admin/Console_type.js":
/*!*************************************!*\
  !*** ./pages/Admin/Console_type.js ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ConsoleType; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _FetchServices__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../FetchServices */ "./FetchServices.js");
/* harmony import */ var _material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/IconButton */ "@material-ui/core/IconButton");
/* harmony import */ var _material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core_Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/Button */ "@material-ui/core/Button");
/* harmony import */ var _material_ui_core_Button__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _material_ui_core_Avatar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/Avatar */ "@material-ui/core/Avatar");
/* harmony import */ var _material_ui_core_Avatar__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Avatar__WEBPACK_IMPORTED_MODULE_5__);


var _jsxFileName = "E:\\gamestation\\pages\\Admin\\Console_type.js";





function ConsoleType() {
  const {
    0: getType,
    1: setType
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])("");
  const {
    0: getDescription,
    1: setDescription
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])("");
  const {
    0: getImage,
    1: setImage
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])({
    icon: '',
    file: ''
  });
  const {
    0: getMessage,
    1: setMessage
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])("");
  /* handle in image*/

  const handleImage = event => {
    setImage({
      icon: URL.createObjectURL(event.target.files[0]),
      file: event.target.files[0]
    });
  };

  const handlesubmit = async () => {
    var formData = new FormData();
    formData.append('type', getType), formData.append('description', getDescription), formData.append('image', getImage.file);
    var config = {
      header: {
        'content-type': 'multipart/form-data'
      }
    };
    var result = await Object(_FetchServices__WEBPACK_IMPORTED_MODULE_2__["postDataAndImage"])('consoletype/addtype', formData, config);
    console.log('result', result);

    if (result) {
      //alert("Record Submitted")
      setMessage('Record Submitted');
    } else {
      // alert('Fail to Submit Record')
      setMessage('Fail to Submit Record');
    }
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      id: "consoletype_form",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        id: "consoltypeheading",
        children: "Console Type"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 40,
        columnNumber: 12
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        class: "form-row",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          class: "col-md-6 mb-3",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
            for: "validationServer01",
            children: "Type"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 44,
            columnNumber: 21
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
            type: "text",
            class: "form-control",
            id: "validationServer01",
            value: getType,
            onChange: event => setType(event.target.value),
            required: true
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 45,
            columnNumber: 21
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            class: "valid-feedback",
            children: "Looks good!"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 47,
            columnNumber: 21
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 43,
          columnNumber: 21
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          class: "col-md-6 mb-3",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
            for: "validationServer02",
            children: "Description"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 52,
            columnNumber: 21
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
            type: "text",
            class: "form-control",
            id: "validationServer02",
            value: getDescription,
            onChange: event => setDescription(event.target.value),
            required: true
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 53,
            columnNumber: 21
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            class: "valid-feedback",
            children: "Looks good!"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 55,
            columnNumber: 21
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 51,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 42,
        columnNumber: 17
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        class: "form-row",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          class: "col-md-6 mb-3",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
            accept: "image/*" //  className={classes.input}
            ,
            id: "contained-button-file",
            multiple: true,
            type: "file",
            style: {
              display: 'none'
            },
            onChange: event => handleImage(event)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 64,
            columnNumber: 21
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
            htmlFor: "contained-button-file",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_4___default.a, {
              variant: "contained",
              color: "primary",
              component: "span",
              children: "Upload Image"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 74,
              columnNumber: 25
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 73,
            columnNumber: 21
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Avatar__WEBPACK_IMPORTED_MODULE_5___default.a, {
            id: "Aveter",
            style: {
              width: 60,
              height: 60
            },
            src: getImage.icon
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 78,
            columnNumber: 21
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 61,
          columnNumber: 21
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 60,
        columnNumber: 20
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_4___default.a, {
        variant: "contained",
        color: "primary",
        onClick: () => handlesubmit(),
        children: "Submit form"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 82,
        columnNumber: 21
      }, this), getMessage]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 39,
      columnNumber: 9
    }, this)
  }, void 0, false);
}

/***/ }),

/***/ "@material-ui/core/Avatar":
/*!*******************************************!*\
  !*** external "@material-ui/core/Avatar" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Avatar");

/***/ }),

/***/ "@material-ui/core/Button":
/*!*******************************************!*\
  !*** external "@material-ui/core/Button" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Button");

/***/ }),

/***/ "@material-ui/core/IconButton":
/*!***********************************************!*\
  !*** external "@material-ui/core/IconButton" ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/IconButton");

/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("axios");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react/jsx-dev-runtime");

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vRmV0Y2hTZXJ2aWNlcy5qcyIsIndlYnBhY2s6Ly8vLi9wYWdlcy9BZG1pbi9Db25zb2xlX3R5cGUuanMiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvQXZhdGFyXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvQnV0dG9uXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvSWNvbkJ1dHRvblwiIiwid2VicGFjazovLy9leHRlcm5hbCBcImF4aW9zXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicmVhY3RcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIiJdLCJuYW1lcyI6WyJheGlvcyIsInJlcXVpcmUiLCJTZXJ2ZXJVUkwiLCJnZXREYXRhIiwidXJsIiwicmVzcG9uc2UiLCJmZXRjaCIsInJlc3VsdCIsImpzb24iLCJhbGVydCIsImUiLCJjb25zb2xlIiwibG9nIiwicG9zdERhdGEiLCJib2R5IiwibWV0aG9kIiwibW9kZSIsImhlYWRlcnMiLCJKU09OIiwic3RyaW5naWZ5IiwicG9zdERhdGFBbmRJbWFnZSIsImZvcm1EYXRhIiwiY29uZmlnIiwicG9zdCIsImRhdGEiLCJkZWxldGVEYXRhQXhpb3MiLCJVcmwiLCJkZWxldGUiLCJlcnJvciIsIkNvbnNvbGVUeXBlIiwiZ2V0VHlwZSIsInNldFR5cGUiLCJ1c2VTdGF0ZSIsImdldERlc2NyaXB0aW9uIiwic2V0RGVzY3JpcHRpb24iLCJnZXRJbWFnZSIsInNldEltYWdlIiwiaWNvbiIsImZpbGUiLCJnZXRNZXNzYWdlIiwic2V0TWVzc2FnZSIsImhhbmRsZUltYWdlIiwiZXZlbnQiLCJVUkwiLCJjcmVhdGVPYmplY3RVUkwiLCJ0YXJnZXQiLCJmaWxlcyIsImhhbmRsZXN1Ym1pdCIsIkZvcm1EYXRhIiwiYXBwZW5kIiwiaGVhZGVyIiwidmFsdWUiLCJkaXNwbGF5Iiwid2lkdGgiLCJoZWlnaHQiXSwibWFwcGluZ3MiOiI7O1FBQUE7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSxJQUFJO1FBQ0o7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTs7O1FBR0E7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDBDQUEwQyxnQ0FBZ0M7UUFDMUU7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSx3REFBd0Qsa0JBQWtCO1FBQzFFO1FBQ0EsaURBQWlELGNBQWM7UUFDL0Q7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLHlDQUF5QyxpQ0FBaUM7UUFDMUUsZ0hBQWdILG1CQUFtQixFQUFFO1FBQ3JJO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMkJBQTJCLDBCQUEwQixFQUFFO1FBQ3ZELGlDQUFpQyxlQUFlO1FBQ2hEO1FBQ0E7UUFDQTs7UUFFQTtRQUNBLHNEQUFzRCwrREFBK0Q7O1FBRXJIO1FBQ0E7OztRQUdBO1FBQ0E7Ozs7Ozs7Ozs7Ozs7QUN4RkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFBSUEsS0FBSyxHQUFDQyxtQkFBTyxDQUFDLG9CQUFELENBQWpCOztBQUNBLE1BQU1DLFNBQVMsR0FBQyx1QkFBaEIsQyxDQUNBOztBQUVBOztBQUNBLE1BQU1DLE9BQU8sR0FBQyxNQUFNQyxHQUFOLElBQVk7QUFDdEIsTUFBRztBQUNELFVBQU1DLFFBQVEsR0FBQyxNQUFNQyxLQUFLLENBQUUsR0FBRUosU0FBVSxJQUFHRSxHQUFJLEVBQXJCLENBQTFCO0FBQ0EsVUFBTUcsTUFBTSxHQUFDLE1BQU1GLFFBQVEsQ0FBQ0csSUFBVCxFQUFuQjs7QUFDQSxRQUFHRCxNQUFNLElBQUUsaUNBQVgsRUFDQTtBQUNFRSxXQUFLLENBQUNGLE1BQUQsQ0FBTDtBQUNBLGFBQU8sRUFBUDtBQUNELEtBSkQsTUFLSztBQUNILGFBQU9BLE1BQVA7QUFDQTtBQUNILEdBWEQsQ0FXQyxPQUFNRyxDQUFOLEVBQVE7QUFDSkMsV0FBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSixXQUFPLElBQVA7QUFFQTtBQUNKLENBakJEO0FBbUJBOzs7QUFDQSxNQUFNRyxRQUFRLEdBQUMsT0FBTVQsR0FBTixFQUFVVSxJQUFWLEtBQWlCO0FBQzVCLE1BQUc7QUFDRCxVQUFNVCxRQUFRLEdBQUMsTUFBTUMsS0FBSyxDQUFFLEdBQUVKLFNBQVUsSUFBR0UsR0FBSSxFQUFyQixFQUMxQjtBQUFDVyxZQUFNLEVBQUMsTUFBUjtBQUFlQyxVQUFJLEVBQUMsTUFBcEI7QUFDQ0MsYUFBTyxFQUFDO0FBQUMsd0JBQWU7QUFBaEIsT0FEVDtBQUVDSCxVQUFJLEVBQUNJLElBQUksQ0FBQ0MsU0FBTCxDQUFlTCxJQUFmO0FBRk4sS0FEMEIsQ0FBMUI7QUFLQSxVQUFNUCxNQUFNLEdBQUMsTUFBTUYsUUFBUSxDQUFDRyxJQUFULEVBQW5COztBQUNBLFFBQUdELE1BQU0sSUFBRSxpQ0FBWCxFQUNBO0FBQUVFLFdBQUssQ0FBQ0YsTUFBRCxDQUFMO0FBQ0QsYUFBTyxFQUFQO0FBQ0EsS0FIRCxNQUlJO0FBRUo7QUFDQSxhQUFPQSxNQUFQO0FBQ0M7QUFFRixHQWpCRCxDQWlCQyxPQUFNRyxDQUFOLEVBQVE7QUFDSkMsV0FBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSixXQUFPLElBQVA7QUFFQTtBQUNKLENBdkJEO0FBeUJBOzs7QUFDQSxNQUFNVSxnQkFBZ0IsR0FBQyxPQUFNaEIsR0FBTixFQUFVaUIsUUFBVixFQUFtQkMsTUFBbkIsS0FBNEI7QUFDL0MsTUFBRztBQUNBLFFBQUlqQixRQUFRLEdBQUMsTUFBTUwsS0FBSyxDQUFDdUIsSUFBTixDQUFZLEdBQUVyQixTQUFVLElBQUdFLEdBQUksRUFBL0IsRUFBaUNpQixRQUFqQyxFQUEwQ0MsTUFBMUMsQ0FBbkIsQ0FEQSxDQUVEOztBQUNDLFFBQUdqQixRQUFRLENBQUNtQixJQUFULElBQWUsaUNBQWxCLEVBQ0Q7QUFBRWYsV0FBSyxDQUFDSixRQUFRLENBQUNtQixJQUFWLENBQUw7QUFDRCxhQUFPLEtBQVA7QUFDQSxLQUhBLE1BSUc7QUFFSCxZQUFNakIsTUFBTSxHQUFDLE1BQU1GLFFBQVEsQ0FBQ21CLElBQTVCO0FBQ0EsYUFBUWpCLE1BQVI7QUFDQTtBQUVGLEdBYkQsQ0FjQSxPQUFNRyxDQUFOLEVBQVE7QUFFTixXQUFPLElBQVA7QUFDRDtBQUNGLENBbkJIOztBQW9CRSxNQUFNZSxlQUFlLEdBQUcsTUFBT0MsR0FBUCxJQUFlO0FBQ3JDLE1BQUk7QUFDRixRQUFJdEIsR0FBRyxHQUFJLEdBQUVGLFNBQVUsSUFBR3dCLEdBQUksRUFBOUI7QUFDQSxVQUFNSixNQUFNLEdBQUc7QUFBRSxzQkFBZ0I7QUFBbEIsS0FBZjtBQUNBLFVBQU1qQixRQUFRLEdBQUcsTUFBTUwsS0FBSyxDQUFDMkIsTUFBTixDQUFhdkIsR0FBYixFQUFrQmtCLE1BQWxCLENBQXZCO0FBQ0EsUUFBSWYsTUFBTSxHQUFHRixRQUFRLENBQUNtQixJQUF0QjtBQUNBYixXQUFPLENBQUNDLEdBQVIsQ0FBWUwsTUFBWjtBQUNBLFdBQU9BLE1BQVA7QUFDRCxHQVBELENBT0UsT0FBT3FCLEtBQVAsRUFBYztBQUNkakIsV0FBTyxDQUFDQyxHQUFSLENBQVlnQixLQUFaO0FBQ0Q7QUFDRixDQVhEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN2RUY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNlLFNBQVNDLFdBQVQsR0FBdUI7QUFFbEMsUUFBTTtBQUFBLE9BQUNDLE9BQUQ7QUFBQSxPQUFVQztBQUFWLE1BQXFCQyxzREFBUSxDQUFDLEVBQUQsQ0FBbkM7QUFDQSxRQUFNO0FBQUEsT0FBQ0MsY0FBRDtBQUFBLE9BQWlCQztBQUFqQixNQUFtQ0Ysc0RBQVEsQ0FBQyxFQUFELENBQWpEO0FBQ0EsUUFBTTtBQUFBLE9BQUNHLFFBQUQ7QUFBQSxPQUFXQztBQUFYLE1BQXFCSixzREFBUSxDQUFDO0FBQUNLLFFBQUksRUFBQyxFQUFOO0FBQVVDLFFBQUksRUFBQztBQUFmLEdBQUQsQ0FBbkM7QUFDQSxRQUFNO0FBQUEsT0FBQ0MsVUFBRDtBQUFBLE9BQWFDO0FBQWIsTUFBMkJSLHNEQUFRLENBQUMsRUFBRCxDQUF6QztBQUVFOztBQUNILFFBQU1TLFdBQVcsR0FBRUMsS0FBRCxJQUFTO0FBQzFCTixZQUFRLENBQUM7QUFBQ0MsVUFBSSxFQUFDTSxHQUFHLENBQUNDLGVBQUosQ0FBb0JGLEtBQUssQ0FBQ0csTUFBTixDQUFhQyxLQUFiLENBQW1CLENBQW5CLENBQXBCLENBQU47QUFBaURSLFVBQUksRUFBQ0ksS0FBSyxDQUFDRyxNQUFOLENBQWFDLEtBQWIsQ0FBbUIsQ0FBbkI7QUFBdEQsS0FBRCxDQUFSO0FBQ0YsR0FGQzs7QUFJQyxRQUFNQyxZQUFZLEdBQUMsWUFBUztBQUV4QixRQUFJMUIsUUFBUSxHQUFHLElBQUkyQixRQUFKLEVBQWY7QUFDSTNCLFlBQVEsQ0FBQzRCLE1BQVQsQ0FBZ0IsTUFBaEIsRUFBdUJuQixPQUF2QixHQUNBVCxRQUFRLENBQUM0QixNQUFULENBQWdCLGFBQWhCLEVBQThCaEIsY0FBOUIsQ0FEQSxFQUVBWixRQUFRLENBQUM0QixNQUFULENBQWdCLE9BQWhCLEVBQXdCZCxRQUFRLENBQUNHLElBQWpDLENBRkE7QUFHQSxRQUFJaEIsTUFBTSxHQUFDO0FBQUM0QixZQUFNLEVBQUM7QUFBQyx3QkFBZTtBQUFoQjtBQUFSLEtBQVg7QUFDQSxRQUFJM0MsTUFBTSxHQUFHLE1BQU1hLHVFQUFnQixDQUFDLHFCQUFELEVBQXVCQyxRQUF2QixFQUFnQ0MsTUFBaEMsQ0FBbkM7QUFDUlgsV0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWixFQUFxQkwsTUFBckI7O0FBQ0ksUUFBR0EsTUFBSCxFQUNJO0FBQUU7QUFDRmlDLGdCQUFVLENBQUMsa0JBQUQsQ0FBVjtBQUNDLEtBSEwsTUFJUTtBQUNSO0FBQ0lBLGdCQUFVLENBQUMsdUJBQUQsQ0FBVjtBQUNDO0FBRVIsR0FsQkQ7O0FBbUJBLHNCQUNJO0FBQUEsMkJBQ0E7QUFBSyxRQUFFLEVBQUMsa0JBQVI7QUFBQSw4QkFDRztBQUFLLFVBQUUsRUFBQyxtQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURILGVBR1E7QUFBSyxhQUFLLEVBQUMsVUFBWDtBQUFBLGdDQUNJO0FBQUssZUFBSyxFQUFDLGVBQVg7QUFBQSxrQ0FDQTtBQUFPLGVBQUcsRUFBQyxvQkFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFEQSxlQUVBO0FBQU8sZ0JBQUksRUFBQyxNQUFaO0FBQW1CLGlCQUFLLEVBQUMsY0FBekI7QUFBd0MsY0FBRSxFQUFDLG9CQUEzQztBQUNBLGlCQUFLLEVBQUVWLE9BRFA7QUFDZ0Isb0JBQVEsRUFBR1ksS0FBRCxJQUFTWCxPQUFPLENBQUNXLEtBQUssQ0FBQ0csTUFBTixDQUFhTSxLQUFkLENBRDFDO0FBQ2dFLG9CQUFRO0FBRHhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRkEsZUFJQTtBQUFLLGlCQUFLLEVBQUMsZ0JBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURKLGVBU0k7QUFBSyxlQUFLLEVBQUMsZUFBWDtBQUFBLGtDQUNBO0FBQU8sZUFBRyxFQUFDLG9CQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURBLGVBRUE7QUFBTyxnQkFBSSxFQUFDLE1BQVo7QUFBbUIsaUJBQUssRUFBQyxjQUF6QjtBQUF3QyxjQUFFLEVBQUMsb0JBQTNDO0FBQ0EsaUJBQUssRUFBRWxCLGNBRFA7QUFDdUIsb0JBQVEsRUFBR1MsS0FBRCxJQUFTUixjQUFjLENBQUNRLEtBQUssQ0FBQ0csTUFBTixDQUFhTSxLQUFkLENBRHhEO0FBQzhFLG9CQUFRO0FBRHRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRkEsZUFJQTtBQUFLLGlCQUFLLEVBQUMsZ0JBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUhSLGVBcUJXO0FBQUssYUFBSyxFQUFDLFVBQVg7QUFBQSwrQkFDQztBQUFLLGVBQUssRUFBQyxlQUFYO0FBQUEsa0NBR0E7QUFDSyxrQkFBTSxFQUFDLFNBRFosQ0FFSTtBQUZKO0FBR0ssY0FBRSxFQUFDLHVCQUhSO0FBSUssb0JBQVEsTUFKYjtBQUtLLGdCQUFJLEVBQUMsTUFMVjtBQU1JLGlCQUFLLEVBQUU7QUFBQ0MscUJBQU8sRUFBQztBQUFULGFBTlg7QUFPSSxvQkFBUSxFQUFHVixLQUFELElBQVNELFdBQVcsQ0FBQ0MsS0FBRDtBQVBsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUhBLGVBWUE7QUFBTyxtQkFBTyxFQUFDLHVCQUFmO0FBQUEsbUNBQ0kscUVBQUMsK0RBQUQ7QUFBUSxxQkFBTyxFQUFDLFdBQWhCO0FBQTRCLG1CQUFLLEVBQUMsU0FBbEM7QUFBNEMsdUJBQVMsRUFBQyxNQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBWkEsZUFpQkEscUVBQUMsK0RBQUQ7QUFBUSxjQUFFLEVBQUMsUUFBWDtBQUFvQixpQkFBSyxFQUFFO0FBQUNXLG1CQUFLLEVBQUMsRUFBUDtBQUFVQyxvQkFBTSxFQUFDO0FBQWpCLGFBQTNCO0FBQWlELGVBQUcsRUFBRW5CLFFBQVEsQ0FBQ0U7QUFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFqQkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXJCWCxlQTJDWSxxRUFBQywrREFBRDtBQUFRLGVBQU8sRUFBQyxXQUFoQjtBQUE0QixhQUFLLEVBQUMsU0FBbEM7QUFBNEMsZUFBTyxFQUFFLE1BQUlVLFlBQVksRUFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0EzQ1osRUErQ1NSLFVBL0NUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURBLG1CQURKO0FBcURILEM7Ozs7Ozs7Ozs7O0FDekZELHFEOzs7Ozs7Ozs7OztBQ0FBLHFEOzs7Ozs7Ozs7OztBQ0FBLHlEOzs7Ozs7Ozs7OztBQ0FBLGtDOzs7Ozs7Ozs7OztBQ0FBLGtDOzs7Ozs7Ozs7OztBQ0FBLGtEIiwiZmlsZSI6InBhZ2VzL0FkbWluL0NvbnNvbGVfdHlwZS5qcyIsInNvdXJjZXNDb250ZW50IjpbIiBcdC8vIFRoZSBtb2R1bGUgY2FjaGVcbiBcdHZhciBpbnN0YWxsZWRNb2R1bGVzID0gcmVxdWlyZSgnLi4vLi4vc3NyLW1vZHVsZS1jYWNoZS5qcycpO1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHR2YXIgdGhyZXcgPSB0cnVlO1xuIFx0XHR0cnkge1xuIFx0XHRcdG1vZHVsZXNbbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuIFx0XHRcdHRocmV3ID0gZmFsc2U7XG4gXHRcdH0gZmluYWxseSB7XG4gXHRcdFx0aWYodGhyZXcpIGRlbGV0ZSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXTtcbiBcdFx0fVxuXG4gXHRcdC8vIEZsYWcgdGhlIG1vZHVsZSBhcyBsb2FkZWRcbiBcdFx0bW9kdWxlLmwgPSB0cnVlO1xuXG4gXHRcdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG4gXHRcdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbiBcdH1cblxuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tID0gbW9kdWxlcztcblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGUgY2FjaGVcbiBcdF9fd2VicGFja19yZXF1aXJlX18uYyA9IGluc3RhbGxlZE1vZHVsZXM7XG5cbiBcdC8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb24gZm9yIGhhcm1vbnkgZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kID0gZnVuY3Rpb24oZXhwb3J0cywgbmFtZSwgZ2V0dGVyKSB7XG4gXHRcdGlmKCFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywgbmFtZSkpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgbmFtZSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGdldHRlciB9KTtcbiBcdFx0fVxuIFx0fTtcblxuIFx0Ly8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yID0gZnVuY3Rpb24oZXhwb3J0cykge1xuIFx0XHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcbiBcdFx0fVxuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xuIFx0fTtcblxuIFx0Ly8gY3JlYXRlIGEgZmFrZSBuYW1lc3BhY2Ugb2JqZWN0XG4gXHQvLyBtb2RlICYgMTogdmFsdWUgaXMgYSBtb2R1bGUgaWQsIHJlcXVpcmUgaXRcbiBcdC8vIG1vZGUgJiAyOiBtZXJnZSBhbGwgcHJvcGVydGllcyBvZiB2YWx1ZSBpbnRvIHRoZSBuc1xuIFx0Ly8gbW9kZSAmIDQ6IHJldHVybiB2YWx1ZSB3aGVuIGFscmVhZHkgbnMgb2JqZWN0XG4gXHQvLyBtb2RlICYgOHwxOiBiZWhhdmUgbGlrZSByZXF1aXJlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnQgPSBmdW5jdGlvbih2YWx1ZSwgbW9kZSkge1xuIFx0XHRpZihtb2RlICYgMSkgdmFsdWUgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKHZhbHVlKTtcbiBcdFx0aWYobW9kZSAmIDgpIHJldHVybiB2YWx1ZTtcbiBcdFx0aWYoKG1vZGUgJiA0KSAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlICYmIHZhbHVlLl9fZXNNb2R1bGUpIHJldHVybiB2YWx1ZTtcbiBcdFx0dmFyIG5zID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yKG5zKTtcbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KG5zLCAnZGVmYXVsdCcsIHsgZW51bWVyYWJsZTogdHJ1ZSwgdmFsdWU6IHZhbHVlIH0pO1xuIFx0XHRpZihtb2RlICYgMiAmJiB0eXBlb2YgdmFsdWUgIT0gJ3N0cmluZycpIGZvcih2YXIga2V5IGluIHZhbHVlKSBfX3dlYnBhY2tfcmVxdWlyZV9fLmQobnMsIGtleSwgZnVuY3Rpb24oa2V5KSB7IHJldHVybiB2YWx1ZVtrZXldOyB9LmJpbmQobnVsbCwga2V5KSk7XG4gXHRcdHJldHVybiBucztcbiBcdH07XG5cbiBcdC8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSBmdW5jdGlvbihtb2R1bGUpIHtcbiBcdFx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0RGVmYXVsdCgpIHsgcmV0dXJuIG1vZHVsZVsnZGVmYXVsdCddOyB9IDpcbiBcdFx0XHRmdW5jdGlvbiBnZXRNb2R1bGVFeHBvcnRzKCkgeyByZXR1cm4gbW9kdWxlOyB9O1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCAnYScsIGdldHRlcik7XG4gXHRcdHJldHVybiBnZXR0ZXI7XG4gXHR9O1xuXG4gXHQvLyBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGxcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubyA9IGZ1bmN0aW9uKG9iamVjdCwgcHJvcGVydHkpIHsgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIHByb3BlcnR5KTsgfTtcblxuIFx0Ly8gX193ZWJwYWNrX3B1YmxpY19wYXRoX19cbiBcdF9fd2VicGFja19yZXF1aXJlX18ucCA9IFwiXCI7XG5cblxuIFx0Ly8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4gXHRyZXR1cm4gX193ZWJwYWNrX3JlcXVpcmVfXyhfX3dlYnBhY2tfcmVxdWlyZV9fLnMgPSBcIi4vcGFnZXMvQWRtaW4vQ29uc29sZV90eXBlLmpzXCIpO1xuIiwidmFyIGF4aW9zPXJlcXVpcmUoXCJheGlvc1wiKVxuY29uc3QgU2VydmVyVVJMPSdodHRwOi8vbG9jYWxob3N0OjQwMDAnXG4vL3RvIHJlYWQgYWxsIGRhdGEgZnJvbSBub2RlXG5cbi8qIGdldCBkYXRhKi9cbmNvbnN0IGdldERhdGE9YXN5bmModXJsKT0+e1xuICAgIHRyeXtcbiAgICAgIGNvbnN0IHJlc3BvbnNlPWF3YWl0IGZldGNoKGAke1NlcnZlclVSTH0vJHt1cmx9YClcbiAgICAgIGNvbnN0IHJlc3VsdD1hd2FpdCByZXNwb25zZS5qc29uKClcbiAgICAgIGlmKHJlc3VsdD09J1Nlc3Npb24gRXhwaXJlZCBQbHMgTG9naW4gQWdhaW4nKVxuICAgICAge1xuICAgICAgICBhbGVydChyZXN1bHQpXG4gICAgICAgIHJldHVybihbXSlcbiAgICAgIH1cbiAgICAgICBlbHNle1xuICAgICAgICByZXR1cm4gcmVzdWx0XG4gICAgICAgfVxuICAgIH1jYXRjaChlKXtcbiAgICAgICAgIGNvbnNvbGUubG9nKGUpXG4gICAgIHJldHVybiBudWxsXG5cbiAgICB9XG59XG5cbi8qIHBvc3QgZGF0YSAqLyAgICAgICAgICAgICAgICAgICAgICAgIFxuY29uc3QgcG9zdERhdGE9YXN5bmModXJsLGJvZHkpPT57XG4gICAgdHJ5e1xuICAgICAgY29uc3QgcmVzcG9uc2U9YXdhaXQgZmV0Y2goYCR7U2VydmVyVVJMfS8ke3VybH1gLFxuICAgICAge21ldGhvZDpcIlBPU1RcIixtb2RlOlwiY29yc1wiLFxuICAgICAgIGhlYWRlcnM6e1wiQ29udGVudC1UeXBlXCI6XCJhcHBsaWNhdGlvbi9qc29uO2NoYXJzZXQ9dXRmLThcIn0sXG4gICAgICAgYm9keTpKU09OLnN0cmluZ2lmeShib2R5KVxuICAgICAgfSlcbiAgICAgIGNvbnN0IHJlc3VsdD1hd2FpdCByZXNwb25zZS5qc29uKClcbiAgICAgIGlmKHJlc3VsdD09J1Nlc3Npb24gRXhwaXJlZCBQbHMgTG9naW4gQWdhaW4nKSBcbiAgICAgIHsgYWxlcnQocmVzdWx0KVxuICAgICAgIHJldHVybihbXSlcbiAgICAgIH1cbiAgICAgIGVsc2V7XG5cbiAgICAgIC8vY29uc3QgcmVzdWx0PWF3YWl0IHJlc3BvbnNlLmpzb24oKVxuICAgICAgcmV0dXJuIHJlc3VsdFxuICAgICAgfVxuXG4gICAgfWNhdGNoKGUpe1xuICAgICAgICAgY29uc29sZS5sb2coZSlcbiAgICAgcmV0dXJuIG51bGxcblxuICAgIH1cbn1cblxuLyogcG9zdCBhbmQgaW1hZ2UgZGF0YSovXG5jb25zdCBwb3N0RGF0YUFuZEltYWdlPWFzeW5jKHVybCxmb3JtRGF0YSxjb25maWcpPT57XG4gICAgdHJ5e1xuICAgICAgIHZhciByZXNwb25zZT1hd2FpdCBheGlvcy5wb3N0KGAke1NlcnZlclVSTH0vJHt1cmx9YCxmb3JtRGF0YSxjb25maWcpXG4gICAgICAvLyAgY29uc3QgcmVzdWx0PWF3YWl0IHJlc3BvbnNlLmRhdGEuUkVTVUxUIFxuICAgICAgIGlmKHJlc3BvbnNlLmRhdGE9PSdTZXNzaW9uIEV4cGlyZWQgUGxzIExvZ2luIEFnYWluJykgXG4gICAgICB7IGFsZXJ0KHJlc3BvbnNlLmRhdGEpXG4gICAgICAgcmV0dXJuKGZhbHNlKVxuICAgICAgfVxuICAgICAgZWxzZXtcbiAgICAgIFxuICAgICAgIGNvbnN0IHJlc3VsdD1hd2FpdCByZXNwb25zZS5kYXRhIFxuICAgICAgIHJldHVybiAocmVzdWx0KVxuICAgICAgfVxuICAgICAgXG4gICAgfVxuICAgIGNhdGNoKGUpe1xuICAgICAgXG4gICAgICByZXR1cm4gbnVsbFxuICAgIH1cbiAgfVxuICBjb25zdCBkZWxldGVEYXRhQXhpb3MgPSBhc3luYyAoVXJsKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIHZhciB1cmwgPSBgJHtTZXJ2ZXJVUkx9LyR7VXJsfWA7XG4gICAgICBjb25zdCBjb25maWcgPSB7IFwiY29udGVudC10eXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH07XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGF4aW9zLmRlbGV0ZSh1cmwsIGNvbmZpZyk7XG4gICAgICB2YXIgcmVzdWx0ID0gcmVzcG9uc2UuZGF0YTtcbiAgICAgIGNvbnNvbGUubG9nKHJlc3VsdCk7XG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmxvZyhlcnJvcik7XG4gICAgfVxuICB9O1xuXG4gICAgZXhwb3J0IHtnZXREYXRhLHBvc3REYXRhLHBvc3REYXRhQW5kSW1hZ2UsZGVsZXRlRGF0YUF4aW9zLFNlcnZlclVSTH0iLCJpbXBvcnQgUmVhY3Qse3VzZVN0YXRlfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHtwb3N0RGF0YSxnZXREYXRhLHBvc3REYXRhQW5kSW1hZ2V9IGZyb20gJy4uLy4uL0ZldGNoU2VydmljZXMnO1xyXG5pbXBvcnQgSWNvbkJ1dHRvbiBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9JY29uQnV0dG9uJztcclxuaW1wb3J0IEJ1dHRvbiBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9CdXR0b24nO1xyXG5pbXBvcnQgQXZhdGFyIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0F2YXRhcic7XHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENvbnNvbGVUeXBlKCkge1xyXG4gICAgXHJcbiAgICBjb25zdCBbZ2V0VHlwZSwgc2V0VHlwZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIGNvbnN0IFtnZXREZXNjcmlwdGlvbiwgc2V0RGVzY3JpcHRpb25dID0gdXNlU3RhdGUoXCJcIilcclxuICAgIGNvbnN0IFtnZXRJbWFnZSwgc2V0SW1hZ2VdPXVzZVN0YXRlKHtpY29uOicnLCBmaWxlOicnfSlcclxuICAgIGNvbnN0IFtnZXRNZXNzYWdlLCBzZXRNZXNzYWdlXSA9IHVzZVN0YXRlKFwiXCIpXHJcblxyXG4gICAgICAvKiBoYW5kbGUgaW4gaW1hZ2UqL1xyXG4gICBjb25zdCBoYW5kbGVJbWFnZT0oZXZlbnQpPT57XHJcbiAgICBzZXRJbWFnZSh7aWNvbjpVUkwuY3JlYXRlT2JqZWN0VVJMKGV2ZW50LnRhcmdldC5maWxlc1swXSksZmlsZTpldmVudC50YXJnZXQuZmlsZXNbMF19KVxyXG4gfVxyXG4gICAgXHJcbiAgICBjb25zdCBoYW5kbGVzdWJtaXQ9YXN5bmMoKT0+e1xyXG4gICAgICAgIFxyXG4gICAgICAgIHZhciBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YSgpXHJcbiAgICAgICAgICAgIGZvcm1EYXRhLmFwcGVuZCgndHlwZScsZ2V0VHlwZSksXHJcbiAgICAgICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnZGVzY3JpcHRpb24nLGdldERlc2NyaXB0aW9uKSxcclxuICAgICAgICAgICAgZm9ybURhdGEuYXBwZW5kKCdpbWFnZScsZ2V0SW1hZ2UuZmlsZSlcclxuICAgICAgICAgICAgdmFyIGNvbmZpZz17aGVhZGVyOnsnY29udGVudC10eXBlJzonbXVsdGlwYXJ0L2Zvcm0tZGF0YSd9fVxyXG4gICAgICAgICAgICB2YXIgcmVzdWx0ID0gYXdhaXQgcG9zdERhdGFBbmRJbWFnZSgnY29uc29sZXR5cGUvYWRkdHlwZScsZm9ybURhdGEsY29uZmlnKVxyXG4gICAgY29uc29sZS5sb2coJ3Jlc3VsdCcscmVzdWx0KTtcclxuICAgICAgICBpZihyZXN1bHQpXHJcbiAgICAgICAgICAgIHsgLy9hbGVydChcIlJlY29yZCBTdWJtaXR0ZWRcIilcclxuICAgICAgICAgICAgc2V0TWVzc2FnZSgnUmVjb3JkIFN1Ym1pdHRlZCcpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZXtcclxuICAgICAgICAvLyBhbGVydCgnRmFpbCB0byBTdWJtaXQgUmVjb3JkJylcclxuICAgICAgICAgICAgc2V0TWVzc2FnZSgnRmFpbCB0byBTdWJtaXQgUmVjb3JkJylcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgIH1cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICA8ZGl2IGlkPVwiY29uc29sZXR5cGVfZm9ybVwiPiBcclxuICAgICAgICAgICA8ZGl2IGlkPVwiY29uc29sdHlwZWhlYWRpbmdcIj5Db25zb2xlIFR5cGU8L2Rpdj5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1yb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLW1kLTYgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBmb3I9XCJ2YWxpZGF0aW9uU2VydmVyMDFcIj5UeXBlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBjbGFzcz1cImZvcm0tY29udHJvbFwiIGlkPVwidmFsaWRhdGlvblNlcnZlcjAxXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2dldFR5cGV9IG9uQ2hhbmdlPXsoZXZlbnQpPT5zZXRUeXBlKGV2ZW50LnRhcmdldC52YWx1ZSl9IHJlcXVpcmVkLz5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidmFsaWQtZmVlZGJhY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgTG9va3MgZ29vZCFcclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29sLW1kLTYgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBmb3I9XCJ2YWxpZGF0aW9uU2VydmVyMDJcIj5EZXNjcmlwdGlvbjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgY2xhc3M9XCJmb3JtLWNvbnRyb2xcIiBpZD1cInZhbGlkYXRpb25TZXJ2ZXIwMlwiIFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtnZXREZXNjcmlwdGlvbn0gb25DaGFuZ2U9eyhldmVudCk9PnNldERlc2NyaXB0aW9uKGV2ZW50LnRhcmdldC52YWx1ZSl9IHJlcXVpcmVkLz5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidmFsaWQtZmVlZGJhY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgTG9va3MgZ29vZCFcclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tcm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbC1tZC02IG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICB7LyogPGxhYmVsIGZvcj1cInZhbGlkYXRpb25TZXJ2ZXIwM1wiPlVwbG9hZCBJbWFnZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJmaWxlXCIgY2xhc3M9XCJmb3JtLWNvbnRyb2xcIiBpZD1cInZhbGlkYXRpb25TZXJ2ZXIwM1wiIGFyaWEtZGVzY3JpYmVkYnk9XCJ2YWxpZGF0aW9uU2VydmVyMDNGZWVkYmFja1wiIHJlcXVpcmVkLz4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gIGNsYXNzTmFtZT17Y2xhc3Nlcy5pbnB1dH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiY29udGFpbmVkLWJ1dHRvbi1maWxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgIG11bHRpcGxlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7ZGlzcGxheTonbm9uZSd9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KT0+aGFuZGxlSW1hZ2UoZXZlbnQpfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJjb250YWluZWQtYnV0dG9uLWZpbGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgY29sb3I9XCJwcmltYXJ5XCIgY29tcG9uZW50PVwic3BhblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBVcGxvYWQgSW1hZ2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8QXZhdGFyIGlkPVwiQXZldGVyXCIgc3R5bGU9e3t3aWR0aDo2MCxoZWlnaHQ6NjB9fSBzcmM9e2dldEltYWdlLmljb259IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICB7LyogPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tcHJpbWFyeVwiID48L2J1dHRvbj4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgY29sb3I9XCJwcmltYXJ5XCIgb25DbGljaz17KCk9PmhhbmRsZXN1Ym1pdCgpfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFN1Ym1pdCBmb3JtXHJcbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAge2dldE1lc3NhZ2V9XHJcbiAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC8+XHJcbiAgICApXHJcbn1cclxuIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvQXZhdGFyXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlL0J1dHRvblwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS9JY29uQnV0dG9uXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImF4aW9zXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiKTsiXSwic291cmNlUm9vdCI6IiJ9