webpackHotUpdate_N_E("pages/Rentweek/Rent_week",{

/***/ "./pages/Rentweek/Rent_week.js":
/*!*************************************!*\
  !*** ./pages/Rentweek/Rent_week.js ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Rent_month; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Components_Header_Header__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../Components/Header/Header */ "./Components/Header/Header.js");
/* harmony import */ var _Components_Footer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../Components/Footer */ "./Components/Footer/index.js");


var _jsxFileName = "E:\\gamestation\\pages\\Rentweek\\Rent_week.js";



function Rent_month() {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_Components_Header_Header__WEBPACK_IMPORTED_MODULE_2__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 7,
      columnNumber: 13
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      "class": "alert alert-success showContain",
      role: "alert",
      style: {
        margin: 0,
        padding: 0,
        width: '90%',
        overflow: 'hidden'
      },
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
        "class": "alert-heading",
        children: "Hello, Welcome"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 9,
        columnNumber: 17
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
        id: "p1",
        children: "Looking to Rent a Gaming Console?"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 10,
        columnNumber: 17
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("hr", {
        id: "hr"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 11,
        columnNumber: 17
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
        "class": "mb-0",
        children: "Start by choosing from the available platforms"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 17
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 8,
      columnNumber: 13
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      "class": "row",
      style: {
        margin: 0,
        padding: 0,
        width: '90%',
        overflow: 'hidden'
      },
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        "class": "col-md-6",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          id: "imgmonth1",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: "/images/PS4.jpg",
            style: {
              height: 'auto',
              maxWidth: '100%',
              verticalAlign: 'top'
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 18,
            columnNumber: 25
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 17,
          columnNumber: 21
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          id: "mainbtn1",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            "class": "wpb_text_column wpb_content_element  responsive_js_composer_custom_css_1951844264",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              "class": "wpb_wrapper",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
                style: {
                  textAlign: 'center'
                },
                children: "PS4 Slim"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 22,
                columnNumber: 58
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                style: {
                  textAlign: 'center'
                },
                children: "High-end, Sleek & Premium"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 23,
                columnNumber: 33
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                style: {
                  textAlign: 'center',
                  color: '#8444bc'
                },
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("strong", {
                  children: "Starts at \u20B9 700"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 24,
                  columnNumber: 84
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 24,
                columnNumber: 33
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 22,
              columnNumber: 33
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 21,
            columnNumber: 31
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            "class": "vc_btn3-container vc_btn3-center responsive_js_composer_custom_css_495954661",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
              id: "choose1",
              children: ["Choose ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                "class": "vc_btn3-icon entypo-icon entypo-icon-right-thin"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 28,
                columnNumber: 60
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 28,
              columnNumber: 37
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 27,
            columnNumber: 29
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 20,
          columnNumber: 25
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 14
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        "class": "col-md-6",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          id: "imgmonth2",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            src: "/images/xbox.jpg",
            style: {
              height: 'auto',
              maxWidth: '100%',
              verticalAlign: 'top'
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 34,
            columnNumber: 20
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 33,
          columnNumber: 19
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          id: "mainbtn1",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            "class": "wpb_text_column wpb_content_element  responsive_js_composer_custom_css_1951844264",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              "class": "wpb_wrapper",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
                style: {
                  textAlign: 'center'
                },
                children: "Xbox One"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 38,
                columnNumber: 58
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                style: {
                  textAlign: 'center'
                },
                children: "Imaginative, optimal & fun"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 39,
                columnNumber: 33
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                style: {
                  textAlign: 'center',
                  color: '#8444bc'
                },
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("strong", {
                  children: "Starts at \u20B9 700"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 40,
                  columnNumber: 84
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 40,
                columnNumber: 33
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 38,
              columnNumber: 33
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 37,
            columnNumber: 31
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            "class": "vc_btn3-container vc_btn3-center responsive_js_composer_custom_css_495954661",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
              id: "choose1",
              children: ["Choose ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
                "class": "vc_btn3-icon entypo-icon entypo-icon-right-thin"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 44,
                columnNumber: 60
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 44,
              columnNumber: 37
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 43,
            columnNumber: 29
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 36,
          columnNumber: 20
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 32,
        columnNumber: 15
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 15,
      columnNumber: 13
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_Components_Footer__WEBPACK_IMPORTED_MODULE_3__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 49,
      columnNumber: 12
    }, this)]
  }, void 0, true);
}
_c = Rent_month;

var _c;

$RefreshReg$(_c, "Rent_month");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvUmVudHdlZWsvUmVudF93ZWVrLmpzIl0sIm5hbWVzIjpbIlJlbnRfbW9udGgiLCJtYXJnaW4iLCJwYWRkaW5nIiwid2lkdGgiLCJvdmVyZmxvdyIsImhlaWdodCIsIm1heFdpZHRoIiwidmVydGljYWxBbGlnbiIsInRleHRBbGlnbiIsImNvbG9yIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDZSxTQUFTQSxVQUFULEdBQXNCO0FBQ2pDLHNCQUNJO0FBQUEsNEJBQ0kscUVBQUMsaUVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURKLGVBRUk7QUFBSyxlQUFNLGlDQUFYO0FBQThDLFVBQUksRUFBQyxPQUFuRDtBQUEyRCxXQUFLLEVBQUU7QUFBRUMsY0FBTSxFQUFFLENBQVY7QUFBYUMsZUFBTyxFQUFDLENBQXJCO0FBQXdCQyxhQUFLLEVBQUUsS0FBL0I7QUFBc0NDLGdCQUFRLEVBQUU7QUFBaEQsT0FBbEU7QUFBQSw4QkFDSTtBQUFJLGlCQUFNLGVBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FESixlQUVJO0FBQUcsVUFBRSxFQUFDLElBQU47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGSixlQUdJO0FBQUksVUFBRSxFQUFDO0FBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUhKLGVBSUk7QUFBRyxpQkFBTSxNQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRkosZUFTSTtBQUFLLGVBQU0sS0FBWDtBQUFpQixXQUFLLEVBQUU7QUFBRUgsY0FBTSxFQUFFLENBQVY7QUFBYUMsZUFBTyxFQUFDLENBQXJCO0FBQXdCQyxhQUFLLEVBQUUsS0FBL0I7QUFBc0NDLGdCQUFRLEVBQUU7QUFBaEQsT0FBeEI7QUFBQSw4QkFDQztBQUFLLGlCQUFNLFVBQVg7QUFBQSxnQ0FDTztBQUFLLFlBQUUsRUFBQyxXQUFSO0FBQUEsaUNBQ0k7QUFBSyxlQUFHLEVBQUMsaUJBQVQ7QUFBMkIsaUJBQUssRUFBRTtBQUFDQyxvQkFBTSxFQUFFLE1BQVQ7QUFBaUJDLHNCQUFRLEVBQUMsTUFBMUI7QUFBa0NDLDJCQUFhLEVBQUM7QUFBaEQ7QUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRFAsZUFJVztBQUFLLFlBQUUsRUFBQyxVQUFSO0FBQUEsa0NBQ007QUFBSyxxQkFBTSxtRkFBWDtBQUFBLG1DQUNFO0FBQUssdUJBQU0sYUFBWDtBQUFBLHNDQUF5QjtBQUFJLHFCQUFLLEVBQUU7QUFBQ0MsMkJBQVMsRUFBQztBQUFYLGlCQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUF6QixlQUNBO0FBQUcscUJBQUssRUFBRTtBQUFDQSwyQkFBUyxFQUFFO0FBQVosaUJBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBREEsZUFFQTtBQUFHLHFCQUFLLEVBQUU7QUFBQ0EsMkJBQVMsRUFBRSxRQUFaO0FBQXNCQyx1QkFBSyxFQUFFO0FBQTdCLGlCQUFWO0FBQUEsdUNBQW1EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBRkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFETixlQU9JO0FBQUsscUJBQU0sOEVBQVg7QUFBQSxtQ0FDUTtBQUFHLGdCQUFFLEVBQUMsU0FBTjtBQUFBLGlEQUF1QjtBQUFHLHlCQUFNO0FBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREQsZUFpQkU7QUFBSyxpQkFBTSxVQUFYO0FBQUEsZ0NBQ0k7QUFBSyxZQUFFLEVBQUMsV0FBUjtBQUFBLGlDQUNDO0FBQUssZUFBRyxFQUFDLGtCQUFUO0FBQTRCLGlCQUFLLEVBQUU7QUFBQ0osb0JBQU0sRUFBRSxNQUFUO0FBQWlCQyxzQkFBUSxFQUFDLE1BQTFCO0FBQWtDQywyQkFBYSxFQUFDO0FBQWhEO0FBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERDtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURKLGVBSUs7QUFBSyxZQUFFLEVBQUMsVUFBUjtBQUFBLGtDQUNXO0FBQUsscUJBQU0sbUZBQVg7QUFBQSxtQ0FDRTtBQUFLLHVCQUFNLGFBQVg7QUFBQSxzQ0FBeUI7QUFBSSxxQkFBSyxFQUFFO0FBQUNDLDJCQUFTLEVBQUM7QUFBWCxpQkFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFBekIsZUFDQTtBQUFHLHFCQUFLLEVBQUU7QUFBQ0EsMkJBQVMsRUFBRTtBQUFaLGlCQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQURBLGVBRUE7QUFBRyxxQkFBSyxFQUFFO0FBQUNBLDJCQUFTLEVBQUUsUUFBWjtBQUFzQkMsdUJBQUssRUFBRTtBQUE3QixpQkFBVjtBQUFBLHVDQUFtRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUZBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRFgsZUFPUztBQUFLLHFCQUFNLDhFQUFYO0FBQUEsbUNBQ1E7QUFBRyxnQkFBRSxFQUFDLFNBQU47QUFBQSxpREFBdUI7QUFBRyx5QkFBTTtBQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBUFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUpMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFUSixlQTJDRyxxRUFBQywwREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBM0NIO0FBQUEsa0JBREo7QUErQ0g7S0FoRHVCVCxVIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL1JlbnR3ZWVrL1JlbnRfd2Vlay5iNGM2Y2NmYmI1Yjc1Y2FhNzI4OC5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgSGVhZGVyIGZyb20gJy4uLy4uL0NvbXBvbmVudHMvSGVhZGVyL0hlYWRlcic7XHJcbmltcG9ydCBGb290ZXIgZnJvbSAnLi4vLi4vQ29tcG9uZW50cy9Gb290ZXInO1xyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBSZW50X21vbnRoKCkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgICA8SGVhZGVyIC8+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJhbGVydCBhbGVydC1zdWNjZXNzIHNob3dDb250YWluXCIgIHJvbGU9XCJhbGVydFwiIHN0eWxlPXt7IG1hcmdpbjogMCwgcGFkZGluZzowLCB3aWR0aDogJzkwJScsIG92ZXJmbG93OiAnaGlkZGVuJ319PlxyXG4gICAgICAgICAgICAgICAgPGg0IGNsYXNzPVwiYWxlcnQtaGVhZGluZ1wiPkhlbGxvLCBXZWxjb21lPC9oND5cclxuICAgICAgICAgICAgICAgIDxwIGlkPVwicDFcIj5Mb29raW5nIHRvIFJlbnQgYSBHYW1pbmcgQ29uc29sZT88L3A+XHJcbiAgICAgICAgICAgICAgICA8aHIgaWQ9XCJoclwiLz5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzPVwibWItMFwiPlN0YXJ0IGJ5IGNob29zaW5nIGZyb20gdGhlIGF2YWlsYWJsZSBwbGF0Zm9ybXM8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInJvd1wiIHN0eWxlPXt7IG1hcmdpbjogMCwgcGFkZGluZzowLCB3aWR0aDogJzkwJScsIG92ZXJmbG93OiAnaGlkZGVuJ319PlxyXG4gICAgICAgICAgICAgPGRpdiBjbGFzcz0nY29sLW1kLTYnPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgaWQ9XCJpbWdtb250aDFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9XCIvaW1hZ2VzL1BTNC5qcGdcIiBzdHlsZT17e2hlaWdodDogJ2F1dG8nLCBtYXhXaWR0aDonMTAwJScsIHZlcnRpY2FsQWxpZ246J3RvcCd9fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBpZD1cIm1haW5idG4xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ3cGJfdGV4dF9jb2x1bW4gd3BiX2NvbnRlbnRfZWxlbWVudCAgcmVzcG9uc2l2ZV9qc19jb21wb3Nlcl9jdXN0b21fY3NzXzE5NTE4NDQyNjRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwid3BiX3dyYXBwZXJcIj48aDQgc3R5bGU9e3t0ZXh0QWxpZ246J2NlbnRlcid9fT5QUzQgU2xpbTwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgc3R5bGU9e3t0ZXh0QWxpZ246ICdjZW50ZXInfX0+SGlnaC1lbmQsIFNsZWVrICZhbXA7IFByZW1pdW08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgc3R5bGU9e3t0ZXh0QWxpZ246ICdjZW50ZXInLCBjb2xvcjogJyM4NDQ0YmMnfX0+PHN0cm9uZz5TdGFydHMgYXQg4oK5IDcwMDwvc3Ryb25nPjwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidmNfYnRuMy1jb250YWluZXIgdmNfYnRuMy1jZW50ZXIgcmVzcG9uc2l2ZV9qc19jb21wb3Nlcl9jdXN0b21fY3NzXzQ5NTk1NDY2MVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YSBpZD1cImNob29zZTFcIj5DaG9vc2UgPGkgY2xhc3M9XCJ2Y19idG4zLWljb24gZW50eXBvLWljb24gZW50eXBvLWljb24tcmlnaHQtdGhpblwiPjwvaT48L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9J2NvbC1tZC02Jz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBpZD1cImltZ21vbnRoMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgPGltZyBzcmM9XCIvaW1hZ2VzL3hib3guanBnXCIgc3R5bGU9e3toZWlnaHQ6ICdhdXRvJywgbWF4V2lkdGg6JzEwMCUnLCB2ZXJ0aWNhbEFsaWduOid0b3AnfX0vPlxyXG4gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICA8ZGl2IGlkPVwibWFpbmJ0bjFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIndwYl90ZXh0X2NvbHVtbiB3cGJfY29udGVudF9lbGVtZW50ICByZXNwb25zaXZlX2pzX2NvbXBvc2VyX2N1c3RvbV9jc3NfMTk1MTg0NDI2NFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ3cGJfd3JhcHBlclwiPjxoNCBzdHlsZT17e3RleHRBbGlnbjonY2VudGVyJ319Plhib3ggT25lPC9oND5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBzdHlsZT17e3RleHRBbGlnbjogJ2NlbnRlcid9fT5JbWFnaW5hdGl2ZSwgb3B0aW1hbCAmIGZ1bjwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBzdHlsZT17e3RleHRBbGlnbjogJ2NlbnRlcicsIGNvbG9yOiAnIzg0NDRiYyd9fT48c3Ryb25nPlN0YXJ0cyBhdCDigrkgNzAwPC9zdHJvbmc+PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ2Y19idG4zLWNvbnRhaW5lciB2Y19idG4zLWNlbnRlciByZXNwb25zaXZlX2pzX2NvbXBvc2VyX2N1c3RvbV9jc3NfNDk1OTU0NjYxXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhIGlkPVwiY2hvb3NlMVwiPkNob29zZSA8aSBjbGFzcz1cInZjX2J0bjMtaWNvbiBlbnR5cG8taWNvbiBlbnR5cG8taWNvbi1yaWdodC10aGluXCI+PC9pPjwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgIDxGb290ZXIvPlxyXG4gICAgICAgIDwvPlxyXG4gICAgKVxyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=