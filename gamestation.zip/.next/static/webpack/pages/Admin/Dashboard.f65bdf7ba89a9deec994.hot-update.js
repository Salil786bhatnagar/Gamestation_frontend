webpackHotUpdate_N_E("pages/Admin/Dashboard",{

/***/ "./pages/Admin/Dashboard.js":
/*!**********************************!*\
  !*** ./pages/Admin/Dashboard.js ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Dashboard; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var E_gamestation_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var E_gamestation_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(E_gamestation_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var E_gamestation_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var E_gamestation_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! clsx */ "./node_modules/clsx/dist/clsx.m.js");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/core/styles */ "./node_modules/@material-ui/core/esm/styles/index.js");
/* harmony import */ var _material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @material-ui/core/Typography */ "./node_modules/@material-ui/core/esm/Typography/index.js");
/* harmony import */ var _Console_type__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./Console_type */ "./pages/Admin/Console_type.js");
/* harmony import */ var _Displayall_consoletype__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./Displayall_consoletype */ "./pages/Admin/Displayall_consoletype.js");
/* harmony import */ var _Mainpage__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./Mainpage */ "./pages/Admin/Mainpage.js");
/* harmony import */ var _material_ui_core_CssBaseline__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @material-ui/core/CssBaseline */ "./node_modules/@material-ui/core/esm/CssBaseline/index.js");
/* harmony import */ var _material_ui_core_AppBar__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @material-ui/core/AppBar */ "./node_modules/@material-ui/core/esm/AppBar/index.js");
/* harmony import */ var _material_ui_core_Toolbar__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @material-ui/core/Toolbar */ "./node_modules/@material-ui/core/esm/Toolbar/index.js");
/* harmony import */ var _material_ui_core_List__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @material-ui/core/List */ "./node_modules/@material-ui/core/esm/List/index.js");
/* harmony import */ var _material_ui_core_Divider__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @material-ui/core/Divider */ "./node_modules/@material-ui/core/esm/Divider/index.js");
/* harmony import */ var _material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @material-ui/core/IconButton */ "./node_modules/@material-ui/core/esm/IconButton/index.js");
/* harmony import */ var _material_ui_core_Badge__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @material-ui/core/Badge */ "./node_modules/@material-ui/core/esm/Badge/index.js");
/* harmony import */ var _material_ui_core_Container__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @material-ui/core/Container */ "./node_modules/@material-ui/core/esm/Container/index.js");
/* harmony import */ var _material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @material-ui/core/Grid */ "./node_modules/@material-ui/core/esm/Grid/index.js");
/* harmony import */ var _material_ui_core_Paper__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @material-ui/core/Paper */ "./node_modules/@material-ui/core/esm/Paper/index.js");
/* harmony import */ var _material_ui_core_Link__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @material-ui/core/Link */ "./node_modules/@material-ui/core/esm/Link/index.js");
/* harmony import */ var _material_ui_icons_Menu__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @material-ui/icons/Menu */ "./node_modules/@material-ui/icons/Menu.js");
/* harmony import */ var _material_ui_icons_Menu__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Menu__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _material_ui_core_Avatar__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @material-ui/core/Avatar */ "./node_modules/@material-ui/core/esm/Avatar/index.js");
/* harmony import */ var _material_ui_core_Drawer__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @material-ui/core/Drawer */ "./node_modules/@material-ui/core/esm/Drawer/index.js");
/* harmony import */ var _material_ui_icons_ChevronLeft__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @material-ui/icons/ChevronLeft */ "./node_modules/@material-ui/icons/ChevronLeft.js");
/* harmony import */ var _material_ui_icons_ChevronLeft__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_ChevronLeft__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var _ListItems__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./ListItems */ "./pages/Admin/ListItems.js");
/* harmony import */ var _material_ui_core_Box__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @material-ui/core/Box */ "./node_modules/@material-ui/core/esm/Box/index.js");






var _jsxFileName = "E:\\gamestation\\pages\\Admin\\Dashboard.js",
    _s = $RefreshSig$();


























function Copyright() {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_7__["default"], {
    variant: "body2",
    color: "textSecondary",
    align: "center",
    children: ['Copyright © ', /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Link__WEBPACK_IMPORTED_MODULE_21__["default"], {
      color: "inherit",
      href: "https://material-ui.com/",
      children: "Your Website"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 29,
      columnNumber: 7
    }, this), ' ', new Date().getFullYear(), '.']
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 27,
    columnNumber: 5
  }, this);
}

_c = Copyright;
var drawerWidth = 240;
var useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_6__["makeStyles"])(function (theme) {
  return {//   root: {
    //     display: 'flex',
    //   },
    //   toolbar: {
    //     paddingRight: 24, // keep right padding when drawer closed
    //   },
    //   toolbarIcon: {
    //     display: 'flex',
    //     // alignItems: 'center',
    //     justifyContent: 'flex-end',
    //     padding: '0 8px',
    //     ...theme.mixins.toolbar,
    //   },
    //   appBar: {
    //     zIndex: theme.zIndex.drawer + 1,
    //     transition: theme.transitions.create(['width', 'margin'], {
    //       easing: theme.transitions.easing.sharp,
    //       duration: theme.transitions.duration.leavingScreen,
    //     }),
    //   },
    //   appBarShift: {
    //     marginLeft: drawerWidth,
    //     width: `calc(100% - ${drawerWidth}px)`,
    //     transition: theme.transitions.create(['width', 'margin'], {
    //       easing: theme.transitions.easing.sharp,
    //       duration: theme.transitions.duration.enteringScreen,
    //     }),
    //   },
    //   menuButton: {
    //     marginRight: 36,
    //   },
    //   menuButtonHidden: {
    //     display: 'none',
    //   },
    //   title: {
    //     flexGrow: 1,
    //   },
    //   drawerPaper: {
    //     position: 'relative',
    //     whiteSpace: 'nowrap',
    //     width: drawerWidth,
    //     transition: theme.transitions.create('width', {
    //       easing: theme.transitions.easing.sharp,
    //       duration: theme.transitions.duration.enteringScreen,
    //     }),
    //   },
    //   drawerPaperClose: {
    //     overflowX: 'hidden',
    //     transition: theme.transitions.create('width', {
    //       easing: theme.transitions.easing.sharp,
    //       duration: theme.transitions.duration.leavingScreen,
    //     }),
    //     width: theme.spacing(7),
    //     [theme.breakpoints.up('sm')]: {
    //       width: theme.spacing(9),
    //     },
    //   },
    //   appBarSpacer: theme.mixins.toolbar,
    //   content: {
    //     flexGrow: 1,
    //     height: '100vh',
    //     overflow: 'auto',
    //   },
    //   container: {
    //     paddingTop: theme.spacing(4),
    //     paddingBottom: theme.spacing(4),
    //     // backgroundColor:'#ececd9',
    //   },
    //   paper: {
    //     padding: theme.spacing(2),
    //     display: 'flex',
    //     overflow: 'auto',
    //     flexDirection: 'column',
    //   },
    //   fixedHeight: {
    //     height: 240,
    //   },
  };
});
function Dashboard(props) {
  _s();

  var _this = this;

  var classes = useStyles();

  var _React$useState = react__WEBPACK_IMPORTED_MODULE_4___default.a.useState(true),
      _React$useState2 = Object(E_gamestation_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_3__["default"])(_React$useState, 2),
      open = _React$useState2[0],
      setOpen = _React$useState2[1];

  var _React$useState3 = react__WEBPACK_IMPORTED_MODULE_4___default.a.useState( /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_Mainpage__WEBPACK_IMPORTED_MODULE_10__["default"], {}, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 123,
    columnNumber: 55
  }, this)),
      _React$useState4 = Object(E_gamestation_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_3__["default"])(_React$useState3, 2),
      ShowComponents = _React$useState4[0],
      setComponet = _React$useState4[1]; //   const [admin,setAdmin]=React.useState([])
  //   const CheckSession=async()=>{
  //   var result=await getData('admin/chktoken')
  //   if(!result)
  //   {
  //    props.history.replace({pathname:'/Signin'})
  //   }
  //   else{
  //     var admin=JSON.parse(localStorage.getItem('admin'))
  //    console.log("ADMIN",admin)
  //    setAdmin(admin)
  //   }
  // useEffect(function(){
  //   CheckSession();
  // },[])


  var handleComponents = /*#__PURE__*/function () {
    var _ref = Object(E_gamestation_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__["default"])( /*#__PURE__*/E_gamestation_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.mark(function _callee(ShowData) {
      return E_gamestation_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.t0 = ShowData;
              _context.next = _context.t0 === 0 ? 3 : _context.t0 === 1 ? 6 : _context.t0 === 2 ? 8 : 10;
              break;

            case 3:
              console.log('0', 0);
              setComponet( /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_Mainpage__WEBPACK_IMPORTED_MODULE_10__["default"], {}, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 146,
                columnNumber: 19
              }, _this));
              return _context.abrupt("break", 10);

            case 6:
              setComponet( /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_Console_type__WEBPACK_IMPORTED_MODULE_8__["default"], {}, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 149,
                columnNumber: 19
              }, _this));
              return _context.abrupt("break", 10);

            case 8:
              setComponet( /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_Displayall_consoletype__WEBPACK_IMPORTED_MODULE_9__["default"], {}, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 152,
                columnNumber: 19
              }, _this));
              return _context.abrupt("break", 10);

            case 10:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function handleComponents(_x) {
      return _ref.apply(this, arguments);
    };
  }();

  var handleDrawerOpen = function handleDrawerOpen() {
    setOpen(true);
  };

  var handleDrawerClose = function handleDrawerClose() {
    setOpen(false);
  };

  var fixedHeightPaper = Object(clsx__WEBPACK_IMPORTED_MODULE_5__["default"])(classes.paper, classes.fixedHeight);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_CssBaseline__WEBPACK_IMPORTED_MODULE_11__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 169,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_AppBar__WEBPACK_IMPORTED_MODULE_12__["default"], {
      position: "absolute",
      className: Object(clsx__WEBPACK_IMPORTED_MODULE_5__["default"])(classes.appBar, open && classes.appBarShift),
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Toolbar__WEBPACK_IMPORTED_MODULE_13__["default"], {
        className: classes.toolbar,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_16__["default"], {
          edge: "start",
          color: "inherit",
          "aria-label": "open drawer",
          onClick: handleDrawerOpen,
          className: Object(clsx__WEBPACK_IMPORTED_MODULE_5__["default"])(classes.menuButton, open && classes.menuButtonHidden),
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_Menu__WEBPACK_IMPORTED_MODULE_22___default.a, {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 179,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 172,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_7__["default"], {
          component: "h1",
          variant: "h6",
          color: "inherit",
          noWrap: true,
          className: classes.title,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: classes.heading,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {}, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 186,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 182,
            columnNumber: 11
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 181,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Avatar__WEBPACK_IMPORTED_MODULE_23__["default"], {
          alt: "Remy Sharp",
          className: classes.large
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 191,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 171,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 170,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Drawer__WEBPACK_IMPORTED_MODULE_24__["default"], {
      variant: "permanent",
      classes: {
        paper: Object(clsx__WEBPACK_IMPORTED_MODULE_5__["default"])(classes.drawerPaper, !open && classes.drawerPaperClose)
      },
      open: open,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: classes.toolbarIcon,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_IconButton__WEBPACK_IMPORTED_MODULE_16__["default"], {
          onClick: handleDrawerClose,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_ChevronLeft__WEBPACK_IMPORTED_MODULE_25___default.a, {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 210,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 209,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 208,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Divider__WEBPACK_IMPORTED_MODULE_15__["default"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 214,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_List__WEBPACK_IMPORTED_MODULE_14__["default"], {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ListItems__WEBPACK_IMPORTED_MODULE_26__["default"], {
          handle_Components: handleComponents
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 215,
          columnNumber: 15
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 215,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 201,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("main", {
      className: classes.content,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: classes.appBarSpacer
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 218,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Container__WEBPACK_IMPORTED_MODULE_18__["default"], {
        maxWidth: "lg",
        className: classes.container,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_19__["default"], {
          container: true,
          spacing: 2,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Grid__WEBPACK_IMPORTED_MODULE_19__["default"], {
            item: true,
            xs: 12,
            sm: 12,
            children: ShowComponents
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 221,
            columnNumber: 15
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 220,
          columnNumber: 13
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Box__WEBPACK_IMPORTED_MODULE_27__["default"], {
            pt: 12,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Copyright, {}, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 227,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 226,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 225,
          columnNumber: 12
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 219,
        columnNumber: 11
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 217,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

_s(Dashboard, "NA0JuS83tlQt1xfpXNCRnvn+dwY=", false, function () {
  return [useStyles];
});

_c2 = Dashboard;

var _c, _c2;

$RefreshReg$(_c, "Copyright");
$RefreshReg$(_c2, "Dashboard");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvQWRtaW4vRGFzaGJvYXJkLmpzIl0sIm5hbWVzIjpbIkNvcHlyaWdodCIsIkRhdGUiLCJnZXRGdWxsWWVhciIsImRyYXdlcldpZHRoIiwidXNlU3R5bGVzIiwibWFrZVN0eWxlcyIsInRoZW1lIiwiRGFzaGJvYXJkIiwicHJvcHMiLCJjbGFzc2VzIiwiUmVhY3QiLCJ1c2VTdGF0ZSIsIm9wZW4iLCJzZXRPcGVuIiwiU2hvd0NvbXBvbmVudHMiLCJzZXRDb21wb25ldCIsImhhbmRsZUNvbXBvbmVudHMiLCJTaG93RGF0YSIsImNvbnNvbGUiLCJsb2ciLCJoYW5kbGVEcmF3ZXJPcGVuIiwiaGFuZGxlRHJhd2VyQ2xvc2UiLCJmaXhlZEhlaWdodFBhcGVyIiwiY2xzeCIsInBhcGVyIiwiZml4ZWRIZWlnaHQiLCJhcHBCYXIiLCJhcHBCYXJTaGlmdCIsInRvb2xiYXIiLCJtZW51QnV0dG9uIiwibWVudUJ1dHRvbkhpZGRlbiIsInRpdGxlIiwiaGVhZGluZyIsImxhcmdlIiwiZHJhd2VyUGFwZXIiLCJkcmF3ZXJQYXBlckNsb3NlIiwidG9vbGJhckljb24iLCJjb250ZW50IiwiYXBwQmFyU3BhY2VyIiwiY29udGFpbmVyIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EsU0FBU0EsU0FBVCxHQUFxQjtBQUNuQixzQkFDRSxxRUFBQyxvRUFBRDtBQUFZLFdBQU8sRUFBQyxPQUFwQjtBQUE0QixTQUFLLEVBQUMsZUFBbEM7QUFBa0QsU0FBSyxFQUFDLFFBQXhEO0FBQUEsZUFDRyxjQURILGVBRUUscUVBQUMsK0RBQUQ7QUFBTSxXQUFLLEVBQUMsU0FBWjtBQUFzQixVQUFJLEVBQUMsMEJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRkYsRUFJVSxHQUpWLEVBS0csSUFBSUMsSUFBSixHQUFXQyxXQUFYLEVBTEgsRUFNRyxHQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBVUQ7O0tBWFFGLFM7QUFhVCxJQUFNRyxXQUFXLEdBQUcsR0FBcEI7QUFFQSxJQUFNQyxTQUFTLEdBQUdDLDJFQUFVLENBQUMsVUFBQ0MsS0FBRDtBQUFBLFNBQVksQ0FDekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQTdFeUMsR0FBWjtBQUFBLENBQUQsQ0FBNUI7QUFnRmUsU0FBU0MsU0FBVCxDQUFtQkMsS0FBbkIsRUFBMEI7QUFBQTs7QUFBQTs7QUFDdkMsTUFBTUMsT0FBTyxHQUFHTCxTQUFTLEVBQXpCOztBQUR1Qyx3QkFFZk0sNENBQUssQ0FBQ0MsUUFBTixDQUFlLElBQWYsQ0FGZTtBQUFBO0FBQUEsTUFFaENDLElBRmdDO0FBQUEsTUFFMUJDLE9BRjBCOztBQUFBLHlCQUdGSCw0Q0FBSyxDQUFDQyxRQUFOLGVBQWUscUVBQUMsa0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUFmLENBSEU7QUFBQTtBQUFBLE1BR2hDRyxjQUhnQztBQUFBLE1BR2hCQyxXQUhnQix3QkFJekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7QUFDQTtBQUNBOzs7QUFFRSxNQUFNQyxnQkFBZ0I7QUFBQSxvUEFBQyxpQkFBTUMsUUFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBQ2RBLFFBRGM7QUFBQSw4Q0FFZCxDQUZjLHVCQU1kLENBTmMsdUJBU2QsQ0FUYztBQUFBOztBQUFBO0FBR2pCQyxxQkFBTyxDQUFDQyxHQUFSLENBQVksR0FBWixFQUFnQixDQUFoQjtBQUNGSix5QkFBVyxlQUFDLHFFQUFDLGtEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQUQsQ0FBWDtBQUptQjs7QUFBQTtBQU9uQkEseUJBQVcsZUFBQyxxRUFBQyxxREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFELENBQVg7QUFQbUI7O0FBQUE7QUFVbkJBLHlCQUFXLGVBQUMscUVBQUMsK0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBRCxDQUFYO0FBVm1COztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQUQ7O0FBQUEsb0JBQWhCQyxnQkFBZ0I7QUFBQTtBQUFBO0FBQUEsS0FBdEI7O0FBZUEsTUFBTUksZ0JBQWdCLEdBQUcsU0FBbkJBLGdCQUFtQixHQUFNO0FBQzdCUCxXQUFPLENBQUMsSUFBRCxDQUFQO0FBQ0QsR0FGRDs7QUFJQSxNQUFNUSxpQkFBaUIsR0FBRyxTQUFwQkEsaUJBQW9CLEdBQU07QUFDOUJSLFdBQU8sQ0FBQyxLQUFELENBQVA7QUFDRCxHQUZEOztBQUlBLE1BQU1TLGdCQUFnQixHQUFHQyxvREFBSSxDQUFDZCxPQUFPLENBQUNlLEtBQVQsRUFBZ0JmLE9BQU8sQ0FBQ2dCLFdBQXhCLENBQTdCO0FBRUEsc0JBQ0U7QUFBQSw0QkFDRSxxRUFBQyxzRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFFRSxxRUFBQyxpRUFBRDtBQUFRLGNBQVEsRUFBQyxVQUFqQjtBQUE0QixlQUFTLEVBQUVGLG9EQUFJLENBQUNkLE9BQU8sQ0FBQ2lCLE1BQVQsRUFBaUJkLElBQUksSUFBSUgsT0FBTyxDQUFDa0IsV0FBakMsQ0FBM0M7QUFBQSw2QkFDRSxxRUFBQyxrRUFBRDtBQUFTLGlCQUFTLEVBQUVsQixPQUFPLENBQUNtQixPQUE1QjtBQUFBLGdDQUNFLHFFQUFDLHFFQUFEO0FBQ0UsY0FBSSxFQUFDLE9BRFA7QUFFRSxlQUFLLEVBQUMsU0FGUjtBQUdFLHdCQUFXLGFBSGI7QUFJRSxpQkFBTyxFQUFFUixnQkFKWDtBQUtFLG1CQUFTLEVBQUVHLG9EQUFJLENBQUNkLE9BQU8sQ0FBQ29CLFVBQVQsRUFBcUJqQixJQUFJLElBQUlILE9BQU8sQ0FBQ3FCLGdCQUFyQyxDQUxqQjtBQUFBLGlDQU9FLHFFQUFDLCtEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBVUUscUVBQUMsb0VBQUQ7QUFBWSxtQkFBUyxFQUFDLElBQXRCO0FBQTJCLGlCQUFPLEVBQUMsSUFBbkM7QUFBd0MsZUFBSyxFQUFDLFNBQTlDO0FBQXdELGdCQUFNLE1BQTlEO0FBQStELG1CQUFTLEVBQUVyQixPQUFPLENBQUNzQixLQUFsRjtBQUFBLGlDQUNBO0FBQUsscUJBQVMsRUFBRXRCLE9BQU8sQ0FBQ3VCLE9BQXhCO0FBQUEsbUNBSUk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFEQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVZGLGVBb0JFLHFFQUFDLGlFQUFEO0FBQVEsYUFBRyxFQUFDLFlBQVo7QUFBeUIsbUJBQVMsRUFBRXZCLE9BQU8sQ0FBQ3dCO0FBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFGRixlQWlDRSxxRUFBQyxpRUFBRDtBQUNFLGFBQU8sRUFBQyxXQURWO0FBRUUsYUFBTyxFQUFFO0FBQ1BULGFBQUssRUFBRUQsb0RBQUksQ0FBQ2QsT0FBTyxDQUFDeUIsV0FBVCxFQUFzQixDQUFDdEIsSUFBRCxJQUFTSCxPQUFPLENBQUMwQixnQkFBdkM7QUFESixPQUZYO0FBS0UsVUFBSSxFQUFFdkIsSUFMUjtBQUFBLDhCQU9FO0FBQUssaUJBQVMsRUFBRUgsT0FBTyxDQUFDMkIsV0FBeEI7QUFBQSwrQkFDRSxxRUFBQyxxRUFBRDtBQUFZLGlCQUFPLEVBQUVmLGlCQUFyQjtBQUFBLGlDQUNFLHFFQUFDLHNFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVBGLGVBYUUscUVBQUMsa0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWJGLGVBY0UscUVBQUMsK0RBQUQ7QUFBQSwrQkFBTSxxRUFBQyxtREFBRDtBQUFXLDJCQUFpQixFQUFFTDtBQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWpDRixlQWlERTtBQUFNLGVBQVMsRUFBRVAsT0FBTyxDQUFDNEIsT0FBekI7QUFBQSw4QkFDRTtBQUFLLGlCQUFTLEVBQUU1QixPQUFPLENBQUM2QjtBQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFFSSxxRUFBQyxvRUFBRDtBQUFXLGdCQUFRLEVBQUMsSUFBcEI7QUFBeUIsaUJBQVMsRUFBRTdCLE9BQU8sQ0FBQzhCLFNBQTVDO0FBQUEsZ0NBQ0UscUVBQUMsK0RBQUQ7QUFBTSxtQkFBUyxNQUFmO0FBQWdCLGlCQUFPLEVBQUUsQ0FBekI7QUFBQSxpQ0FDRSxxRUFBQywrREFBRDtBQUFNLGdCQUFJLE1BQVY7QUFBVyxjQUFFLEVBQUUsRUFBZjtBQUFtQixjQUFFLEVBQUUsRUFBdkI7QUFBQSxzQkFDQ3pCO0FBREQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUFNQztBQUFBLGlDQUNDLHFFQUFDLDhEQUFEO0FBQUssY0FBRSxFQUFFLEVBQVQ7QUFBQSxtQ0FDRSxxRUFBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFORDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFqREY7QUFBQSxrQkFERjtBQW1FRzs7R0FsSG1CUCxTO1VBQ05ILFM7OztNQURNRyxTIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL0FkbWluL0Rhc2hib2FyZC5mNjViZGY3YmE4OWE5ZGVlYzk5NC5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IGNsc3ggZnJvbSAnY2xzeCc7XHJcbmltcG9ydCB7IG1ha2VTdHlsZXMgfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXMnO1xyXG5pbXBvcnQgVHlwb2dyYXBoeSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9UeXBvZ3JhcGh5JztcclxuaW1wb3J0IENvbnNvbGVfdHlwZSBmcm9tICcuL0NvbnNvbGVfdHlwZSc7XHJcbmltcG9ydCBEaXNwbGF5YWxsX2NvbnNvbGV0eXBlIGZyb20gJy4vRGlzcGxheWFsbF9jb25zb2xldHlwZSc7XHJcbmltcG9ydCBNYWlucGFnZSBmcm9tICcuL01haW5wYWdlJztcclxuaW1wb3J0IENzc0Jhc2VsaW5lIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0Nzc0Jhc2VsaW5lJztcclxuaW1wb3J0IEFwcEJhciBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9BcHBCYXInO1xyXG5pbXBvcnQgVG9vbGJhciBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9Ub29sYmFyJztcclxuaW1wb3J0IExpc3QgZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvTGlzdCc7XHJcbmltcG9ydCBEaXZpZGVyIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0RpdmlkZXInO1xyXG5pbXBvcnQgSWNvbkJ1dHRvbiBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9JY29uQnV0dG9uJztcclxuaW1wb3J0IEJhZGdlIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0JhZGdlJztcclxuaW1wb3J0IENvbnRhaW5lciBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9Db250YWluZXInO1xyXG5pbXBvcnQgR3JpZCBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9HcmlkJztcclxuaW1wb3J0IFBhcGVyIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL1BhcGVyJztcclxuaW1wb3J0IExpbmsgZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvTGluayc7XHJcbmltcG9ydCBNZW51SWNvbiBmcm9tICdAbWF0ZXJpYWwtdWkvaWNvbnMvTWVudSc7XHJcbmltcG9ydCBBdmF0YXIgZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvQXZhdGFyJztcclxuaW1wb3J0IERyYXdlciBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9EcmF3ZXInO1xyXG5pbXBvcnQgQ2hldnJvbkxlZnRJY29uIGZyb20gJ0BtYXRlcmlhbC11aS9pY29ucy9DaGV2cm9uTGVmdCc7XHJcbmltcG9ydCBMaXN0SXRlbXMgZnJvbSAnLi9MaXN0SXRlbXMnO1xyXG5pbXBvcnQgQm94IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL0JveCc7XHJcbmZ1bmN0aW9uIENvcHlyaWdodCgpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImJvZHkyXCIgY29sb3I9XCJ0ZXh0U2Vjb25kYXJ5XCIgYWxpZ249XCJjZW50ZXJcIj5cclxuICAgICAgeydDb3B5cmlnaHQgwqkgJ31cclxuICAgICAgPExpbmsgY29sb3I9XCJpbmhlcml0XCIgaHJlZj1cImh0dHBzOi8vbWF0ZXJpYWwtdWkuY29tL1wiPlxyXG4gICAgICAgIFlvdXIgV2Vic2l0ZVxyXG4gICAgICA8L0xpbms+eycgJ31cclxuICAgICAge25ldyBEYXRlKCkuZ2V0RnVsbFllYXIoKX1cclxuICAgICAgeycuJ31cclxuICAgIDwvVHlwb2dyYXBoeT5cclxuICApO1xyXG59XHJcblxyXG5jb25zdCBkcmF3ZXJXaWR0aCA9IDI0MDtcclxuXHJcbmNvbnN0IHVzZVN0eWxlcyA9IG1ha2VTdHlsZXMoKHRoZW1lKSA9PiAoe1xyXG4vLyAgIHJvb3Q6IHtcclxuLy8gICAgIGRpc3BsYXk6ICdmbGV4JyxcclxuLy8gICB9LFxyXG4vLyAgIHRvb2xiYXI6IHtcclxuLy8gICAgIHBhZGRpbmdSaWdodDogMjQsIC8vIGtlZXAgcmlnaHQgcGFkZGluZyB3aGVuIGRyYXdlciBjbG9zZWRcclxuLy8gICB9LFxyXG4vLyAgIHRvb2xiYXJJY29uOiB7XHJcbi8vICAgICBkaXNwbGF5OiAnZmxleCcsXHJcbi8vICAgICAvLyBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcclxuLy8gICAgIGp1c3RpZnlDb250ZW50OiAnZmxleC1lbmQnLFxyXG4vLyAgICAgcGFkZGluZzogJzAgOHB4JyxcclxuLy8gICAgIC4uLnRoZW1lLm1peGlucy50b29sYmFyLFxyXG4vLyAgIH0sXHJcbi8vICAgYXBwQmFyOiB7XHJcbi8vICAgICB6SW5kZXg6IHRoZW1lLnpJbmRleC5kcmF3ZXIgKyAxLFxyXG4vLyAgICAgdHJhbnNpdGlvbjogdGhlbWUudHJhbnNpdGlvbnMuY3JlYXRlKFsnd2lkdGgnLCAnbWFyZ2luJ10sIHtcclxuLy8gICAgICAgZWFzaW5nOiB0aGVtZS50cmFuc2l0aW9ucy5lYXNpbmcuc2hhcnAsXHJcbi8vICAgICAgIGR1cmF0aW9uOiB0aGVtZS50cmFuc2l0aW9ucy5kdXJhdGlvbi5sZWF2aW5nU2NyZWVuLFxyXG4vLyAgICAgfSksXHJcbi8vICAgfSxcclxuLy8gICBhcHBCYXJTaGlmdDoge1xyXG4vLyAgICAgbWFyZ2luTGVmdDogZHJhd2VyV2lkdGgsXHJcbi8vICAgICB3aWR0aDogYGNhbGMoMTAwJSAtICR7ZHJhd2VyV2lkdGh9cHgpYCxcclxuLy8gICAgIHRyYW5zaXRpb246IHRoZW1lLnRyYW5zaXRpb25zLmNyZWF0ZShbJ3dpZHRoJywgJ21hcmdpbiddLCB7XHJcbi8vICAgICAgIGVhc2luZzogdGhlbWUudHJhbnNpdGlvbnMuZWFzaW5nLnNoYXJwLFxyXG4vLyAgICAgICBkdXJhdGlvbjogdGhlbWUudHJhbnNpdGlvbnMuZHVyYXRpb24uZW50ZXJpbmdTY3JlZW4sXHJcbi8vICAgICB9KSxcclxuLy8gICB9LFxyXG4vLyAgIG1lbnVCdXR0b246IHtcclxuLy8gICAgIG1hcmdpblJpZ2h0OiAzNixcclxuLy8gICB9LFxyXG4vLyAgIG1lbnVCdXR0b25IaWRkZW46IHtcclxuLy8gICAgIGRpc3BsYXk6ICdub25lJyxcclxuLy8gICB9LFxyXG4vLyAgIHRpdGxlOiB7XHJcbi8vICAgICBmbGV4R3JvdzogMSxcclxuLy8gICB9LFxyXG4vLyAgIGRyYXdlclBhcGVyOiB7XHJcbi8vICAgICBwb3NpdGlvbjogJ3JlbGF0aXZlJyxcclxuLy8gICAgIHdoaXRlU3BhY2U6ICdub3dyYXAnLFxyXG4vLyAgICAgd2lkdGg6IGRyYXdlcldpZHRoLFxyXG4vLyAgICAgdHJhbnNpdGlvbjogdGhlbWUudHJhbnNpdGlvbnMuY3JlYXRlKCd3aWR0aCcsIHtcclxuLy8gICAgICAgZWFzaW5nOiB0aGVtZS50cmFuc2l0aW9ucy5lYXNpbmcuc2hhcnAsXHJcbi8vICAgICAgIGR1cmF0aW9uOiB0aGVtZS50cmFuc2l0aW9ucy5kdXJhdGlvbi5lbnRlcmluZ1NjcmVlbixcclxuLy8gICAgIH0pLFxyXG4vLyAgIH0sXHJcbi8vICAgZHJhd2VyUGFwZXJDbG9zZToge1xyXG4vLyAgICAgb3ZlcmZsb3dYOiAnaGlkZGVuJyxcclxuLy8gICAgIHRyYW5zaXRpb246IHRoZW1lLnRyYW5zaXRpb25zLmNyZWF0ZSgnd2lkdGgnLCB7XHJcbi8vICAgICAgIGVhc2luZzogdGhlbWUudHJhbnNpdGlvbnMuZWFzaW5nLnNoYXJwLFxyXG4vLyAgICAgICBkdXJhdGlvbjogdGhlbWUudHJhbnNpdGlvbnMuZHVyYXRpb24ubGVhdmluZ1NjcmVlbixcclxuLy8gICAgIH0pLFxyXG4vLyAgICAgd2lkdGg6IHRoZW1lLnNwYWNpbmcoNyksXHJcbi8vICAgICBbdGhlbWUuYnJlYWtwb2ludHMudXAoJ3NtJyldOiB7XHJcbi8vICAgICAgIHdpZHRoOiB0aGVtZS5zcGFjaW5nKDkpLFxyXG4vLyAgICAgfSxcclxuLy8gICB9LFxyXG4vLyAgIGFwcEJhclNwYWNlcjogdGhlbWUubWl4aW5zLnRvb2xiYXIsXHJcbi8vICAgY29udGVudDoge1xyXG4vLyAgICAgZmxleEdyb3c6IDEsXHJcbi8vICAgICBoZWlnaHQ6ICcxMDB2aCcsXHJcbi8vICAgICBvdmVyZmxvdzogJ2F1dG8nLFxyXG4vLyAgIH0sXHJcbi8vICAgY29udGFpbmVyOiB7XHJcbi8vICAgICBwYWRkaW5nVG9wOiB0aGVtZS5zcGFjaW5nKDQpLFxyXG4vLyAgICAgcGFkZGluZ0JvdHRvbTogdGhlbWUuc3BhY2luZyg0KSxcclxuLy8gICAgIC8vIGJhY2tncm91bmRDb2xvcjonI2VjZWNkOScsXHJcbi8vICAgfSxcclxuLy8gICBwYXBlcjoge1xyXG4vLyAgICAgcGFkZGluZzogdGhlbWUuc3BhY2luZygyKSxcclxuLy8gICAgIGRpc3BsYXk6ICdmbGV4JyxcclxuLy8gICAgIG92ZXJmbG93OiAnYXV0bycsXHJcbi8vICAgICBmbGV4RGlyZWN0aW9uOiAnY29sdW1uJyxcclxuLy8gICB9LFxyXG4vLyAgIGZpeGVkSGVpZ2h0OiB7XHJcbi8vICAgICBoZWlnaHQ6IDI0MCxcclxuLy8gICB9LFxyXG59KSk7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBEYXNoYm9hcmQocHJvcHMpIHtcclxuICBjb25zdCBjbGFzc2VzID0gdXNlU3R5bGVzKCk7XHJcbiAgY29uc3QgW29wZW4sIHNldE9wZW5dID0gUmVhY3QudXNlU3RhdGUodHJ1ZSk7XHJcbiAgY29uc3QgW1Nob3dDb21wb25lbnRzLCBzZXRDb21wb25ldF09IFJlYWN0LnVzZVN0YXRlKDxNYWlucGFnZS8+KTtcclxuLy8gICBjb25zdCBbYWRtaW4sc2V0QWRtaW5dPVJlYWN0LnVzZVN0YXRlKFtdKVxyXG4vLyAgIGNvbnN0IENoZWNrU2Vzc2lvbj1hc3luYygpPT57XHJcbi8vICAgdmFyIHJlc3VsdD1hd2FpdCBnZXREYXRhKCdhZG1pbi9jaGt0b2tlbicpXHJcbi8vICAgaWYoIXJlc3VsdClcclxuLy8gICB7XHJcbi8vICAgIHByb3BzLmhpc3RvcnkucmVwbGFjZSh7cGF0aG5hbWU6Jy9TaWduaW4nfSlcclxuLy8gICB9XHJcbi8vICAgZWxzZXtcclxuLy8gICAgIHZhciBhZG1pbj1KU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdhZG1pbicpKVxyXG4vLyAgICBjb25zb2xlLmxvZyhcIkFETUlOXCIsYWRtaW4pXHJcbi8vICAgIHNldEFkbWluKGFkbWluKVxyXG4vLyAgIH1cclxuXHJcblxyXG4vLyB1c2VFZmZlY3QoZnVuY3Rpb24oKXtcclxuLy8gICBDaGVja1Nlc3Npb24oKTtcclxuLy8gfSxbXSlcclxuXHJcbiAgY29uc3QgaGFuZGxlQ29tcG9uZW50cz1hc3luYyhTaG93RGF0YSk9PntcclxuICAgIHN3aXRjaChTaG93RGF0YSlcclxuICAgIHsgY2FzZSAwOlxyXG4gICAgICAgIGNvbnNvbGUubG9nKCcwJywwKVxyXG4gICAgICBzZXRDb21wb25ldCg8TWFpbnBhZ2UvPik7XHJcbiAgICAgIGJyZWFrXHJcbiAgICAgIGNhc2UgMTogXHJcbiAgICAgIHNldENvbXBvbmV0KDxDb25zb2xlX3R5cGUvPilcclxuICAgICAgYnJlYWtcclxuICAgICAgY2FzZSAyOlxyXG4gICAgICBzZXRDb21wb25ldCg8RGlzcGxheWFsbF9jb25zb2xldHlwZS8+KVxyXG4gICAgICBicmVha1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgY29uc3QgaGFuZGxlRHJhd2VyT3BlbiA9ICgpID0+IHtcclxuICAgIHNldE9wZW4odHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRHJhd2VyQ2xvc2UgPSAoKSA9PiB7XHJcbiAgICBzZXRPcGVuKGZhbHNlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBmaXhlZEhlaWdodFBhcGVyID0gY2xzeChjbGFzc2VzLnBhcGVyLCBjbGFzc2VzLmZpeGVkSGVpZ2h0KTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxDc3NCYXNlbGluZSAvPlxyXG4gICAgICA8QXBwQmFyIHBvc2l0aW9uPVwiYWJzb2x1dGVcIiBjbGFzc05hbWU9e2Nsc3goY2xhc3Nlcy5hcHBCYXIsIG9wZW4gJiYgY2xhc3Nlcy5hcHBCYXJTaGlmdCl9PlxyXG4gICAgICAgIDxUb29sYmFyIGNsYXNzTmFtZT17Y2xhc3Nlcy50b29sYmFyfT5cclxuICAgICAgICAgIDxJY29uQnV0dG9uXHJcbiAgICAgICAgICAgIGVkZ2U9XCJzdGFydFwiXHJcbiAgICAgICAgICAgIGNvbG9yPVwiaW5oZXJpdFwiXHJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJvcGVuIGRyYXdlclwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURyYXdlck9wZW59XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xzeChjbGFzc2VzLm1lbnVCdXR0b24sIG9wZW4gJiYgY2xhc3Nlcy5tZW51QnV0dG9uSGlkZGVuKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPE1lbnVJY29uIC8+XHJcbiAgICAgICAgICA8L0ljb25CdXR0b24+XHJcbiAgICAgICAgICA8VHlwb2dyYXBoeSBjb21wb25lbnQ9XCJoMVwiIHZhcmlhbnQ9XCJoNlwiIGNvbG9yPVwiaW5oZXJpdFwiIG5vV3JhcCBjbGFzc05hbWU9e2NsYXNzZXMudGl0bGV9PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2NsYXNzZXMuaGVhZGluZ30+XHJcbiAgICAgICAgICAgICB7LyogPGRpdj5cclxuICAgICAgICAgICAgICBBZG1pbiBEYXNoYm9hcmRcclxuICAgICAgICAgICAgICA8L2Rpdj4gKi99XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIHsvKiB7YWRtaW4uYWRtaW5uYW1lfSAqL31cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICA8QXZhdGFyIGFsdD1cIlJlbXkgU2hhcnBcIiBjbGFzc05hbWU9e2NsYXNzZXMubGFyZ2V9IC8+XHJcbiAgICAgICAgICAgey8qIDxBdmF0YXIgYWx0PVwiUmVteSBTaGFycFwiIHNyYz17YCR7U2VydmVyVVJMfS9pbWFnZXMvJHthZG1pbi5waWN0dXJlfWB9IGNsYXNzTmFtZT17Y2xhc3Nlcy5sYXJnZX0gLz4gKi99XHJcblxyXG4gICAgICAgICAgey8qIDxJY29uQnV0dG9uIGNvbG9yPVwiaW5oZXJpdFwiPlxyXG4gICAgICAgICAgICA8QmFkZ2UgYmFkZ2VDb250ZW50PXs0fSBjb2xvcj1cInNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgIDxOb3RpZmljYXRpb25zSWNvbiAvPlxyXG4gICAgICAgICAgICA8L0JhZGdlPlxyXG4gICAgICAgICAgPC9JY29uQnV0dG9uPiAqL31cclxuICAgICAgICA8L1Rvb2xiYXI+XHJcbiAgICAgIDwvQXBwQmFyPlxyXG4gICAgICA8RHJhd2VyXHJcbiAgICAgICAgdmFyaWFudD1cInBlcm1hbmVudFwiXHJcbiAgICAgICAgY2xhc3Nlcz17e1xyXG4gICAgICAgICAgcGFwZXI6IGNsc3goY2xhc3Nlcy5kcmF3ZXJQYXBlciwgIW9wZW4gJiYgY2xhc3Nlcy5kcmF3ZXJQYXBlckNsb3NlKSxcclxuICAgICAgICB9fVxyXG4gICAgICAgIG9wZW49e29wZW59XHJcbiAgICAgID5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17Y2xhc3Nlcy50b29sYmFySWNvbn0+XHJcbiAgICAgICAgICA8SWNvbkJ1dHRvbiBvbkNsaWNrPXtoYW5kbGVEcmF3ZXJDbG9zZX0+XHJcbiAgICAgICAgICAgIDxDaGV2cm9uTGVmdEljb24gLz5cclxuICAgICAgICAgIDwvSWNvbkJ1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPERpdmlkZXIgLz5cclxuICAgICAgICA8TGlzdD48TGlzdEl0ZW1zIGhhbmRsZV9Db21wb25lbnRzPXtoYW5kbGVDb21wb25lbnRzfS8+PC9MaXN0PlxyXG4gICAgICAgPC9EcmF3ZXI+XHJcbiAgICAgIDxtYWluIGNsYXNzTmFtZT17Y2xhc3Nlcy5jb250ZW50fT5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17Y2xhc3Nlcy5hcHBCYXJTcGFjZXJ9IC8+XHJcbiAgICAgICAgICA8Q29udGFpbmVyIG1heFdpZHRoPVwibGdcIiBjbGFzc05hbWU9e2NsYXNzZXMuY29udGFpbmVyfT5cclxuICAgICAgICAgICAgPEdyaWQgY29udGFpbmVyIHNwYWNpbmc9ezJ9PlxyXG4gICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBzbT17MTJ9PlxyXG4gICAgICAgICAgICAgIHtTaG93Q29tcG9uZW50c31cclxuICAgICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8Qm94IHB0PXsxMn0+XHJcbiAgICAgICAgICAgICAgPENvcHlyaWdodCAvPlxyXG4gICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgPC9kaXY+ICBcclxuICAgICAgICAgIDwvQ29udGFpbmVyPlxyXG4gICAgICA8L21haW4+XHJcbiAgICA8Lz5cclxuICApXHJcbiAgICB9Il0sInNvdXJjZVJvb3QiOiIifQ==